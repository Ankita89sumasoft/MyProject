package Helper;

import Utilities.JsonDataReadAndWrite;
import com.paulhammant.ngwebdriver.NgWebDriver;
//import org.json.simple.parser.ParseException;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;

public class BaseClass {
    PropertiesReader pro=new PropertiesReader();
   public static NgWebDriver ngwebdriver;
    public static QRCodeHelper qr=null;
   public String appId="AA9662";

    public static WebDriver driver ;
    public JsonDataReadAndWrite json=new JsonDataReadAndWrite();

    public void set() throws IOException, ParseException {
      ChromeOptions chromeOptions=new ChromeOptions();
        //chromeOptions.addArguments("--headless");
        chromeOptions.addArguments("--disable-cache");
        chromeOptions.addArguments("start-maximized");
        chromeOptions.addArguments("--window-size=1400,600");
        System.setProperty("webdriver.chrome.driver","src/Driver/chromedriver2.exe");
        String file_Path="C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\DownloadedFile";
        HashMap<String,Object> pref=new HashMap<String,Object>();
        pref.put("download.default_directory",file_Path);
        chromeOptions.setExperimentalOption("prefs",pref);
        driver=new ChromeDriver(chromeOptions);
        this.ngwebdriver=new NgWebDriver((JavascriptExecutor) driver);
        driver.manage().window().maximize();
    }
    public void login() throws InterruptedException {
        String url=pro.propertyReader("url");
        String username=pro.propertyReader("username");
        String password=pro.propertyReader("password");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        qr=new QRCodeHelper();
        qr.getLogin_Email_Id().sendKeys(username);
        Thread.sleep(1000);
        qr.getPassword().sendKeys(password);
        Thread.sleep(1000);
        qr.getLoginSubmit().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    public String captureScreenShot() throws IOException {
        TakesScreenshot screenshot=(TakesScreenshot) driver;
        String Source=screenshot.getScreenshotAs(OutputType.BASE64);
        /*String des="C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\test-output";
        FileUtils.copyDirectory(scrfile,new File(des));*/
        return Source;
    }
    public static boolean isClickable(WebElement el, WebDriverWait wait)
    {
        try{

            wait.until(ExpectedConditions.elementToBeClickable(el));
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    public void end()
    {
        driver.manage().deleteAllCookies();
        driver.close();
    }
}
