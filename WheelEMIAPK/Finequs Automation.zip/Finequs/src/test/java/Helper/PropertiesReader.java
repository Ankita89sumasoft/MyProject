package Helper;

import java.io.FileReader;
import java.util.Properties;

public class PropertiesReader {
    public String propertyReader(String s)
    {
        Properties p=new Properties();
        try
        {
            p.load(new FileReader("src/Resources/FinequsData.properties"));
        }
        catch(Exception e)
        {
            System.out.println("Expection is"+e);
        }
        return p.getProperty(s);
    }
}
