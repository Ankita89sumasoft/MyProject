package Helper;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationReader
{
    public String getReportConfigPath() throws IOException {
        Properties p=new Properties();
        p.load(new FileReader("src/Resources/configuration.properties"));
        String reportConfigPath = p.getProperty("reportConfigPath");

        if(reportConfigPath!= null) return reportConfigPath;
        else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }
}
