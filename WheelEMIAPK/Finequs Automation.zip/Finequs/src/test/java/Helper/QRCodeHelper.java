package Helper;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class QRCodeHelper extends BaseClass {
    public WebDriverWait wait = new WebDriverWait(driver, 30);

    public QRCodeHelper() {
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//input[@placeholder='Email']")
    WebElement loginemailid;
    public WebElement getLogin_Email_Id()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Email']")));
        return loginemailid;
    }
    @FindBy(xpath = "//input[@placeholder='Password']")
    WebElement password;
    public WebElement getPassword()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Password']")));
        return password;
    }
    @FindBy(xpath = "//button[@type='submit']")
    WebElement loginsubmit;
    public WebElement getLoginSubmit()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
        return loginsubmit;
    }
    @FindBy(xpath = "(//span[@class='hamburger-box'])[1]")
    WebElement navigation;

    public WebElement getNavigationBar() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='hamburger-box'])[1]")));
        return navigation;
    }

    @FindBy(xpath = "//div[@class='app-sidebar__inner']")
    WebElement navigationdrawer;

    public WebElement getNavigationdrawer() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='app-sidebar__inner']")));
        return navigationdrawer;
    }

    @FindBy(xpath = "//a[text()=' Channel']")
    WebElement channel;

    public WebElement getChannel() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Channel']")));
        return channel;
    }
    @FindBy(xpath = "//div[@id='appm']")
    WebElement maindiv;
    public WebElement getMainDiv()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='appm']")));
        return maindiv;
    }
    @FindBy(xpath = "//a[text()=' Generate QRCode ']")
    WebElement generateqrcode;

    public WebElement getGenerateqrcode() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Generate QRCode ']")));
        return generateqrcode;
    }
    @FindBy(xpath = "//select[@formcontrolname='GenerateFor']")
    WebElement generatefor;
    public WebElement getGenerateFor()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@formcontrolname='GenerateFor']")));
        return generatefor;
    }

    @FindBy(xpath = "//button[@class='btn btn-primary']")
    WebElement copyurl;

    public WebElement getCopyURL() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary']")));
        return copyurl;
    }

    @FindBy(xpath = "//button[text()='Close']")
    WebElement closealter;

    public WebElement getClosealter() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Close']")));
        return closealter;
    }

    @FindBy(xpath = "//input[@id='firstName']")
    WebElement url;

    public WebElement getURL() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='firstName']")));
        return url;
    }

    @FindBy(xpath = "//button[text()=' Generate QRCode ']")
    WebElement generateQRcode;

    public WebElement getGenerateQRcode() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Generate QRCode ']")));
        return generateQRcode;
    }

    @FindBy(xpath = "//p[text()=' © Copyright finequs 1.0.0.0 ']")
    WebElement scroll;

    public WebElement getScroll() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[text()=' © Copyright finequs 1.0.0.0 ']")));
        return scroll;
    }

    @FindBy(xpath = "//p[text()='Generate QR Code']")
    WebElement header;

    public WebElement getHeader() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Generate QR Code']")));
        return header;
    }

    @FindBy(xpath = "//h4[text()='Insta Loan']")
    WebElement instaloan;

    public WebElement getInstaLoan() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Insta Loan']")));
        return instaloan;
    }

    @FindBy(xpath = "//input[@id='IsConsent']")
    WebElement checkbox;

    public WebElement getCheckbox() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='IsConsent']")));
        return checkbox;
    }
    @FindBy(xpath = "//button[text()=' I Agree ']")
    WebElement agree;

    public WebElement getAgreeStatement() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' I Agree ']")));
        return agree;
    }

    @FindBy(xpath = "//button[text()='Send OTP']")
    WebElement sendotp;

    public WebElement getSendotp() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Send OTP']")));
        return sendotp;
    }

    @FindBy(xpath = "//div[@class='col-md-8 m-auto']")
    WebElement div;

    public WebElement getDiv() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='col-md-8 m-auto']")));
        return div;
    }

    @FindBy(xpath = "//input[@placeholder='Sent To']")
    WebElement searchdata;

    public WebElement getSearchdata() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Sent To']")));
        return searchdata;
    }

    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[7]")
    WebElement searchicon1;
    public WebElement getSearchiconFirst() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='ng-star-inserted'])[7]")));
        return searchicon1;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[13]")
    WebElement searchicon2;
    public WebElement getSearchiconSecond() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='ng-star-inserted'])[13]")));
        return searchicon2;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[19]")
    WebElement searchicon3;
    public WebElement getSearchiconThird() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='ng-star-inserted'])[19]")));
        return searchicon3;
    }
    @FindBy(xpath = "//section[@class='segment segment-type-string ng-star-inserted']")
    List<WebElement> ACLSMSDetails;
    public List<WebElement> getACLSMSDetails()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//section[@class='segment segment-type-string ng-star-inserted']")));
        return ACLSMSDetails;
    }
    @FindBy(xpath = "(//span[@class='segment-value ng-star-inserted'])[10]")
    WebElement otpConatinsVerificationText;
    public WebElement getOTPVerificationContainsText()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")));
        return otpConatinsVerificationText;
    }
    @FindBy(xpath = "//input[@placeholder='Mobile']")
    WebElement mobile;

    public WebElement getMobilenumber() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Mobile']")));
        return mobile;
    }
    @FindBy(xpath = "(//div[@class='row'])[6]")
    WebElement bankSelectionPage;
    public WebElement getBankSelectionPage()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='row'])[6]")));
        return bankSelectionPage;
    }
    @FindBy(xpath = "(//button[text()=' Save and Next '])[1]")
    WebElement saveandnextbuttonofbankselection;
    public WebElement getSaveAndNextButtonofBankSelection()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[text()=' Save and Next '])[1]")));
        return saveandnextbuttonofbankselection;
    }
    @FindBy(xpath = "(//button[text()=' Send OTP '])[1]")
    WebElement sendOTPButton;
    public WebElement getSendOTPButton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[text()=' Send OTP '])[1]")));
        return sendOTPButton;
    }
    @FindBy(xpath = "//input[@placeholder='First Name']")
    WebElement firstname;
    public WebElement getFirstName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='First Name']")));
        return firstname;
    }
    @FindBy(xpath = "(//div[@class='row'])[3]")
    WebElement form;
    public WebElement getForm()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//form[@id='contact-form'])[1]")));
        return form;
    }
    @FindBy(xpath = "//input[@placeholder='Last Name']")
    WebElement lastname;
    public WebElement getLastName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Last Name']")));
        return lastname;
    }
    @FindBy(xpath = "//input[@placeholder='Pincode']")
    WebElement pincode;
    public WebElement getPincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Pincode']")));
        return pincode;
    }
    @FindBy(xpath = "//button[@type='submit']")
    WebElement refresh;
    public WebElement getRefreshpage()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']")));
        return refresh;
    }
    @FindBy(xpath = "(//span[@class='segment-value ng-star-inserted'])[10]")
    WebElement message;
    public WebElement getMessage()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")));
        return message;
    }
    @FindBy(xpath = "//mat-icon[text()='close']")
    WebElement close;
    public WebElement getCloseOTPAlter()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//mat-icon[text()='close']")));
        return close;
    }
    @FindBy(xpath = "(//mat-icon[text()='search'])[1]")
    WebElement searchone;
    public WebElement getClickFirstSearchIcon()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='search'])[1]")));
        return searchone;
    }
    @FindBy(xpath = "(//mat-icon[text()='search'])[3]")
    WebElement searchsecond;
    public WebElement getClickSecondSearchIcon()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='search'])[3]")));
        return searchsecond;
    }
    @FindBy(xpath = "(//mat-icon[text()='search'])[5]")
    WebElement searchthird;
    public WebElement getSearchThird()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='search'])[5]")));
        return searchthird;
    }
    @FindBy(xpath = "(//mat-icon[text()='search'])[7]")
    WebElement searchfourth;
    public WebElement getSearchFourth()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='search'])[7]")));
        return searchfourth;
    }
    @FindBy(xpath = "//input[@placeholder='Enter OTP']")
    WebElement enterOTP;
    public WebElement getEnterOTP()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Enter OTP']")));
        return enterOTP;
    }
    @FindBy(xpath = "//button[text()=' Submit OTP ']")
    WebElement submitotp;
    public WebElement getSubmitOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Submit OTP ']")));
        return submitotp;
    }
    @FindBy(xpath = "//button[text()=' OK ']")
    WebElement ok;
    public WebElement getOk()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' OK ']")));
        return ok;
    }
    @FindBy(xpath = "//span[text()='messages']")
    WebElement segmentkey;
    public WebElement getSegmentkey()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='messages']")));
        return segmentkey;
    }
    @FindBy(xpath = "(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[1]")
    WebElement searchmobilenumber;
    public WebElement getSearchMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[1]")));
        return searchmobilenumber;
    }
    @FindBy(xpath = "//a[text()=' Loans']")
    WebElement loans;
    public WebElement getLoans()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Loans']")));
        return loans;
    }
    @FindBy(xpath = "//a[text()=' Loan Applications ']")
    WebElement loanapplication;
    public WebElement getLoanApplication()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Loan Applications ']")));
        return loanapplication;
    }
    @FindBy(xpath = "//input[@placeholder='Mobile']")
    WebElement mobilesearch;
    public WebElement getSearchMobileNo()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Mobile']")));
        return mobilesearch;
    }
    @FindBy(xpath = "//a[text()=' Micro Loan Queue ']")
    WebElement microloanqueue;
    public WebElement getMicroLoanQueue()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Micro Loan Queue ']")));
        return microloanqueue;
    }
    @FindBy(xpath = "//td[@class='records mat-cell cdk-column-applicationId mat-column-applicationId ng-star-inserted']")
    WebElement applicationid;
    public WebElement getApplicationID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@class='records mat-cell cdk-column-applicationId mat-column-applicationId ng-star-inserted']")));
        return applicationid;
    }
    @FindBy(xpath = "//div[@class='col-12 d-flex justify-content-between justify-content-md-start  align-items-end']")
    WebElement microapplicationid;
    public WebElement getMicroId()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='col-12 d-flex justify-content-between justify-content-md-start  align-items-end']")));
        return microapplicationid;
    }
    @FindBy(xpath = "//button[text()=' Next ']")
    WebElement nextbutton;
    public WebElement getNextButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Next ']")));
        return nextbutton;
    }
    @FindBy(xpath ="//textarea[@class='form-control ng-untouched ng-pristine ng-valid']")
    WebElement remark;
    public WebElement getNewRemark()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@class='form-control ng-untouched ng-pristine ng-valid']")));
        return remark;
    }
    @FindBy(xpath = "//button[text()=' Data Collection ']")
    WebElement datacollection;
    public WebElement getDatacollection()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Data Collection ']")));
        return datacollection;
    }
    @FindBy(xpath = "//button[text()='Ok']")
    WebElement datacollectionok;
    public WebElement getDatacollectionok()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Ok']")));
        return datacollectionok;
    }
    @FindBy(xpath = "//input[@name='alternateMobile']")
    WebElement alternatemobilenumber;
    public WebElement getAlternateMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='alternateMobile']")));
        return alternatemobilenumber;
    }
    @FindBy(xpath = "//input[@name='fatherName']")
    WebElement fathername;
    public WebElement getFatherName()
    {
        wait.until((ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='fatherName']"))));
        return fathername;
    }
    @FindBy(xpath = "//input[@name='motherName']")
    WebElement mothername;
    public WebElement getMothername()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='motherName']")));
        return mothername;
    }
    @FindBy(xpath = "//input[@type='checkbox']")
    WebElement checkboxtick;
    public WebElement getCheckBoxTick()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='checkbox']")));
        return checkboxtick;
    }
    @FindBy(xpath = "//input[@formcontrolname='resOfficeSame']")
    WebElement resofficesame;
    public WebElement getResOfficeSame()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='resOfficeSame']")));
        return resofficesame;
    }
    @FindBy(xpath = "//button[text()=' Submit ']")
    WebElement submitmicro;
    public WebElement getSumbitMicro()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Submit ']")));
        return submitmicro;
    }
    @FindBy(xpath="//a[text()=' Document Collection Queue ']")
    WebElement datacollectionqueue;
    public WebElement getDataCollectionQueue()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Document Collection Queue ']")));
        return datacollectionqueue;
    }
    @FindBy(xpath = "//span[@class='ngx-select__placeholder text-muted ng-star-inserted']")
    WebElement DocCollectionID;
    public WebElement getDocCollectionID()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='ngx-select__placeholder text-muted ng-star-inserted']")));
        return DocCollectionID;
    }
    @FindBy(xpath = "//input[@placeholder='Please select ApplicationId']")
    WebElement ddappid;
    public WebElement getDDAppID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Please select ApplicationId']")));
        return ddappid;
    }
    @FindBy(xpath = "//h3[text()='No Data Available...']")
    WebElement no_data_avilable;
    public WebElement getNo_Data_Avilable()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h3[text()='No Data Available...']")));
        return no_data_avilable;
    }
    @FindBy(xpath = "//p[text()='Data Collection Queue']")
    WebElement data_collection_queuetext;
    public WebElement getDataCollectionQueueText()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Data Collection Queue']")));
        return data_collection_queuetext;
    }
    @FindBy(xpath = "//h4[text()='Quick Loan']")
    WebElement quickloan;
    public WebElement getQuickLoan()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Quick Loan']")));
        return quickloan;
    }
    @FindBy(xpath = "//h4[contains(text(),'Credit Card')]")
    WebElement creditcardoption;
    public WebElement getCreaditCardOption()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[contains(text(),'Credit Card')]")));
        return creditcardoption;
    }
    @FindBy(xpath = "//h4[text()='Personal Loan']")
    WebElement personalloan;
    public WebElement getPersonalLoan()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Personal Loan']")));
        return personalloan;
    }
    @FindBy(xpath = "(//input[@formcontrolname='mobile'])[1]")
    WebElement mobilenumber;
    public WebElement getEnterMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='mobile'])[1]")));
        return mobilenumber;
    }
    @FindBy(xpath = "(//input[@type='checkbox'])[1]")
    WebElement tickcheckbox;
    public WebElement getTickCheckBox()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='checkbox'])[1]")));
        return tickcheckbox;
    }
    @FindBy(xpath = "(//button[text()=' Send OTP '])[1]")
    WebElement otpsend;
    public WebElement getSendOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Send OTP '])[1]")));
        return otpsend;
    }
    @FindBy(xpath = "//a[text()=' Reports']")
    WebElement report;
    public WebElement getReport()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Reports']")));
        return report;
    }
    @FindBy(xpath = "//a[text()=' SMS Log ']")
    WebElement smslog;
    public WebElement getSMSLog()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' SMS Log ']")));
        return smslog;
    }
    @FindBy(xpath = "(//input[@type='password'])[1]")
    WebElement otp;
    public WebElement getEnterMobileOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='password'])[1]")));
        return otp;
    }
    @FindBy(xpath = "(//button[contains(text(),' Verify ')])[1]")
    WebElement verify;
    public WebElement getVerifyButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),' Verify ')])[1]")));
        return verify;
    }
    @FindBy(xpath =" //mat-icon[text()='attachment ']")
    WebElement pinicon;
    public WebElement getpinicon()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(" //mat-icon[text()='attachment ']")));
        return pinicon;
    }
    @FindBy(xpath = "//button[@class='btn-shadow btn-wide btn-pill btn-hover-shine btn btn btn-primary ml-2']")
    WebElement uploadbutton;
    public WebElement getUploadButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-shadow btn-wide btn-pill btn-hover-shine btn btn btn-primary ml-2']")));
        return uploadbutton;
    }
    @FindBy(xpath = "//input[@formcontrolname='firstName']")
    WebElement pdfirstname;
    public WebElement getFirstname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='firstName']")));
        return pdfirstname;
    }
    @FindBy(xpath = "(//input[@formcontrolname='lastName'])[1]")
    WebElement pdlastname;
    public WebElement getPdLastName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='lastName'])[1]")));
        return pdlastname;
    }
   @FindBy(xpath = "(//input[@formcontrolname='dob'])[1]")
    WebElement dob;
    public WebElement getDOB()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@formcontrolname='dob'])[1]")));
        return dob;
    }
    @FindBy(xpath = "(//input[@formcontrolname='panNumber'])[1]")
    WebElement pannumber;
    public WebElement getPanNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='panNumber'])[1]")));
        return pannumber;

    }

    @FindBy(xpath = "(//input[@formcontrolname='pincode'])[1]")
    WebElement pdpincode;
    public WebElement getPDppincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='pincode'])[1]")));
        return pdpincode;
    }
    @FindBy(xpath = "(//button[text()=' Save and Next '])[1]")
    WebElement saveandnext;
    public WebElement getSaveAndNext()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Save and Next '])[1]")));
        return saveandnext;
    }
    @FindBy(xpath = "//button[@class='current']")
    WebElement currentdate;
    public WebElement getCurrentdate()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='current']")));
        return currentdate;
    }
    @FindBy(xpath = "//button[@class='previous']")
    WebElement previousbutton;
    public WebElement getPreviousbutton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='previous']")));
        return previousbutton;
    }
    @FindBy(xpath = "//span[text()='1998']")
    WebElement year;
    public WebElement getYear()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='1998']")));
        return year;
    }
    @FindBy(xpath = "//span[text()='August']")
    WebElement month;
    public WebElement getMonth()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='August']")));
        return month;
    }
    @FindBy(xpath = "//span[text()='20']")
    WebElement day;
    public WebElement getDay()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='20']")));
        return day;
    }
    @FindBy(xpath = "(//input[@formcontrolname='occupation'])[2]")
    WebElement occupation;
    public WebElement getOccupation()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@formcontrolname='occupation'])[2]")));
        return occupation;
    }
    @FindBy(xpath = "(//button[text()=' Confirm '])[1]")
    WebElement confirm;
    public WebElement getConfirmButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Confirm '])[1]")));
        return confirm;
    }
    @FindBy(xpath = "(//div[@class='col-12 d-flex justify-content-between justify-content-md-start align-items-end'])[1]")
    WebElement pdapplicationid;
    public WebElement getPDApplicationID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='col-12 d-flex justify-content-between justify-content-md-start align-items-end'])[1]")));
        return pdapplicationid;
    }
    @FindBy(xpath = "(//input[@name='currentAddress'])[1]")
    WebElement currentaddress;
    public WebElement getCurrentAddress()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='currentAddress'])[1]")));
        return currentaddress;
    }
    @FindBy(xpath = "(//input[@name='email'])[1]")
    WebElement emailid;
    public WebElement getEmaild()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='email'])[1]")));
        return emailid;
    }
    @FindBy(xpath = "(//input[@name='loanAmount'])[1]")
    WebElement loanamount;
    public WebElement getLoanAmount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='loanAmount'])[1]")));
        return loanamount;
    }
    @FindBy(xpath = "(//input[@name='netMonthlyIncome'])[1]")
    WebElement netmonthlyicome;
    public WebElement getNetMonthlyIcome()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='netMonthlyIncome'])[1]")));
        return netmonthlyicome;
    }

    @FindBy(xpath = "(//input[@formcontrolname='officePincode'])[1]")
    WebElement officepincode;
    public WebElement getOfficePincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='officePincode'])[1]")));
        return officepincode;
    }
    @FindBy(xpath = "(//button[@type='submit'])[5]")
    WebElement submit;
    public WebElement getSubmit()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@type='submit'])[5]")));
        return submit;

    }
    @FindBy(xpath = "(//input[@name='otp'])[2]")
    WebElement otpenter;
    public WebElement getOTPEnter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='otp'])[2]")));
        return otpenter;
    }
    @FindBy(xpath = "//button[text()='Verify OTP']")
    WebElement verifyotp;
    public WebElement getVerifyOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Verify OTP']")));
        return verifyotp;
    }
    @FindBy(xpath = "//h4[text()='Finequs - One-stop shop for all your financial requirements.']")
    WebElement tagname;
    public WebElement getTagName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h4[text()='Finequs - One-stop shop for all your financial requirements.']")));
        return tagname;
    }
    @FindBy(xpath = "//div[@class='headerOuter']")
    WebElement row;
    public WebElement getRow()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='headerOuter']")));
        return row;
    }
    @FindBy(xpath = "//h4[text()='விரைவு கடன்']")
    WebElement otherlanginstaloan;
    public WebElement getOtherLangInstaLoan()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='விரைவு கடன்']")));
        return otherlanginstaloan;
    }
    @FindBy(xpath = "//h4[text()='Credit Card']")
    WebElement creditcard;
    public WebElement getCreaditcardQDE()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Credit Card']")));
        return creditcard;
    }
    @FindBy(xpath = "//h4[text()='Insurance']")
    WebElement insurance;
    public WebElement getInsurance()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Insurance']")));
        return insurance;
    }
    @FindBy(xpath = "(//input[@type='text'])[1]")
    WebElement insurance_mobile;
    public WebElement getInsurance_mobile()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@type='text'])[1]")));
        return insurance_mobile;
    }
    @FindBy(xpath = "(//select[@placeholder='--Select--'])[1]")
    WebElement insurance_salutation;
    public WebElement getInsurance_salutation()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//select[@placeholder='--Select--'])[1]")));
        return insurance_salutation;
    }
    @FindBy(xpath = "(//input[@required='required'])[2]")
    WebElement insurance_firstname;
    public WebElement getInsurance_firstname()
    {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@required='required'])[2]")));
        return insurance_firstname;
    }
    @FindBy(xpath = "(//input[@required='required'])[3]")
    WebElement insurance_lastname;
    public WebElement getInsurance_lastname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@required='required'])[3]")));
        return insurance_lastname;
    }
    @FindBy(xpath = "//input[@id='dob-id']")
    WebElement insurance_dob;
    public WebElement getInsurance_dob()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='dob-id']")));
        return insurance_dob;
    }
    @FindBy(xpath = "(//select[@placeholder='--Select--'])[2]")
    WebElement insurance_gender;
    public WebElement getInsurance_Geneder()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//select[@placeholder='--Select--'])[2]")));
        return insurance_gender;
    }
    @FindBy(xpath = "(//input[@type='text'])[5]")
    WebElement insurance_email;
    public WebElement getInsurance_Email()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@type='text'])[5]")));
        return insurance_email;
    }
    @FindBy(xpath = "//button[text()=' Finish ']")
    WebElement insurance_finish;
    public WebElement getInsurance_Finish()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Finish ']")));
        return insurance_finish;
    }
    @FindBy(xpath = "//button[text()=' Cancel ']")
    WebElement insurance_cancel;
    public WebElement getInsurance_Cancel()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Cancel ']")));
        return insurance_cancel;
    }
    @FindBy(xpath = "(//button[@type='submit'])[1]")
    WebElement CreditQEDSendOTP;
    public WebElement getCreditQEDSendOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@type='submit'])[1]")));
        return CreditQEDSendOTP;
    }
    @FindBy(xpath = "(//input[@formcontrolname='otp'])[1]")
    WebElement enterotpcreditQDE;
    public WebElement getEnterOTPCreditQDE()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='otp'])[1]")));
        return enterotpcreditQDE;
    }
    @FindBy(xpath = "(//button[text()=' Verify '])[1]")
    WebElement verifycreditQDE;
    public WebElement getVerifyCreditQDE()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Verify '])[1]")));
        return verifycreditQDE;
    }
    @FindBy(xpath = "(//input[@formcontrolname='firstName'])[1]")
    WebElement creditcardFirstname;
    public WebElement getCreditcardFirstname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='firstName'])[1]")));
        return creditcardFirstname;
    }
    @FindBy(xpath = "//label[contains(text(),'Last Name ')]")
    WebElement creditLastName;
    public WebElement getCreaditLastName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(),'Last Name ')]")));
        return creditLastName;
    }
    @FindBy(xpath = "//label[text()='DOB']")
    WebElement creditdob;
    public WebElement getCreaditDOB()
    {
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[text()='DOB']")))  ;
      return creditdob;
    }
    @FindBy(xpath = "//label[text()='Pincode']")
    WebElement labelpincode;
    public WebElement getLabelPincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[text()='Pincode']")));
        return labelpincode;
    }
    @FindBy(xpath = "(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[1]")
    WebElement table1;
    public WebElement getTable1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[1]")));
        return table1;
    }

    @FindBy(xpath = "(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[2]")
    WebElement table2;
    public WebElement getTable2()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[2]")));
        return table2;
    }
    @FindBy(xpath = "(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[3]")
    WebElement table3;
    public WebElement getTable3()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[3]")));
        return table3;
    }
    @FindBy(xpath = "(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[4]")
    WebElement table4;
    public WebElement getTable4()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//td[@class='records mat-cell cdk-column-sentTo mat-column-sentTo ng-star-inserted'])[4]")));
        return table4;
    }
    @FindBy(xpath = "(//span[text()='Please enter a valid first name'])[1]")
    WebElement firstnameverification;
    public WebElement getFirstnameverification()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Please enter a valid first name'])[1]")));
        return firstnameverification;
    }
    @FindBy(xpath = "(//span[text()='Please enter a valid last name'])[1]")
    WebElement lastnameverification;
    public WebElement getLastnameVerification()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Please enter a valid last name'])[1]")));
        return lastnameverification;
    }
    @FindBy(xpath = "//div[text()='Email must be a valid email address']")
    WebElement loginalterverification;
    public WebElement getLoginAlterVerificaton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Email must be a valid email address']")));
        return loginalterverification;
    }
    @FindBy(xpath = "//div[@class='row mb-5 productOuter px-4 justify-content-center']")
    WebElement childwindowelement;
    public WebElement getChildWindowElement()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='row mb-5 productOuter px-4 justify-content-center']")));
        return childwindowelement;
    }
    @FindBy(xpath = "//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")
    WebElement tickbankSelection;
    public WebElement getTickBankSelection()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")));
        return tickbankSelection;
    }
    @FindBy(xpath = "(//button[text()=' Submit '])[1]")
    WebElement personalsubmit;
    public WebElement getPersonalSubmit()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Submit '])[1]")));
        return personalsubmit;
    }
    @FindBy(xpath = "//p[text()='Thank you for the request, we have sent you a link to download the App for Indifi.']")
    WebElement alterverification;
    public WebElement getAlterVerification()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Thank you for the request, we have sent you a link to download the App for Indifi.']")));
        return alterverification;
    }
    @FindBy(xpath = "//input[@placeholder='App ID']")
    WebElement quickappid;
    public WebElement getQuickAppId()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='App ID']")));
        return quickappid;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[23]")
    WebElement finalstatus;
    public WebElement getFinalStatus()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='ng-star-inserted'])[23]")));
        return finalstatus;
    }
    @FindBy(xpath = "//div[text()='Customer Application Status updated successfully.']")
    WebElement updatestatusalter;
    public WebElement getUpdateStatusAlter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Customer Application Status updated successfully.']")));
        return updatestatusalter;
    }
    @FindBy(xpath = "//a[text()=' Data Collection Queue ']")
    WebElement dcq;
    public WebElement getQuicDataCollectionQueue()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Data Collection Queue ']")));
        return dcq;
    }
    @FindBy(xpath = "//input[@placeholder='Search for applications here']")
    WebElement searchid;
    public WebElement getSearchId()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Search for applications here']")));
        return searchid;
    }
    @FindBy(xpath = "//div[@class='ngx-select__toggle btn form-control']")
    WebElement serachclick;
    public WebElement getSearchClick()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ngx-select__toggle btn form-control']")));
       return serachclick;
    }
    @FindBy(xpath = "//button[text()=' Search ']")
    WebElement search;
    public WebElement getSearch()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Search ']")));
        return search;
    }
    @FindBy(xpath = "(//a[@class='ngx-select__item dropdown-item ng-star-inserted'])[1]")
    WebElement click;
    public WebElement getDropDownClick()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@class='ngx-select__item dropdown-item ng-star-inserted'])[1]")));
        return click;
    }
    @FindBy(xpath = "//textarea[@formcontrolname='newRemark']")
    WebElement remarknew;
    public WebElement getRemarkNew()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@formcontrolname='newRemark']")));
        return remarknew;
    }
    @FindBy(xpath = "//mat-icon[text()='close']")
    WebElement closeapplicationid;
    public WebElement getCloseApplicationId()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//mat-icon[text()='close']")));
        return closeapplicationid;
    }
    @FindBy(xpath = "//span[text()='Upload']")
    WebElement uploaddocument;
    public WebElement getUpoadDocument()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Upload']")));
        return uploaddocument;
    }
    @FindBy(xpath = "//input[@type='file']")
    WebElement choosefile;
    public WebElement getChooseFile()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='file']")));
        return choosefile;
    }
    @FindBy(xpath = "//th[text()=' Nearest supporting Outlets ']")
    WebElement text;
    public WebElement getText()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th[text()=' Nearest supporting Outlets ']")));
        return text;
    }
    @FindBy(xpath = "//div[@class='modal-body flex-wrap d-flex justify-content-center ng-star-inserted']")
    WebElement quickloanfields;
    public WebElement getQuickLaonFields()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='modal-body flex-wrap d-flex justify-content-center ng-star-inserted']")));
        return quickloanfields;
    }
    @FindBy(xpath = "//form[@class='ng-untouched ng-pristine ng-invalid']")
    WebElement formelement;
    public WebElement getFormElement()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//form[@class='ng-untouched ng-pristine ng-invalid']")));
        return formelement;
    }
    @FindBy(xpath = "//div[@class='card-body']")
    WebElement formverification;
    public WebElement getFormverification()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='card-body']")));
        return formverification;
    }
    @FindBy(xpath = "//p[text()='Grievance Officer: Mr. Amrish Krishnan']")
    WebElement term;
    public WebElement getTerm()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[text()='Grievance Officer: Mr. Amrish Krishnan']")));
        return term;
    }
    @FindBy(xpath = "//app-consent[@id='modelElement']")
    WebElement termdisplaypage;
    public WebElement getTermDisplayPage()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//app-consent[@id='modelElement']")));
        return termdisplaypage;
    }
    @FindBy(xpath = "(//button[text()=' Resend OTP '])[1]")
    WebElement resend;
    public WebElement getResendOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Resend OTP '])[1]")));
        return resend;
    }
    @FindBy(xpath = "//span[text()='Please enter a valid mobile number']")
    WebElement verifymobilenumber;
    public WebElement getVerifyMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Please enter a valid mobile number']")));
        return verifymobilenumber;
    }
    @FindBy(xpath = "//div[@id='swal2-content']")
    WebElement alter;
    public WebElement getAlter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='swal2-content']")));
        return alter;
    }
    @FindBy(xpath = "(//label[text()='Enter Mobile Number'])[1]")
    WebElement label;
    public WebElement getLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Enter Mobile Number'])[1]")));
        return label;
    }
    @FindBy(xpath = "(//span[@class='text-danger ng-star-inserted'])[1]")
    WebElement mobilealter;
    public WebElement getMobileAlter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='text-danger ng-star-inserted'])[1]")));
        return mobilealter;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[14]")
    WebElement appid;
    public WebElement getAppID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='ng-star-inserted'])[14]")));
        return appid;
    }
    @FindBy(xpath = "(//label[text()='First Name'])[1]")
    WebElement firstnamelabel;
    public WebElement getFirstNameLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='First Name'])[1]")));
        return firstnamelabel;
    }
    @FindBy(xpath = "(//label[text()='Last Name'])[1]")
    WebElement lastnamelabel;
    public WebElement getLastNameLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Last Name'])[1]")));
        return lastnamelabel;
    }
    @FindBy(xpath = "(//span[@class='text-danger ng-star-inserted'])[2]")
    WebElement lastverificatonlabel;
    public WebElement getLastNameVerification()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")));
        return lastnameverification;
    }
    @FindBy(xpath = "(//input[@formcontrolname='dob'])[1]")
    WebElement dateofbirth;
    public WebElement getDateOfBirth()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='dob'])[1]")));
        return dateofbirth;
    }
    @FindBy(xpath = "(//label[text()='Pan Number'])[1]")
    WebElement panlabel;
    public WebElement getPanLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Pan Number'])[1]")));
        return panlabel;
    }
    @FindBy(xpath = "(//button[text()=' Save and Next '])[1]")
    WebElement quicksaveandnext;
    public WebElement getSaveAndNextButton()
    {
      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[text()=' Save and Next '])[1]")));
      return quicksaveandnext;
    }
    @FindBy(xpath = "(//label[text()='Pincode'])[1]")
    WebElement pincodelabel;
    public WebElement getPincodeLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Pincode'])[1]")));
        return pincodelabel;
    }
    @FindBy(xpath = "(//label[text()='Net Monthly Income'])[1]")
    WebElement netincomelabel;
    public WebElement getNetIcomeLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Net Monthly Income'])[1]")));
        return netincomelabel;
    }
    @FindBy(xpath = "(//div[@class='form-check mb-1'])[1]")
    WebElement occuption;
    public WebElement getOccuption()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='form-check mb-1'])[1]")));
        return occuption;
    }
    @FindBy(xpath = "//input[@formcontrolname='loanAmount']")
    WebElement laonamount;
    public WebElement getLaonAmount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='loanAmount']")));
        return loanamount;
    }
    @FindBy(xpath = "(//input[@name='loanAmount'])[1]")
    WebElement quickloanamount;
    public WebElement getQuickLoanAmount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='loanAmount'])[1]")));
        return quickloanamount;
    }
    @FindBy(xpath = "//input[@placeholder='Sent To']")
    WebElement sentmobilenumber;
    public WebElement getSendMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Sent To']")));
        return sentmobilenumber;
    }
    @FindBy(xpath = "(//input[@formcontrolname='netMonthlyIncome'])[1]")
    WebElement netsalary;
    public WebElement getNetSalary()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='netMonthlyIncome'])[1]")));
        return netsalary;
    }
    @FindBy(xpath = "(//input[@formcontrolname='loanAmount'])[1]")
    WebElement requiredloanamount;
    public WebElement getRequiredLoanAmount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='loanAmount'])[1]")));
        return requiredloanamount;
    }
    @FindBy(xpath = "(//input[@formcontrolname='loanAmount'])[2]")
    WebElement laonamt;
    public WebElement getLoanAmt()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@formcontrolname='loanAmount'])[2]")));
        return laonamt;
    }
    @FindBy(xpath = "(//button[text()=' Send OTP '])[2]")
    WebElement sentotp;
    public WebElement getSentOTP()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Send OTP '])[2]")));
        return sentotp;
    }
    @FindBy(xpath = "(//label[text()='Email'])[1]")
    WebElement emaillabel;
    public WebElement getEmailLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Email'])[1]")));
        return emaillabel;
    }
    @FindBy(xpath = "(//button[text()=' Send OTP '])[2]")
    WebElement verifysendOTP;
    public WebElement getVerifysendOTP()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[text()=' Send OTP '])[2]")));
        return verifysendOTP;
    }
    @FindBy(xpath = "(//div[@class='col-12 col-md-7 col-lg-5 m-auto DetailsSection'])[2]")
    WebElement personaldetail;
    public WebElement getPersonalDetail()
    {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='col-12 col-md-7 col-lg-5 m-auto DetailsSection'])[2]")));
        return personaldetail;
    }
    @FindBy(xpath = "(//input[@name='officePincode'])[1]")
    WebElement offpin;
    public WebElement getOffiPin()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@name='officePincode'])[1]")));
        return offpin;
    }

    @FindBy(xpath = "(//span[text()='Please enter valid pincode'])[1]")
    WebElement validpin;
    public WebElement getValidPin()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='Please enter valid pincode'])[1]")));
        return validpin;
    }
    @FindBy(xpath = "(//label[text()='Office Pincode'])[1]")
    WebElement officepincodelabel;
    public WebElement getOfficePinCodeLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Office Pincode'])[1]")));
        return officepincodelabel;
    }
    @FindBy(xpath = "(//div[@class='col-12 text-center'])[2]")
    WebElement divmainotp;
    public WebElement getDivMainOTP()
    {
      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='col-12 text-center'])[2]")));
      return divmainotp;
    }
    @FindBy(xpath = "(//label[text()='Loan Amount'])[1]")
    WebElement loanamtlabel;
    public WebElement getLoanAmountLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[text()='Loan Amount'])[1]")));
        return loanamtlabel;
    }
    @FindBy(xpath = "//input[@name='DOB']")
    WebElement DateOB;
    public WebElement getDateofBirth()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='DOB']")));
        return DateOB;
    }
    @FindBy(xpath = "//input[@placeholder='loanAmount']")
    WebElement loan;
    public WebElement getLoan()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='loanAmount']")));
    return loan;
    }
    @FindBy(xpath = "//a[text()=' White label partner ']")
    WebElement whitelabel;
    public WebElement getWhiteLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' White label partner ']")));
        return whitelabel;
    }
    @FindBy(xpath = "//div[@class='ng-star-inserted']")
    WebElement whitelabelonboaring;
    public WebElement getWhiteLabelOnBoarding()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='ng-star-inserted']")));
        return whitelabelonboaring;
    }
    @FindBy(xpath = "//button[text()='Verify']")
    WebElement whitelabelverify;
    public WebElement getWhiteLabelVerify()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Verify']")));
        return whitelabelverify;
    }
    @FindBy(xpath = "//input[@placeholder='Merchant Id']")
    WebElement Merchantinput;
    public WebElement getMerchantInput()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Merchant Id']")));
        return Merchantinput;
    }
    @FindBy(xpath = "//span[text()='x']")
    WebElement merchantclose;
    public WebElement getMerchantClose()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='x']")));
        return merchantclose;
    }
    @FindBy(xpath = "//a[text()=' Merchants List ']")
    WebElement Merchant_List;
    public WebElement getMerchant_List()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Merchants List ']")));
        return Merchant_List;
    }
    @FindBy(xpath = "//div[@class='page-title-subheading']")
    WebElement customername;
    public WebElement getCustomerName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='page-title-subheading']")));
        return customername;
    }
    @FindBy(xpath = "(//span[@class='mat-button-wrapper'])[4]")
    WebElement finalprivousbutton;
    public WebElement getFinalPrivousButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='mat-button-wrapper'])[4]")));
        return finalprivousbutton;
    }
    @FindBy(xpath = "(//span[@class='mat-button-wrapper'])[2]")
    WebElement middlepreviousbutton;
    public WebElement getMiddlepreviousbutton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='mat-button-wrapper'])[2]")));
        return middlepreviousbutton;
    }
    @FindBy(xpath = "(//span[@class='mat-button-wrapper'])[3]")
    WebElement middlenextbutton;
    public WebElement getMiddlenextbutton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='mat-button-wrapper'])[3]")));
        return middlenextbutton;
    }
    @FindBy(xpath = "//div[@class='mat-select-arrow-wrapper']")
    WebElement rangearrow;
    public WebElement getRangearrow()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='mat-select-arrow-wrapper']")));
        return rangearrow;
    }
    @FindBy(xpath = "//a[text()=' Merchant Promotions ']")
    WebElement merchant_promotion;
    public WebElement getMerchantPromotion()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Merchant Promotions ']")));
        return merchant_promotion;
    }
    @FindBy(xpath = "//div[text()=' Merchant Promotions ']")
    WebElement merchant_Promotions;
    public WebElement getMechant_Promotions()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()=' Merchant Promotions ']")));
        return merchant_Promotions;
    }
    @FindBy(xpath = "//a[text()=' Self Onboarding QR Code ']")
    WebElement self_onboarding_QR_code;
    public WebElement getSelf_Onboarding_QR_Code()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Self Onboarding QR Code ']")));
        return self_onboarding_QR_code;
    }
    @FindBy(xpath = "//div[text()=' Merchant Onboarding - Generate QR Code ']")
    WebElement merchanronboardingtext;
    public WebElement getMerchant_Onboarding_text()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()=' Merchant Onboarding - Generate QR Code ']")));
        return merchanronboardingtext;
    }
    @FindBy(xpath = "//span[text()='--Select Merchant--']")
    WebElement select_Merchant;
    public WebElement getSelect_Merchant()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='--Select Merchant--']")));
        return select_Merchant;
    }
    @FindBy(xpath = "//input[@class='select2-search__field']")
    WebElement Merchant_name_Entered;
    public WebElement get_Merchant_Name_Entered()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class='select2-search__field']")));
        return Merchant_name_Entered;
    }
    @FindBy(xpath = "//select[@formcontrolname='Merchant']")
    WebElement selectoptions;
    public WebElement getSelectOptions()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='Merchant']")));
        return selectoptions;
    }
    @FindBy(xpath = "//input[@formcontrolname='URL']")
    WebElement blankurl;
    public WebElement getBlankURL()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='URL']")));
        return blankurl;
    }
    @FindBy(xpath = "//div[@id='swal2-content']")
    WebElement copyalter;
    public WebElement getCopyAlter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='swal2-content']")));
        return copyalter;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_mobile_0']")
    WebElement fpo_Mobilenumber;
    public WebElement get_FPO_Mobilenumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_mobile_0']")));
        return fpo_Mobilenumber;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_email_1']")
    WebElement fpo_Email_id;
    public WebElement get_FPO_EmailID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_email_1']")));
        return fpo_Email_id;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_firstName_2']")
    WebElement fpo_firstname;
    public WebElement get_FPO_FirstName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_firstName_2']")));
        return fpo_firstname;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_lastName_3']")
    WebElement fpo_lastname;
    public WebElement get_FPO_Lastname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_lastName_3']")));
        return fpo_lastname;
    }
    @FindBy(xpath = "//input[@id='dob-id']")
    WebElement fpo_DOB;
    public WebElement get_FPO_DOB()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='dob-id']")));
        return fpo_DOB;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_panCard_5']")
    WebElement fpo_PAN_Number;
    public WebElement get_FPO_PAN_Number()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_panCard_5']")));
        return fpo_PAN_Number;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_residencePinCode_6']")
    WebElement residence_pincode;
    public WebElement get_Residence_Pincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_residencePinCode_6']")));
        return residence_pincode;
    }
    @FindBy(xpath = "//input[@id='formly_9_input_officePinCode_7']")
    WebElement fpo_officepincode;
    public WebElement get_FPO_OfficePincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_9_input_officePinCode_7']")));
        return fpo_officepincode;
    }
    @FindBy(xpath = "//a[text()=' Bank Selection Q ']")
    WebElement bankselection;
    public WebElement get_Bank_Selction_Q()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Bank Selection Q ']")));
        return bankselection;
    }
    @FindBy(xpath = "(//button[@type='submit'])[3]")
    WebElement submitbankselectionQ;
    public WebElement getSubmitBankSelectionQ()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[@type='submit'])[3]")));
        return submitbankselectionQ;
    }
    @FindBy(xpath = "//button[text()='Call']")
    WebElement callbutton;
    public WebElement getCallButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Call']")));
        return callbutton;
    }
    @FindBy(xpath = "//button[text()=' Decline ']")
    WebElement decline;
    public WebElement getDeclineButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Decline ']")));
        return decline;
    }
    @FindBy(xpath = "//select[@formcontrolname='declinereason']")
    WebElement declinereason;
    public WebElement getDeclineReason()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='declinereason']")));
        return declinereason;
    }
    @FindBy(xpath = "//button[text()='Submit']")
    WebElement declinereasonsubmitbutton;
    public WebElement getDeclineReasonSubmitButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Submit']")));
        return declinereasonsubmitbutton;
    }
    @FindBy(xpath = "//button[text()=' Diarise ']")
    WebElement diarisebutton;
    public WebElement getDiariseButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Diarise ']")));
        return diarisebutton;
    }
    @FindBy(xpath = "//textarea[@id='comment']")
    WebElement comment;
    public WebElement getComment()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@id='comment']")));
        return comment;
    }
    @FindBy(xpath = "//a[text()=' Diarise Queue ']")
    WebElement diarisequeue;
    public WebElement getDiariseQueue()
    {
       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Diarise Queue ']")));
       return diarisequeue;
    }
    @FindBy(xpath = "//button[text()=' Customer Not Interested ']")
    WebElement customernotinterestedbutton;
    public WebElement getCustomerNotInterestedButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Customer Not Interested ']")));
        return customernotinterestedbutton;
    }
    @FindBy(xpath = "//button[text()='Cancel']")
    WebElement cancelbutton;
    public WebElement getCancelButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Cancel']")));
        return cancelbutton;
    }
    @FindBy(xpath = "//a[text()=' Reverse File Upload ']")
    WebElement reversefileupload;
    public WebElement get_Reverse_File_Upload_Option()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' Reverse File Upload ']")));
        return reversefileupload;
    }
    @FindBy(xpath = "//div[@id='customerQDR']")
    WebElement reversefilepage;
    public WebElement getReverseFilePage()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='customerQDR']")));
        return reversefilepage;
    }
    @FindBy(xpath = "(//mat-icon[text()='remove_red_eye'])[1]")
    WebElement viewbutton;
    public WebElement getViewButtonIcon()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='remove_red_eye'])[1]")));
        return viewbutton;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[11]")
    WebElement viewrecordcount;
    public WebElement getViewRecordCount()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='ng-star-inserted'])[11]")));
        return viewrecordcount;
    }
    @FindBy(xpath = "//button[@title='Refresh list']")
    WebElement refreshbutton;
    public WebElement getRefeshButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Refresh list']")));
        return refreshbutton;
    }
    @FindBy(xpath = "//input[@placeholder='UploadedBy']")
    WebElement uploadbyinput;
    public WebElement getUploadByInput()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='UploadedBy']")));
        return uploadbyinput;
    }
    @FindBy(xpath = "//a[text()=' API Trigger ']")
    WebElement apitrigger;
    public WebElement getAPITiggerOption()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()=' API Trigger ']")));
        return apitrigger;
    }
    @FindBy(xpath = "//input[@value='yes']")
    WebElement yesradiobutton;
    public WebElement getYesRadioButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='yes']")));
        return yesradiobutton;
    }
    @FindBy(xpath = "//button[text()='Upload ']")
    WebElement uploadfileButton;
    public WebElement getUploadFileButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Upload ']")));
        return uploadfileButton;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[5]")
    WebElement datetime;
    public WebElement getDateTime()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='ng-star-inserted'])[5]")));
        return datetime;
    }
    @FindBy(xpath = "//input[@placeholder='Bulk Upload Count']")
    WebElement searchbulkuploadcount;
    public WebElement getSearchBulkUploadCount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Bulk Upload Count']")));
        return searchbulkuploadcount;
    }
    @FindBy(xpath = "//td[@class='records mat-cell cdk-column-bulkUploadCount mat-column-bulkUploadCount ng-star-inserted']")
    WebElement samebulkcount;
    public WebElement getSameBulkCount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@class='records mat-cell cdk-column-bulkUploadCount mat-column-bulkUploadCount ng-star-inserted']")));
        return samebulkcount;
    }
    @FindBy(xpath = "(//button[@class='mat-raised-button mat-primary'])[1]")
    WebElement exportbutton;
    public WebElement getExportbutton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class='mat-raised-button mat-primary'])[1]")));
        return exportbutton;
    }
    @FindBy(xpath = "//input[@value='no']")
    WebElement selectno;
    public WebElement getSelectNo()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='no']")));
        return selectno;
    }
    @FindBy(xpath = "(//div[@class='ng-star-inserted'])[2]")
    WebElement selectpartner;
    public WebElement getSelectPartner()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='ng-star-inserted'])[2]")));
        return selectpartner;
    }
    @FindBy(xpath = "(//div[@class='ng-star-inserted'])[3]")
    WebElement selectpartner2;
    public WebElement getSelectPartner2()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='ng-star-inserted'])[3]")));
        return selectpartner2;
    }
    @FindBy(xpath = "//button[text()=' Previous ']")
    WebElement previous;
    public WebElement getPreviousButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Previous ']")));
        return previous;
    }
    @FindBy(xpath = "//div[@class='ngx-select__selected ng-star-inserted']")
    WebElement datacollectionsearch;
    public WebElement getDataCollectionSearch()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ngx-select__selected ng-star-inserted']")));
        return datacollectionsearch;
    }
    @FindBy(xpath = "//ul[@class='ngx-select__choices dropdown-menu ng-star-inserted show']")
    WebElement searchdropdown;
    public WebElement getSearchDropDown()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@class='ngx-select__choices dropdown-menu ng-star-inserted show']")));
        return searchdropdown;
    }
    @FindBy(xpath = "//button[@class='mat-icon-button']")
    WebElement togglebutton;
    public WebElement getToggleButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='mat-icon-button']")));
        return togglebutton;
    }
    @FindBy(xpath = "(//mat-icon[text()='refresh'])[1]")
    WebElement togglerefreshbutton;
    public WebElement getToggleRefreshButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//mat-icon[text()='refresh'])[1]")));
        return togglerefreshbutton;
    }
    @FindBy(xpath = "//div[@class='la-ball-scale-ripple-multiple la-3x']")
    WebElement refreshbuffer;
    public WebElement getRefreshBuffer()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='la-ball-scale-ripple-multiple la-3x']")));
        return refreshbuffer;
    }
    @FindBy(xpath = "//input[@formcontrolname='pinCode']")
    WebElement currentpincode;
    public WebElement getCurrentPincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='pinCode']")));
        return currentpincode;
    }
    @FindBy(xpath = "//input[@formcontrolname='currentPermanentSame']")
    WebElement currentpermanentsame;
    public WebElement getCurrentpermanentsame()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@formcontrolname='currentPermanentSame']")));
        return currentpermanentsame;
    }
    @FindBy(xpath = "//span[@class='text-danger ng-star-inserted']")
    WebElement getreferencemsg;
    public WebElement getReferenceMSG()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='text-danger ng-star-inserted']")));
        return getreferencemsg;
    }
    @FindBy(xpath = "//textarea[@formcontrolname='oldRemark']")
    WebElement oldremark;
    public WebElement getOldRemark()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@formcontrolname='oldRemark']")));
        return oldremark;
    }
    @FindBy(xpath = "//button[text()=' Bank Selection ']")
    WebElement bankselectionbutton;
    public WebElement gerBankSelectionButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Bank Selection ']")));
        return bankselectionbutton;
    }
    @FindBy(xpath = "//button[text()=' Save ']")
    WebElement datacollectionqueuesubmit;
    public WebElement getDataCollectionQueueSubmit()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()=' Save ']")));
        return datacollectionqueuesubmit;
    }
    @FindBy(xpath = "//span[@class='mat-button-wrapper']")
    WebElement elipsis;
    public WebElement getElipsis()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='mat-button-wrapper']")));
        return elipsis;
    }
    @FindBy(xpath = "//div[@class='bs-datepicker-container ng-trigger ng-trigger-datepickerAnimation']")
    WebElement datedisplay;
    public WebElement getDateDisplay()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='bs-datepicker-container ng-trigger ng-trigger-datepickerAnimation']")));
        return datedisplay;
    }
    @FindBy(xpath = "//input[@placeholder='From Date']")
    WebElement formdate;
    public WebElement getFromDate()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='From Date']")));
        return formdate;
    }
    @FindBy(xpath = "//input[@placeholder='To Date']")
    WebElement todate;
    public WebElement getToDate()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='To Date']")));
        return todate;
    }
    @FindBy(xpath = "(//input[@type='radio'])[1]")
    WebElement both_status;
    public WebElement getBoth_status()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//input[@type='radio'])[1]")));
        return both_status;
    }
    @FindBy(xpath = "(//input[@type='radio'])[2]")
    WebElement yes_status;
    public WebElement getYes_Status()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='radio'])[2]")));
        return yes_status;
    }
    @FindBy(xpath = "(//input[@type='radio'])[3]")
    WebElement no_status;
    public WebElement getNo_status()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@type='radio'])[3]")));
        return no_status;
    }
    @FindBy(xpath = "//input[@id='formly_21_input_firstName_1']")
    WebElement microfirstname;
    public WebElement getMicroFirstname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_21_input_firstName_1']")));
        return microfirstname;
    }
    @FindBy(xpath = "//input[@id='formly_21_input_lastName_2']")
    WebElement microlastname;
    public WebElement gerMicroLastname()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_21_input_lastName_2']")));
        return microlastname;
    }
    @FindBy(xpath = "//select[@id='formly_21_select_loanAppliedFor_3']")
    WebElement microloanappliedfor;
    public WebElement getMicroLoanAppliedFor()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='formly_21_select_loanAppliedFor_3']")));
        return microloanappliedfor;
    }
    @FindBy(xpath = "//select[@id='formly_21_select_loan2AppliedFor_4']")
    WebElement secondloan;
    public WebElement getSecondLoan()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='formly_21_select_loan2AppliedFor_4']")));
        return secondloan;
    }
    @FindBy(xpath = "//input[@id='formly_21_input_mobile_6']")
    WebElement micromobileno;
    public WebElement getMicroMobileNo()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_21_input_mobile_6']")));
        return micromobileno;
    }
    @FindBy(xpath = "//input[@id='formly_21_input_alternateMobile_7']")
    WebElement microalternatemobilenumber;
    public WebElement getmicroalternatemobilenumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_21_input_alternateMobile_7']")));
        return microalternatemobilenumber;

    }
    @FindBy(xpath = "//input[@placeholder='Bank Name']")
    WebElement bank_name;
    public WebElement getMicor_Bank_Name()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder='Bank Name']")));
        return bank_name;
    }
    @FindBy(xpath = "//button[@class='close']")
    WebElement button_close;
    public WebElement getButton_close()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='close']")));
        return button_close;
    }
    @FindBy(xpath = "//button//span//mat-icon[text()='more_vert']")
    WebElement threeDotButton;
    public WebElement getThreeDotButton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button//span//mat-icon[text()='more_vert']")));
        return threeDotButton;
    }
    @FindBy(xpath = "//div[@class='MerchantDetails ng-star-inserted']//child::h4")
    WebElement appIdOnBankSQ;
    public WebElement getappIdOnBankSQ()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='MerchantDetails ng-star-inserted']//child::h4")));
        return appIdOnBankSQ;
    }

    @FindBy(xpath = "//div[@class='d-flex align-items-baseline flex-wrap']//child::label")
    WebElement merchantDetails;
    public WebElement getmerchantDetails()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='d-flex align-items-baseline flex-wrap']//child::label")));
        return merchantDetails;
    }

    @FindBy(xpath = "//div[@class='d-flex flex-wrap align-items-center']//child::p")
    WebElement merchantDetailsName;
    public WebElement getmerchantDetailsName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='d-flex flex-wrap align-items-center']//child::p")));
        return merchantDetailsName;
    }

    @FindBy(xpath = " //div[@class='d-flex align-item-center mt-1 mt-md-0 berouScore']//child::label")
    WebElement BuraueScrore;
    public WebElement getBuraueScrore()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(" //div[@class='d-flex align-item-center mt-1 mt-md-0 berouScore']//child::label")));
        return BuraueScrore;
    }

    @FindBy(xpath = "//div[@class='d-flex align-item-center mt-1 mt-md-0 berouScore']//child::p")
    WebElement BuraueScroreNumber;
    public WebElement getBuraueScroreNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(" //div[@class='d-flex align-item-center mt-1 mt-md-0 berouScore']//child::label")));
        return BuraueScroreNumber;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_firstName_1']")
    WebElement firstName;
    public WebElement getfirstName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(" //input[@id='formly_11_input_firstName_1']")));
        return firstName;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_lastName_2']")
    WebElement lastName;
    public WebElement getlastName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_lastName_2']")));
        return lastName;
    }


    @FindBy(xpath = "//input[@id='formly_11_input_DOB_3']")
    WebElement DOB;
    public WebElement getDOB1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_DOB_3']")));
        return DOB;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_mobile_4']")
    WebElement MobileNumber;
    public WebElement getMobileNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_mobile_4']")));
        return MobileNumber;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_panNumber_5']")
    WebElement panNumber;
    public WebElement getpanNumber()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_panNumber_5']")));
        return panNumber;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_occupation_6']")
    WebElement occupation1;
    public WebElement getoccupation1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_occupation_6']")));
        return occupation1;
    }

    @FindBy(xpath = "//select[@id='formly_11_select_loanAppliedFor_7']")
    WebElement LoanApplied;
    public WebElement getLoanApplied()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='formly_11_select_loanAppliedFor_7']")));
        return LoanApplied;
    }

    @FindBy(xpath = "//select[@id='formly_11_select_loan2AppliedFor_8']")
    WebElement LoanApplied2;
    public WebElement getLoanApplied2()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='formly_11_select_loan2AppliedFor_8']")));
        return LoanApplied2;
    }

    @FindBy(xpath = "//input[@id='formly_11_input_pincode_9']")
    WebElement pincode1;
    public WebElement getpincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='formly_11_input_pincode_9']")));
        return pincode1;
    }


    @FindBy(xpath = "//h5[text()=' Additional Data Required ']")
    WebElement additionDataText;
    public WebElement getadditionDataText()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h5[text()=' Additional Data Required ']")));
        return additionDataText;
    }

    @FindBy(xpath = "//select[@formcontrolname='gender']")
    WebElement gender;
    public WebElement getBankQGender()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='gender']")));
        return gender;
    }

    @FindBy(xpath = "//input[@formcontrolname='currentAddress']\n")
    WebElement currentAddress;
    public WebElement getBankQcurrentAddress()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='currentAddress']")));
        return currentAddress;
    }
    @FindBy(xpath = "//input[@formcontrolname='email']")
    WebElement email;
    public WebElement getBankQemailID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='currentAddress']")));
        return email;
    }

    @FindBy(xpath = "//input[@formcontrolname='loanAmount']")
    WebElement LoanAmt;
    public WebElement getBankQLoanAmt()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='loanAmount']")));
        return LoanAmt;
    }

    @FindBy(xpath = "//input[@formcontrolname='netMonthlyIncome']")
    WebElement monthlyIncome;
    public WebElement getBankQmonthlyIncome()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='netMonthlyIncome']")));
        return monthlyIncome;
    }

    @FindBy(xpath = "//select[@formcontrolname='isNetBankingAvailable']")
    WebElement IsNetBankingAvailable;
    public WebElement getBankQIsNetBankingAvailable()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
        return IsNetBankingAvailable;
    }

    @FindBy(xpath = "//select[@formcontrolname='isSalaryAccountAvailable']")
    WebElement IsYourSalaryCreditedInBankAccount;
    public WebElement getBankQIsYourSalaryCreditedInBankAccount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        return IsYourSalaryCreditedInBankAccount;
    }

    @FindBy(xpath = "//select[@formcontrolname='isSalarySlipAvailable']")
    WebElement DoYouHaveSalarySlipOrSalaryCertificate;
    public WebElement getBankQDoYouHaveSalarySlipOrSalaryCertificate()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        return DoYouHaveSalarySlipOrSalaryCertificate;
    }
    @FindBy(xpath = "//input[@formcontrolname='officePincode']")
    WebElement officePincode;
    public WebElement getBankQofficePincode()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='officePincode']")));
        return officePincode;
    }
    @FindBy(xpath = "//button[text()=' Previous ']")
    WebElement previousbutton1;
    public WebElement getPreviousbutton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Previous ']")));
        return previousbutton1;
    }

    @FindBy(xpath = "//button[text()=' Next ']")
    WebElement nextbutton1;
    public WebElement getNextButton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Next ']")));
        return nextbutton1;
    }

    @FindBy(xpath = "//button[text()=' Send OTP ']")
    WebElement sendotp1;
    public WebElement getSendotp1() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Send OTP ']")));
        return sendotp1;
    }
    @FindBy(xpath = "//button[text()='Call']")
    WebElement callbutton1;
    public WebElement getCallButton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Call']")));
        return callbutton1;
    }
    @FindBy(xpath = "//button[text()='Send OTP']")
    WebElement instasendotpbutton;
    public WebElement getInstaSendOTPButton()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Send OTP']")));
        return instasendotpbutton;
    }
    @FindBy(xpath = "//button[text()=' Decline ']")
    WebElement decline1;
    public WebElement getDeclineButton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Decline ']")));
        return decline1;
    }

    @FindBy(xpath = "//button[text()=' Submit ']")
    WebElement submitmicro1;
    public WebElement getSumbitMicro1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Submit ']")));
        return submitmicro1;
    }

    @FindBy(xpath = "//button[text()=' Diarise ']")
    WebElement diarisebutton1;
    public WebElement getDiariseButton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Diarise ']")));
        return diarisebutton1;
    }
    @FindBy(xpath = "//button[text()=' Customer Not Interested ']")
    WebElement customernotinterestedbutton1;
    public WebElement getCustomerNotInterestedButton1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Customer Not Interested ']")));
        return customernotinterestedbutton1;
    }
    @FindBy(xpath = "//app-auto-complete-dropdown[@placeholdertext='Search for applications here']")
    WebElement searchID1;
    public WebElement getsearchID1()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//app-auto-complete-dropdown[@placeholdertext='Search for applications here']")));
        return searchID1;
    }

    @FindBy(xpath = "//input[@class='ngx-select__search form-control ng-star-inserted']")
    WebElement searchIDInput;
    public WebElement getsearchIDInput()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class='ngx-select__search form-control ng-star-inserted']")));
        return searchIDInput;
    }

    @FindBy(xpath = "//div[@class='mat-menu-content']//child::span")
    List<WebElement> toggelButtonOptionName;
    public List<WebElement> gettoggelButtonOptionName()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='mat-menu-content']//child::span")));
        return toggelButtonOptionName;
    }

    @FindBy(xpath = "//p[text()='Bank Selection Queue']")
    WebElement pageTitle;
    public WebElement getpageTitle()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Bank Selection Queue']")));
        return pageTitle;
    }

    @FindBy(xpath = "//input[ @placeholder='Search for applications here']")
    WebElement EnterSearchID;
    public WebElement getEnterSearchID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[ @placeholder='Search for applications here']")));
        return EnterSearchID;
    }
    @FindBy(xpath = "//ul[@role='menu']/child::li")
    List<WebElement> ApplicationIDsList;
    public List<WebElement> getApplicationIDsList()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']/child::li")));
        return  ApplicationIDsList;
    }

    @FindBy(xpath = "//div[@id='swal2-content']")
    WebElement OTPSentMessage;
    public WebElement getOTPSentMessage()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='swal2-content']")));
        return OTPSentMessage;
    }


    @FindBy(xpath = "//div[@class='swal2-popup swal2-modal swal2-show']//div[@class='swal2-actions']/button[text()='Close']")
    WebElement acceptOTPAlert;
    public WebElement getacceptOTPAlert()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='swal2-popup swal2-modal swal2-show']//div[@class='swal2-actions']/button[text()='Close']")));
        return acceptOTPAlert;
    }

    @FindBy(xpath = "//input[@formcontrolname='otp']")
    WebElement enterOTPField;
    public WebElement getenterOTPField()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@formcontrolname='otp']")));
        return enterOTPField;
    }


    @FindBy(xpath = "//button[contains(text(),'Verify OTP')]")
    WebElement verfiyOTPButton;
    public WebElement getverfiyOTPButton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Verify OTP')]")));
        return verfiyOTPButton;
    }

    @FindBy(xpath = "//div[@class='position-relative']//mat-icon[text()='visibility_off']")
    WebElement maskIcon;
    public WebElement getmaskIcon()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='position-relative']//mat-icon[text()='visibility_off']")));
        return maskIcon;
    }

    @FindBy(xpath = "//span[@class='text-danger ng-star-inserted']")
    WebElement errorMsg;
    public WebElement geterrorMsg()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='text-danger ng-star-inserted']")));
        return errorMsg;
    }
    @FindBy(xpath = "//a[text()=' Bank Selection Q ']")
    WebElement SelectionBankQ;
    public WebElement getSelectionBankQ()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()=' Bank Selection Q ']")));
        return SelectionBankQ;
    }
    @FindBy(xpath = "//button[text()='Submit']")
    WebElement DeclineDisplayButton;
    public WebElement getDeclineDisplayButton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Submit']")));
        return DeclineDisplayButton;
    }
    @FindBy(xpath = "(//span[@class='mat-button-wrapper'])[1]")
    WebElement DCQToggle;
    public WebElement getDCQToggleButton()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='mat-button-wrapper'])[1]")));
        return DCQToggle;
    }
    @FindBy(xpath = "(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[2]")
    WebElement bankstatusfinalstatus;
    public WebElement getBankstatusfinalstatus()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[2]")));
        return bankstatusfinalstatus;
    }
    @FindBy(xpath = "(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[3]")
    WebElement bankstatustotalDisburedAmount;
    public WebElement getBankstatustotalDisburedAmount()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[3]")));
        return bankstatustotalDisburedAmount;
    }
    @FindBy(xpath = "(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[1]")
    WebElement bankstatusApplicationId;
    public WebElement getBankStatusApplicationID()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[1]")));
        return bankstatusApplicationId;
    }
    @FindBy(xpath = "//tr[@class='mat-row ng-star-inserted']")
    WebElement bankInsrtedRow;
    public WebElement getBankInsrtedRow()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[@class='mat-row ng-star-inserted']")));
        return bankInsrtedRow;
    }
    @FindBy(xpath = "//select[@formcontrolname='salutation']")
    WebElement salutation1;
    public WebElement getSalutation()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@formcontrolname='salutation']")));
        return salutation1;
    }

  ///  ************************************************************************************************************************
  @FindBy(xpath = "//select[@formcontrolname='salutation']")
  WebElement datacollectionSalutation;

    public WebElement getDataCollectionSalutation() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@formcontrolname='salutation']")));
        return datacollectionSalutation;
    }

    @FindBy(xpath = "//button[@aria-label='Example icon-button with a menu']")
    WebElement toggleButtonDCQ;

    public WebElement gettoggleButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@aria-label='Example icon-button with a menu']")));
        return toggleButtonDCQ;
    }

    @FindBy(xpath = "//input[@name='firstName']")
    WebElement firstNameDCQ;

    public WebElement getfirstNameDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='firstName']")));
        return firstNameDCQ;
    }

    @FindBy(xpath = "//input[@name='lastName']")
    WebElement lastNameDCQ;

    public WebElement getlastNameDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='lastName']")));
        return lastNameDCQ;
    }

    @FindBy(xpath = "//select[@name='loanAppliedFor']")
    WebElement loanAppliedForDCQ;

    public WebElement getloanAppliedForDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='loanAppliedFor']")));
        return loanAppliedForDCQ;
    }

    @FindBy(xpath = "//select[@name='loan2AppliedFor']")
    WebElement loan2AppliedForDCQ;

    public WebElement getloan2AppliedForDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='loan2AppliedFor']")));
        return loan2AppliedForDCQ;
    }

    @FindBy(xpath = "//input[@name='lastModifiedDate']")
    WebElement lastModifiedDateDCQ;

    public WebElement getlastModifiedDateDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='lastModifiedDate']")));
        return lastModifiedDateDCQ;
    }

    @FindBy(xpath = "//input[@name='mobile']")
    WebElement mobileDCQ;

    public WebElement getmobileDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='mobile']")));
        return mobileDCQ;
    }

    @FindBy(xpath = "//input[@name='alternateMobile']")
    WebElement alternateMobileDCQ;

    public WebElement getalternateMobileDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='alternateMobile']")));
        return alternateMobileDCQ;
    }

    @FindBy(xpath = "//select[@name='loanTenure']")
    WebElement loanTenureDCQ;

    public WebElement getloanTenureDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='loanTenure']")));
        return loanTenureDCQ;
    }

    @FindBy(xpath = "//select[@name='loanPurpose']")
    WebElement loanPurposeDCQ;

    public WebElement getloanPurposeDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='loanPurpose']")));
        return loanPurposeDCQ;
    }

    @FindBy(xpath = "//p[text()='Applicant Details']")
    WebElement applicant_DetailsHeaderDCQ;

    public WebElement getApplicant_DetailsHeaderDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Applicant Details']")));
        return applicant_DetailsHeaderDCQ;
    }

    @FindBy(xpath = "//input[@name='panCard']")
    WebElement panCardDCQ;

    public WebElement getpanCardDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='panCard']")));
        return panCardDCQ;
    }

    @FindBy(xpath = "//select[@name='gender']")
    WebElement genderDCQ;

    public WebElement getgenderDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='gender']")));
        return genderDCQ;
    }

    @FindBy(xpath = "//select[@name='maritalStatus']")
    WebElement maritalStatusDCQ;

    public WebElement getmaritalStatusDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='maritalStatus']")));
        return maritalStatusDCQ;
    }

    @FindBy(xpath = "//select[@name='noOfDependents']")
    WebElement noOfDependentsDCQ;

    public WebElement getnoOfDependentsDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='noOfDependents']")));
        return noOfDependentsDCQ;
    }


    @FindBy(xpath = "//input[@name='fatherName']")
    WebElement fatherNameDCQ;

    public WebElement getfatherNameDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='fatherName']")));
        return fatherNameDCQ;
    }

    @FindBy(xpath = "//input[@name='motherName']")
    WebElement motherNameDCQ;

    public WebElement getmotherNameDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='motherName']")));
        return motherNameDCQ;
    }

    @FindBy(xpath = "//p[text()='Current Residence Address']")
    WebElement current_Residence_AddressDCQ;

    public WebElement getCurrentResidenceAddressDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Current Residence Address']")));
        return current_Residence_AddressDCQ;
    }

    @FindBy(xpath = "//input[@name='addressLine1']")
    WebElement addressLine1DCQ;

    public WebElement getaddressLine1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='addressLine1']")));
        return addressLine1DCQ;
    }


    @FindBy(xpath = "//input[@name='addressLine2']")
    WebElement addressLine2DCQ;

    public WebElement getaddressLine2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='addressLine2']")));
        return addressLine2DCQ;
    }

    @FindBy(xpath = "//input[@name='addressLine3']")
    WebElement addressLine3DCQ;

    public WebElement getaddressLine3DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='addressLine3']")));
        return addressLine3DCQ;
    }

    @FindBy(xpath = "//input[@name='landmark']")
    WebElement landmark3DCQ;

    public WebElement getlandmarkDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='landmark']")));
        return landmark3DCQ;
    }

    @FindBy(xpath = "//input[@name='pinCode']")
    WebElement pinCodeDCQ;

    public WebElement getpinCodeDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='pinCode']")));
        return pinCodeDCQ;
    }

    @FindBy(xpath = "//select[@name='residenceType']")
    WebElement residenceTypeDCQ;

    public WebElement getresidenceTypeDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='residenceType']")));
        return residenceTypeDCQ;
    }

    @FindBy(xpath = "(//div[@class='ngx-select__toggle btn form-control'])[2]")
    WebElement residentialStateDCQ;

    public WebElement getresidentialStateDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[2]")));
        return residentialStateDCQ;
    }

    @FindBy(xpath = "(//div[@class='ngx-select__toggle btn form-control'])[3]")
    WebElement residentialCityDCQ;

    public WebElement getresidentialCityDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[3]")));
        return residentialCityDCQ;
    }

    @FindBy(xpath = "//select[@name='totalResidenceYears']")
    WebElement totalResidenceYearsDCQ;

    public WebElement gettotalResidenceYearsDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='totalResidenceYears']")));
        return totalResidenceYearsDCQ;
    }

    @FindBy(xpath = "//p[text()='Permanent Residence Address']")
    WebElement Permanent_Residence_AddressDCQ;

    public WebElement getPermanentResidenceAddressDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[text()='Permanent Residence Address']")));
        return Permanent_Residence_AddressDCQ;
    }

    @FindBy(xpath = "//input[@name='currentPermanentSame']")
    WebElement currentPermanentSameDCQ;

    public WebElement getcurrentPermanentSameDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='currentPermanentSame']")));
        return currentPermanentSameDCQ;
    }

    @FindBy(xpath = "//input[@name='officeAddressLine1']")
    WebElement officeAddressLine1DCQ;

    public WebElement getofficeAddressLine1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='officeAddressLine1']")));
        return officeAddressLine1DCQ;
    }

    @FindBy(xpath = "//input[@name='officeAddressLine2']")
    WebElement officeAddressLine2DCQ;

    public WebElement getofficeAddressLine2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='officeAddressLine1']")));
        return officeAddressLine2DCQ;
    }

    @FindBy(xpath = "//input[@name='officeLandmark']")
    WebElement officeLandmarkDCQ;

    public WebElement getofficeLandmarkDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='officeLandmark']")));
        return officeLandmarkDCQ;
    }

    @FindBy(xpath = "//select[@name='officeStateId']")
    WebElement officeStateIdDCQ;

    public WebElement getofficeStateIdDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='officeStateId']")));
        return officeStateIdDCQ;
    }

    @FindBy(xpath = "//select[@name='officeCityId']")
    WebElement officeCityIdDCQ;

    public WebElement getofficeCityIdDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='officeCityId']")));
        return officeCityIdDCQ;
    }

    @FindBy(xpath = "//input[@name='referenceName1']")
    WebElement referenceName1DCQ;

    public WebElement getreferenceName1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='referenceName1']")));
        return referenceName1DCQ;
    }

    @FindBy(xpath = "//input[@name='mobileOfReference1']")
    WebElement mobileOfReference1DCQ;

    public WebElement getmobileOfReference1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='mobileOfReference1']")));
        return mobileOfReference1DCQ;
    }

    @FindBy(xpath = "//input[@name='referenceAddress1']")
    WebElement referenceAddress1DCQ;
    public WebElement getreferenceAddress1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='referenceAddress1']")));
        return referenceAddress1DCQ;
    }

    @FindBy(xpath = "//select[@name='relationWith1Borrowe']")
    WebElement relationWith1BorroweDCQ;

    public WebElement getrelationWith1BorroweDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='relationWith1Borrowe']")));
        return relationWith1BorroweDCQ;
    }

    @FindBy(xpath = "//input[@name='referenceName2']")
    WebElement referenceName2DCQ;

    public WebElement getreferenceName2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='referenceName2']")));
        return referenceName2DCQ;
    }

    @FindBy(xpath = "//input[@name='mobileOfReference2']")
    WebElement mobileOfReference2DCQ;

    public WebElement getmobileOfReference2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='mobileOfReference2']")));
        return mobileOfReference2DCQ;
    }

    @FindBy(xpath = "//input[@name='referenceAddress2']")
    WebElement referenceAddress2DCQ;

    public WebElement getreferenceAddress2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='referenceAddress2']")));
        return referenceAddress2DCQ;
    }

    @FindBy(xpath = "//select[@name='relationWith2Borrowe']")
    WebElement relationWith2BorroweDCQ;

    public WebElement getrelationWith2BorroweDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='relationWith2Borrowe']")));
        return relationWith2BorroweDCQ;
    }


    @FindBy(xpath = "//input[@name='nomineeName1']")
    WebElement nomineeName1DCQ;

    public WebElement getnomineeName1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='nomineeName1']")));
        return nomineeName1DCQ;
    }

    @FindBy(xpath = "//input[@name='mobileNoofNominee1']")
    WebElement mobileNoofNominee1DCQ;

    public WebElement getmobileNoofNominee1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='mobileNoofNominee1']")));
        return mobileNoofNominee1DCQ;
    }

    @FindBy(xpath = "//input[@name='nomineeAddress1']")
    WebElement nomineeAddress1DCQ;

    public WebElement getnomineeAddress1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='nomineeAddress1']")));
        return nomineeAddress1DCQ;
    }

    @FindBy(xpath = "//input[@name='nomineeName2']")
    WebElement nomineeName2DCQ;

    public WebElement getnomineeName2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='nomineeName2']")));
        return nomineeName2DCQ;
    }

    @FindBy(xpath = "//input[@name='nomineeAddress2']")
    WebElement nomineeAddress2DCQ;

    public WebElement getnomineeAddress2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='nomineeAddress2']")));
        return nomineeAddress2DCQ;
    }

    @FindBy(xpath = "//select[@name='relationWithBorrowe1']")
    WebElement relationWithBorrowe1DCQ;

    public WebElement getrelationWithBorrowe1DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='relationWithBorrowe1']")));
        return relationWithBorrowe1DCQ;
    }

    @FindBy(xpath = "//select[@name='relationWithBorrowe2']")
    WebElement relationWithBorrowe2DCQ;

    public WebElement getrelationWithBorrowe2DCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name='relationWithBorrowe2']")));
        return relationWithBorrowe2DCQ;
    }

    @FindBy(xpath = "//textarea[@name='oldRemark']")
    WebElement oldRemarkDCQ;

    public WebElement getoldRemarkDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@name='oldRemark']")));
        return oldRemarkDCQ;
    }

    @FindBy(xpath = "//textarea[@name='newRemark']")
    WebElement newRemarkDCQ;

    public WebElement getnewRemarkDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@name='newRemark']")));
        return newRemarkDCQ;
    }

    @FindBy(xpath = "//th//span[text()='ApplicationId']")
    WebElement ApplicationIdColumnDCQ;

    public WebElement getApplicationIdColumnDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th//span[text()='ApplicationId']")));
        return ApplicationIdColumnDCQ;
    }

    @FindBy(xpath = "//th//span[text()='Diarise Dates']")
    WebElement DiariseDatesColumnDCQ;

    public WebElement getDiariseDatesColumnDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th//span[text()='Diarise Dates']")));
        return DiariseDatesColumnDCQ;
    }

    @FindBy(xpath = "//th//span[text()='Diarise Reasons']")
    WebElement DiariseReasonsColumnDCQ;

    public WebElement getDiariseReasonsColumnDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th//span[text()='Diarise Reasons']")));
        return DiariseReasonsColumnDCQ;
    }

    @FindBy(xpath = "//th//span[text()='Comment']")
    WebElement CommentColumnDCQ;

    public WebElement getCommentColumnDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th//span[text()='Comment']")));
        return CommentColumnDCQ;
    }

    @FindBy(xpath = "//th//span[text()='Created By']")
    WebElement CreatedByColumnDCQ;

    public WebElement getCreatedByColumnDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th//span[text()='Created By']")));
        return CreatedByColumnDCQ;
    }

    @FindBy(xpath = "//button[text()='Call']")
    WebElement callButtonDCQ;

    public WebElement getcallButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Call']")));
        return callButtonDCQ;
    }

    @FindBy(xpath = "//button[text()=' Diarise ']")
    WebElement DiariseButtonDCQ;

    public WebElement getDiariseButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Diarise ']")));
        return DiariseButtonDCQ;
    }

    @FindBy(xpath = "//button[text()=' Customer Not Interested ']")
    WebElement CustomerNotInterestedButtonDCQ;

    public WebElement getCustomerNotInterestedButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Customer Not Interested ']")));
        return CustomerNotInterestedButtonDCQ;
    }

    @FindBy(xpath = "//button[text()=' Decline ']")
    WebElement DeclineButtonDCQ;

    public WebElement getDeclineButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Decline ']")));
        return DeclineButtonDCQ;
    }

    @FindBy(xpath = "//button[text()=' Bank Selection ']")
    WebElement BankSelectionButtonDCQ;
    public WebElement getBankSelectionButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Bank Selection ']")));
        return BankSelectionButtonDCQ;
    }
    @FindBy(xpath = "//button[text()=' Save ']")
    WebElement  SaveButtonDCQ;
    public WebElement getSaveButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Save ']")));
        return  SaveButtonDCQ;
    }
    @FindBy(xpath = "//button[text()=' Submit ']")
    WebElement  SubmitButtonDCQ;
    public WebElement getSubmitButtonDCQ() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()=' Submit ']")));
        return  SubmitButtonDCQ;
    }
    @FindBy(xpath = "//h4[text()='General Insurance']")
    WebElement general_insurance;
    public WebElement getGeneral_Insurance()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='General Insurance']")));
        return general_insurance;
    }
    @FindBy(xpath = "(//button[text()=' Next '])[1]")
    WebElement creditnext;
    public WebElement getCreaditNext()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Next '])[1]")));
        return creditnext;
    }
    @FindBy(xpath = "(//span[@class='text-danger'])[1]")
    WebElement picodelableverify;
    public WebElement getPincodeLabelVerify()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[@class='text-danger'])[1]")));
        return picodelableverify;
    }
    @FindBy(xpath = "//li[@class='ngx-select__item-group ng-star-inserted']")
    List<WebElement> searchoptionsize;
    public List <WebElement> getSearch_Option_Size()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@class='ngx-select__item-group ng-star-inserted']")));
        return searchoptionsize;
    }
    @FindBy(xpath = "//label[text()='Email']")
    WebElement labelemail;
    public WebElement getLabelEmail()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Email']")));
        return labelemail;
    }
    @FindBy(xpath = "//input[@name='loanAmount']")
    WebElement bankloanamount;
    public WebElement get_Bank_Selection_LaonAmount()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='loanAmount']")));
        return bankloanamount;
    }
    @FindBy(xpath = "//label[text()='Total Years of work experience/Business']")
    WebElement totalexpericancelabel;
    public WebElement getTotalExpericanceLabel()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Total Years of work experience/Business']")));
        return totalexpericancelabel;
    }
    @FindBy(xpath = "//h4[text()='Home Loan']")
    WebElement homeloan;
    public WebElement getHomeloan()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Home Loan']")));
        return homeloan;
    }
    @FindBy(xpath = "(//span[@class='ng-star-inserted'])[22]")
    WebElement applicationfinalstatus;
    public WebElement getApplicationfinalstatus()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[@class='ng-star-inserted'])[22]")));
        return applicationfinalstatus;
    }
    @FindBy(xpath = "//h4[text()='Business Loan']")
    WebElement businessloan;
    public WebElement getBusinessloan()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Business Loan']")));
        return businessloan;
    }
    @FindBy(xpath = "//h4[text()='Loan Against Property']")
    WebElement loanagainstproperty;
    public WebElement getLoanagainstproperty()
    {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h4[text()='Loan Against Property']")));
        return loanagainstproperty;
    }
    @FindBy(xpath = "(//label[text()='Salutation'])[1]")
    WebElement salutation;
    public WebElement getLoanSalutation()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[text()='Salutation'])[1]")));
        return salutation;
    }
    @FindBy(xpath = "//div[@class='padding ng-star-inserted']")
    WebElement textofapplicationid;
    public WebElement getTextOfApplicationId()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='padding ng-star-inserted']")));
        return textofapplicationid;
    }
    @FindBy(xpath = "//h2[@id='swal2-title']")
    WebElement getOTPalter;
    public WebElement getOTPAlter()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[@id='swal2-title']")));
        return getOTPalter;
    }

}




