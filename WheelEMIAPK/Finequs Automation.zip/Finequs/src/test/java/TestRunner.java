import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.IOException;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/java/FeatureFile/Positive_Scenario","src/test/java/FeatureFile/Negative_Scenario"},
        glue = {"StepDefination"},
        tags = "@InstaLoanFlow or @Insta1 or @Insta2 or @Insta3 or @Insta4 or @Insta5 or @Insta6 or @Insta7 or @Insta8 or @Insta9 or @Insta10 or @Insta11 "+
        " or @Insta12 or @Insta13 or @Insta14 or @Insta15 or @Insta16 or @Insta17 or @Insta18 or @Quickloanflow1 or @quick1 or @quick2 or @quick3" +
        " or @quick4 or @quick5 or @quick6 or @quick7 or @quick8 or @quick9 or @quick10 or @quick11 or @quick12 or @quick13 or @quick14"+
        " or @quick15 or @quick16 or @quick17 or @quick18 or @quick19 or @quick20 or @quick21 or @quick22 or @quick23 or @quick24 or @quick25"+
        " or @quick26 or @quick27 or @quick28 or @quick29 or @quick30 or @quick31 or @quick32 or @channel1 or @channel2 or @white_label_partner1"+
        " or @white_label_partner2 or @white_label_partner3 or @Merchants_List1 or @Merchants_List2 or @Merchants_List3 or @Merchants_List4" +
        " or @Merchants_List5 or @Merchants_List6 or @Merchants_List7 or @Merchent_Peromotions1 or @self_onboarding_QR_code1 or @self_onboarding_QR_code2" +
        " or @self_onboarding_QR_code3 or @self_onboarding_QR_code4 or @self_onboarding_QR_code5 or @self_onboarding_QR_code6 or @self_onboarding_QR_code7" +
                " or @self_onboarding_QR_code8 or @Bank_selection_queue1 or @Bank_selection_queue2 or @Bank_selection_queue3 or @Bank_selection_queue4" +
                " or @Bank_selection_queue5 or @Bank_selection_queue6 or @Bank_selection_queue7 or @Bank_selection_queue8 or @Bank_selection_queue9" +
                " or @Bank_selection_queue10 or @Bank_selection_queue11 or @Bank_selection_queue12 or @Bank_selection_queue13 or @Bank_selection_queue14" +
                " or @Bank_selection_queue20 or @Bank_selection_queue21 or @Bank_selection_queue22 or @Bank_selection_queue23 or @Bank_selection_queue24 " +
                "or @Bank_selection_queue25 or @Bank_selection_queue26 or @Bank_selection_queue27 or @Bank_selection_queue28 or @Bank_selection_queue29 " +
                "or @Bank_selection_queue30 or @Bank_selection_queue31 or @Bank_selection_queue32 or @Bank_selection_queue33 or @Bank_selection_queue34 or @Bank_selection_queue35 " +
                "or @Bank_selection_queue36 or @Bank_selection_queue37 or @Bank_selection_queue38 or @Bank_selection_queue39 or @Bank_selection_queue40 or @Bank_selection_queue41 "+
                "or @Bank_selection_queue42 or @Bank_selection_queue43 or @Bank_selection_queue44 or @Bank_selection_queue45 or @Bank_selection_queue46 or @Bank_selection_queue47 "+
                "or @Bank_selection_queue48 or @Bank_selection_queue49 or @Bank_selection_queue50 or @Bank_selection_queue51 or @Bank_selection_queue52 or @Bank_selection_queue53 "+
                "or @Bank_selection_queue54 or @Bank_selection_queue55 or @Bank_selection_queue56 or @Bank_selection_queue57 or @Reverse_File_Upload1 or @Reverse_File_Upload2 or @Reverse_File_Upload3 or @Reverse_File_Upload4"+
                " or @Reverse_File_Upload5 or @Reverse_File_Upload6 or @Reverse_File_Upload7 or @Reverse_File_Upload8 or @Reverse_File_Upload9"+
                " or @Reverse_File_Upload10 or @Reverse_File_Upload11 or @Reverse_File_Upload12 or @Reverse_File_Upload13 or @Reverse_File_Upload14"+
                " or @API_Trigger1 or @API_Trigger2 or @API_Trigger3 or @API_Trigger4 or @API_Trigger5 or @API_Trigger6 or @API_Trigger7 or @API_Trigger8"+
                " or @API_Trigger9 or @API_Trigger10 or @API_Trigger11 or @API_Trigger12 or @API_Trigger13 or @API_Trigger14 or @Data_collection_Queue1"+
                " or @Data_collection_Queue2 or @Data_collection_Queue3 or @Data_collection_Queue4 or @Data_collection_Queue5 or @Data_collection_Queue6"+
                " or @Data_collection_Queue7 or @Data_collection_Queue8 or @Data_collection_Queue9 or @Data_collection_Queue10 or @Data_collection_Queue11"+
                " or @Data_collection_Queue12 or @Data_collection_Queue13 or @Data_collection_Queue14 or @Data_collection_Queue15 or @Data_collection_Queue16" +
                " or @Data_collection_Queue17 or @Data_collection_Queue18 or @Data_collection_Queue19 or @Data_collection_Queue20 or @Data_collection_Queue21" +
                " or @Data_collection_Queue22 or @Data_collection_Queue23 or @Data_collection_Queue24 or @Data_collection_Queue25 or @Data_collection_Queue26" +
                " or @Data_collection_Queue27 or @Data_collection_Queue28 or @Data_collection_Queue29 or @Data_collection_Queue30 or @Data_collection_Queue31" +
                " or @Data_collection_Queue32 or @Data_collection_Queue33 or @Data_collection_Queue34 or @Data_collection_Queue35 or @Data_collection_Queue36" +
                " or @Data_collection_Queue37 or @Data_collection_Queue38 or @Data_collection_Queue39 or @Data_collection_Queue40 or @microloanQueue1" +
                " or @microloanQueue2 or @microloanQueue3 or @microloanQueue4 or @microloanQueue5 or @microloanQueue6 or @microloanQueue7" +
                " or @microloanQueue8 or @microloanQueue9 or @microloanQueue10 or @microloanQueue11 or @microloanQueue12 or @microloanQueue13" +
                " or @microloanQueue14 or @microloanQueue15 or @microloanQueue16 or @microloanQueue17 or @microloanQueue18 or @microloanQueue19" +
                " or @microloanQueue20 or @microloanQueue21 or @microloanQueue22 or @microloanQueue23 or @microloanQueue24 or @microloanQueue25" +
                " or @microloanQueue26 or @microloanQueue27 or @microloanQueue28 or @microloanQueue29 or @microloanQueue30 or @microloanQueue31" +
                " or @microloanQueue32 or @microloanQueue33 or @microloanQueue34 or @microloanQueue35 or @microloanQueue36 or @microloanQueue37" +
                " or @microloanQueue38 or @microloanQueue39 or @microloanQueue40 or @microloanQueue41 or @microloanQueue42 or @microloanQueue43" +
                " or @microloanQueue44 or @microloanQueue45 or @microloanQueue46 or @microloanQueue47 or @microloanQueue48 or @microloanQueue49" +
                " or @microloanQueue50 or @microloanQueue51 or @microloanQueue52 or @QuickForHomeLoanflow or @QuickForBusinessLoanflow or @QuickForLoanAgainstPropertyflow"+
                " or @homeLoanquickloan1 or @homeLoanquickloan2 or @homeLoanquickloan3 or @homeLoanquickloan4 or @homeLoanquickloan5 or @homeLoanquickloan6 or @homeLoanquickloan7"+
                " or @homeLoanquickloan8 or @homeLoanquickloan9 or @homeLoanquickloan10 or @homeLoanquickloan11 or @homeLoanquickloan12 or @homeLoanquickloan13 or @homeLoanquickloan4"+
                " or @homeLoanquickloan15 or @homeLoanquickloan16 or @homeLoanquickloan17 or @BusinessQuickLoan1 or @BusinessQuickLoan2 or @BusinessQuickLoan3 or @BusinessQuickLoan4"+
                " or @BusinessQuickLoan5 or @BusinessQuickLoan6 or @BusinessQuickLoan7 or @BusinessQuickLoan8 or @BusinessQuickLoan9 or @BusinessQuickLoan10 or @BusinessQuickLoan11"+
                " or @BusinessQuickLoan12 or @BusinessQuickLoan13 or @BusinessQuickLoan14 or @BusinessQuickLoan15 or @BusinessQuickLoan16 or @BusinessQuickLoan17 or @BusinessQuickLoan18"+
                " or @BusinessQuickLoan19 or @BusinessQuickLoan20 or @BusinessQuickLoan21 or @BusinessQuickLoan22 or @BusinessQuickLoan23 or @BusinessQuickLoan24 or @BusinessQuickLoan25"+
                " or @BusinessQuickLoan26 or @BusinessQuickLoan27 or @BusinessQuickLoan28 or @BusinessQuickLoan29 or @BusinessQuickLoan30 or @BusinessQuickLoan31 or @LoanAgainstPropertyquickloan1 or @LoanAgainstPropertyquickloan2"+
                " or @LoanAgainstPropertyquickloan3 or @LoanAgainstPropertyquickloan4 or @LoanAgainstPropertyquickloan5 or @LoanAgainstPropertyquickloan6 or @LoanAgainstPropertyquickloan7 or @LoanAgainstPropertyquickloan8 or @LoanAgainstPropertyquickloan9 or @LoanAgainstPropertyquickloan10"+
                " or @LoanAgainstPropertyquickloan11 or @LoanAgainstPropertyquickloan12 or @LoanAgainstPropertyquickloan13 or @LoanAgainstPropertyquickloan14 or @LoanAgainstPropertyquickloan15 or @LoanAgainstPropertyquickloan16 or @LoanAgainstPropertyquickloan17",
        monochrome = true,
        //plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})
        plugin = {"html:target/QA-Automation-html-report.html","json:target/QA_Automation.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})

public class TestRunner {

    @AfterClass
    public static void writeExtendReport() throws IOException
    {
    }

}

   /* @Before
    public void start()
    {

        System.out.println("-----------------Start The Automation Script---------------------");
    }
    @After
    public void end()

    {
        System.out.println("-------------------End The Automation Script-----------------------");
    }
*/

