package Utilities;

import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.Locale;
import java.util.Random;

public class InputGenerator {
    public static void main(String[] args) throws IOException, ParseException {
        new InputGenerator().mobileNumberGenerator();
    }
         WriteExcelData writedata = new WriteExcelData();
        JsonDataReadAndWrite jsrt = new JsonDataReadAndWrite();
        Random rd = new Random();
        public String mobileNumberGenerator () throws IOException, ParseException {

            String mobileNo="9";
            for (int i=0;i<9;i++) {
                int a = (int)(Math.random()*10);
                mobileNo = mobileNo + a;
            }
            jsrt.jsonWrite("MobileNumber", mobileNo);
            return mobileNo;
            /*long mob = rd.nextInt(99999999);
            String mobileNo = "8" + mob;
            if (mobileNo.length() <= 9) {
                int a = (int) Math.random() * 10;
                mobileNo = mobileNo + a;

            }
            //writedata.setBulkOfData("Sheet1", 1, 1, mobileNo);
            jsrt.jsonWrite("MobileNumber", mobileNo);

            return mobileNo;*/
        }

        public String panCardNumber() throws IOException, ParseException {
            String PANNumber = "";
            for (int i = 0; i <= 4; i++) {
                Random r = new Random();
                PANNumber = PANNumber + (char) (97 + r.nextInt(3));
            }
            for (int j = 0; j <= 3; j++) {
                Random r = new Random();
                PANNumber = PANNumber + (r.nextInt(10));
            }
            for (int i = 0; i <1; i++) {
                Random r = new Random();
                PANNumber = PANNumber + (char) (97 + r.nextInt(3));
            }
            System.out.println(PANNumber.toUpperCase(Locale.ROOT));
            return PANNumber;
        }
        public String getEmailAddress()
        {
            String emaiid="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder builder=new StringBuilder();
            Random random=new Random();
            while (builder.length() < 10) {
                int index = (int) (random.nextFloat() * emaiid.length());
                builder.append(emaiid.charAt(index));
            }
            String emailid = builder.toString();
            return emailid;
        }

    /* return mobileNo;
        String mobileno1="8474738474";
        char[]s=mobileno1.toCharArray();
        int a= Character.getNumericValue(s[7]);
        int b=  Character.getNumericValue(s[8]);
        int c=  Character.getNumericValue(s[9]);
        String d=""+a+b+c;
        int f= Integer.parseInt(d);
        f++;
        String validmobilenumber="5847473"+f;
        mobileno1=validmobilenumber;
        return validmobilenumber;*/

    }


