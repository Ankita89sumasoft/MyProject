package Utilities;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteExcelData {
    public File file=new File("src/Resources/WriteData.xlsx");
    public  void setBulkOfData(String sheetname,int row ,int cell,String data) throws IOException {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fileInputStream);
            XSSFSheet sheet = wb.getSheet(sheetname);
            sheet.getRow(row).createCell(cell).setCellValue(data);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            wb.write(fileOutputStream);
            fileInputStream.close();
            fileOutputStream.close();
            wb.close();
        } catch (Exception e) {
            System.out.println("Exception is:" + e);
        }

    }
}
