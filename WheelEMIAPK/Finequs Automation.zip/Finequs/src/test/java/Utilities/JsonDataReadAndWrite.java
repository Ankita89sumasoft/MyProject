package Utilities;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class JsonDataReadAndWrite {
    public JSONObject jsonObject = new JSONObject();
    public JSONParser parser = new JSONParser();
    JSONObject jsonObject1=new JSONObject();


    public String jsonReadData(String key) throws IOException, ParseException {
        jsonObject = (JSONObject) parser.parse(new FileReader("C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\src\\test\\java\\JsonData\\JsonData.json"));
        return (String) jsonObject.get(key);
    }
    public String jsonActualReadData(String key) throws IOException, ParseException {
        jsonObject1 = (JSONObject) parser.parse(new FileReader("C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\src\\test\\java\\JsonData\\ActualData.json"));
        return (String) jsonObject1.get(key);
    }
    public void jsonWrite(String key, Object value1) throws IOException, ParseException {
        jsonObject.put(key, value1);
        PrintWriter out=new PrintWriter(new FileWriter("C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\src\\test\\java\\JsonData\\JsonData.json", false));
        //FileWriter file = new FileWriter("C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\src\\test\\java\\JsonData\\JsonData.json", false);
       // file.write(jsonObject.toJSONString()+"\n");
        out.write(jsonObject.toString());
        out.close();
    }
}
