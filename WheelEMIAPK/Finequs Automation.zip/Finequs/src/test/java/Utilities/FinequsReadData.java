package Utilities;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FinequsReadData {
    public String readExcelData(String sheetname,String colunmname) throws IOException {
        File file = new File("src/Resources/ReadData.xlsx");
        FileInputStream fi = new FileInputStream(file);
        Workbook wb = WorkbookFactory.create(fi);
        Sheet sheet = wb.getSheet(sheetname);
        // it will take value from first row
        Row row = sheet.getRow(0);
        // it will give you count of row which is used or filled
        short lastcolumnused = row.getLastCellNum();

        int colnum = 0;
        for (int i = 0; i < lastcolumnused; i++) {
            if (row.getCell(i).getStringCellValue().equalsIgnoreCase(colunmname)) {
                colnum = i;
                break;
            }
        }
        // it will take value from Second row
        row = sheet.getRow(1);
        org.apache.poi.ss.usermodel.Cell column = row.getCell(colnum);
        String CellValue = column.getStringCellValue();
        return CellValue;
    }
}
