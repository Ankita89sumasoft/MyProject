package StepDefination;

import Helper.BaseClass;
import Helper.QRCodeHelper;
import Utilities.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
//import org.testng.reporters.TestHTMLReporter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class QuickLoan extends BaseClass {
    public InputGenerator inputgenerator=new InputGenerator();
    JsonDataReadAndWrite read=new JsonDataReadAndWrite();
    QRCodeHelper qr=null;
    WriteExcelData writedata=new WriteExcelData();
    JavascriptExecutor js;
    String parentwindow=null;
    ReadExcelData readexceldata=new ReadExcelData();
    Random random=new Random();
    ReadActualData readactuactualdata=new ReadActualData();
    String thankyoudata="Thank you for the request";
    @Given("I lunch chrome browser for the Quick Loan")
    public void i_lunch_chrome_browser_for_the_quick_loan() throws IOException, ParseException, ParseException, java.text.ParseException {
        set();
    }
    @When("I login valid login credentials")
    public void i_login_valid_login_credentials() throws InterruptedException {
        login();
    }
    @When("I click on the navigation bar")
    public void i_click_on_the_navigation_bar() throws InterruptedException {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        Thread.sleep(1000);
    }
    @When("I click on channel")
    public void i_click_on_channel() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(2000);
    }
    @When("I Select the generate QR code option")
    public void i_select_the_generate_qr_code_option() throws InterruptedException {
        qr.getGenerateqrcode().click();
        Thread.sleep(1000);
    }
    @Then("I verify the send OTP button in personal loan")
    public void i_verify_the_send_otp_button_in_personal_loan() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        WebElement verify=qr.getVerifysendOTP();
        if (verify.getAttribute("disabled").equals("true"))
        {
            System.out.println("Send OTP button is disable in bank seelction");
        }
        else
        {
            throw new InterruptedException("Send OTP button is not disable in bank selection please check...");
        }
    }
    @When("I choose the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_choose_the_as(String string, String string2) throws InterruptedException {
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(2000);
    }
    @Then("I set the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_set_the_as(String string, String string2) throws InterruptedException {
        ngwebdriver.waitForAngularRequestsToFinish();
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1000)");
        Thread.sleep(1000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(2000);
    }

    @When("I copy the url link")
    public void i_copy_the_url_link() throws InterruptedException, IOException, ParseException {
        qr.getCopyURL().click();
        Thread.sleep(2000);
        qr.getClosealter().click();
        Thread.sleep(1000);
        String pastdata=qr.getURL().getAttribute("value");
        System.out.println("Pastdata is"+pastdata);
        Thread.sleep(1000);
        json.jsonWrite("URL",pastdata);
        Thread.sleep(1000);
    }
    @Then("I click on the generate QRcode button")
    public void i_click_on_the_generate_q_rcode_button() throws InterruptedException {
        qr.getGenerateQRcode().click();
        Thread.sleep(1000);
        qr.getScroll();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getHeader();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-4000)");
        Thread.sleep(1000);
    }
    @When("I switch the tab for the Quick loan")
    public void i_switch_the_tab_for_the_quick_loan() throws InterruptedException, IOException, ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        // String url=readdata.readExcel("Sheet1","URL");
        driver.navigate().to(url);
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @When("I click on Quick loan")
    public void i_click_on_quick_loan() throws InterruptedException {
        qr=new QRCodeHelper();
        Actions act=new Actions(driver);
        act.moveToElement(qr.getQuickLoan()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(3000);
    }
    @When("I click on credit card option")
    public void i_click_on_credit_card_option() throws InterruptedException {
        qr=new QRCodeHelper();
        qr.getCreaditCardOption().click();
        Thread.sleep(1000);
    }
    @When("I click on the Home Loan Option")
    public void i_click_on_the_home_loan_option() throws InterruptedException {
        qr.getHomeloan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
    }
    @When("I click on Loan Against Property")
    public void i_click_on_loan_against_property() throws InterruptedException {
        qr.getLoanagainstproperty().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I click on the Business Loan")
    public void i_click_on_the_business_loan() throws InterruptedException {
        qr.getBusinessloan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I click on the Loan Against property option")
    public void i_click_on_the_loan_against_property_option() throws InterruptedException {
        qr.getLoanagainstproperty().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I click on personal loan option")
    public void i_click_on_personal_loan_option() throws InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getPersonalLoan()).click().build().perform();
        Thread.sleep(1000);
    }
    @Then("I verify the mobile number next button")
    public void i_verify_the_mobile_number_next_button() throws InterruptedException {
        qr.getNextButton().click();
        Thread.sleep(1000);
        String msg="Mobile number is required";
        String getmsg=qr.getMobileAlter().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("Mobile number have validation");
        }
        else
        {
            throw new InterruptedException("For quick loan mobile number dont have validation please check...");
        }
    }
    @When("I enter the mobile number in personal loan")
    public void i_enter_the_mobile_number_in_personal_loan() throws InterruptedException, IOException, ParseException {
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        inputgenerator.mobileNumberGenerator();
        String mobile=read.jsonReadData("MobileNumber");
        qr.getEnterMobileNumber().clear();
        Thread.sleep(1000);
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(1000);
        //json.jsonWrite("MobileNo",inputgenerator.mobileNumberGenerator());
       // writedata.setBulkOfData("Sheet1",1,1,number);
        Thread.sleep(1000);
        qr.getNextButton().click();
        Thread.sleep(1000);
    }
    @Then("I Enter the mobile number in Home Loan")
    public void i_enter_the_mobile_number_in_home_loan() throws IOException, ParseException, InterruptedException {
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        inputgenerator.mobileNumberGenerator();
        String mobile=read.jsonReadData("MobileNumber");
        qr.getEnterMobileNumber().clear();
        Thread.sleep(1000);
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(1000);
        //json.jsonWrite("MobileNo",inputgenerator.mobileNumberGenerator());
        // writedata.setBulkOfData("Sheet1",1,1,number);
        Thread.sleep(1000);
        qr.getNextButton().click();
        Thread.sleep(1000);
    }
    @Then("I verify the next button in personal loan")
    public void i_verify_the_next_button_in_personal_loan() throws InterruptedException {
        qr.getNextButton().click();
        Thread.sleep(1000);
        String msg="Mobile number is required";
        String getmsg=qr.getMobileAlter().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("next button have validation");
        }
        else {
            throw new InterruptedException("next button is not have any validation please check...");
        }
    }

    @Then("I verify the save and next button in quick loan")
    public void i_verify_the_save_and_next_button_in_quick_loan() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        WebElement saveandnextbutton=qr.getSaveAndNextButton();
        if (saveandnextbutton.getAttribute("disabled").equals("true"))
        {
            System.out.println("save and next button is disable...");
        }
        else {
            throw new InterruptedException("without filling mandetory details save and next button is enable please check...");
        }
    }

    @When("I click on agree terms and condition of finequs")
    public void i_click_on_agree_terms_and_condition_of_finequs() throws InterruptedException {
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getAgreeStatement().click();
        Thread.sleep(1000);
    }
    @When("I click on the send OTP button")
    public void i_click_on_the_send_otp_button() throws InterruptedException {
        qr.getSendOTP().click();
        Thread.sleep(2000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @When("I switch to the QR code generation window")
    public void i_switch_to_the_qr_code_generation_window() throws InterruptedException {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        Thread.sleep(3000);
    }
    @When("I click on the report drop-down")
    public void i_click_on_the_report_drop_down() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getReport().click();
        Thread.sleep(1000);
        qr.getSMSLog().click();
        Thread.sleep(20000);
    }
    @Then("I click on the SMS log")
    public void i_click_on_the_sms_log() throws InterruptedException {
        qr.getReport().click();
        Thread.sleep(1000);
        qr.getSMSLog().click();
       Thread.sleep(60000);
    }
    @Then("I refresh the page")
    public void i_refresh_the_page() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(50,TimeUnit.MILLISECONDS);
        qr.getRefreshpage().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        //Thread.sleep(40000);
    }
    @When("I Search the mobile number")
    public void i_search_the_mobile_number() throws InterruptedException, IOException, ParseException {
        String mobiledata = json.jsonReadData("MobileNumber");
        Thread.sleep(1000);
        qr.getSearchdata().clear();
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
        Thread.sleep(45000);
        /*ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(2000);*/
    }
    @Then("I Enter the mobile number in Loan against property")
    public void i_enter_the_mobile_number_in_loan_against_property() throws IOException, ParseException, InterruptedException {
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        inputgenerator.mobileNumberGenerator();
        String mobile=read.jsonReadData("MobileNumber");
        qr.getEnterMobileNumber().clear();
        Thread.sleep(1000);
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(1000);
        //json.jsonWrite("MobileNo",inputgenerator.mobileNumberGenerator());
        // writedata.setBulkOfData("Sheet1",1,1,number);
        Thread.sleep(1000);
        qr.getNextButton().click();
        Thread.sleep(1000);
    }
    @Then("I click on the verify button in Loan Against Property")
    public void i_click_on_the_verify_button_in_loan_against_property() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        Thread.sleep(8000);
        String msg="Thank you for application. Our team shall contact you at the earliest.";
        String getmsg=qr.getOTPSentMessage().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
        }
        else {
            throw new InterruptedException("Thank you for application Our team shall contact you at the earliest message not dispalyed please check....");
        }
    }

    @When("I verify the final status of the home loan")
    public void i_verify_the_final_status_of_the_home_loan() throws InterruptedException, IOException, ParseException {
       // String status="Finequs WIP HL";
        String getstatus=qr.getApplicationfinalstatus().getText();
        json.jsonWrite("HomeStatus",getstatus);
        /*if (getstatus.equals(status))
        {
            System.out.println("application id in finequs WIP HL");
        }
        else
        {
            throw new InterruptedException("Application id is not in finequs WIP HL please check...");
        }*/
    }
    @Then("I verify the final status of the Loan against property")
    public void i_verify_the_final_status_of_the_loan_against_property() throws InterruptedException, IOException, ParseException {
        //String status="Finequs WIP LAP";
        String getstatus=qr.getApplicationfinalstatus().getText();
        json.jsonWrite("LoanAginstProperty",getstatus);
       /* if (getstatus.equals(status))
        {
            System.out.println("application id in finequs WIP HL");
        }
        else
        {
            throw new InterruptedException("Application id is not in finequs WIP HL please check...");
        }*/
    }

    @Then("I Enter mobile number for search")
    public void i_enter_mobile_number_for_search() throws InterruptedException, IOException, ParseException {
        qr.getSearchMobileNo().click();
        Thread.sleep(1000);
        String mobilenumber=json.jsonReadData("MobileNumber");
        Thread.sleep(1000);
        qr.getSearchMobileNo().clear();
        Thread.sleep(1000);
        qr.getSearchMobileNo().sendKeys(mobilenumber);
        Thread.sleep(1000);
        qr.getSearchMobileNo().sendKeys(Keys.ENTER);
        Thread.sleep(5000);
    }
    @When("I get the OTP")
    public void i_get_the_otp() throws InterruptedException, IOException, ParseException {
        String otp = null;
        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
           this.i_refresh_the_page();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_mobile_number();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }
        List<WebElement>list=new ArrayList<WebElement>();
        list.add(qr.getSearchiconFirst());
        list.add(qr.getSearchiconSecond());
        list.add(qr.getSearchiconThird());
        int i=0;
        while (i<3)
        {
            Actions act=new Actions(driver);
            act.moveToElement(list.get(i)).click().build().perform();
            Thread.sleep(2000);
            int size= driver.findElements(By.xpath("//section[@class='segment segment-type-string ng-star-inserted']")).size();
            if (size==10)
            {
                String get_thanks_data=driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")).getText();
                if (get_thanks_data.contains(thankyoudata))
                {
                    otp=get_thanks_data.replaceAll("\\D","");
                    Thread.sleep(1000);
                    json.jsonWrite("OTP",otp);
                   // writedata.setBulkOfData("Sheet1",1,2, String.valueOf(otp));
                    Thread.sleep(1000);
                    Actions action=new Actions(driver);
                    action.moveToElement( qr.getCloseOTPAlter()).click().build().perform();
                    Thread.sleep(1000);
                    break;
                }
                else if (size==3||size==9)
                {
                    Actions action=new Actions(driver);
                    action.moveToElement( qr.getCloseOTPAlter()).click().build().perform();
                    Thread.sleep(1000);
                }
                else {
                    Actions action=new Actions(driver);
                    action.moveToElement( qr.getCloseOTPAlter()).click().build().perform();
                    Thread.sleep(1000);
                }
            }
            i++;
        }
        if (otp==null)
        {
            //qr.getCloseOTPAlter().click();
            this.i_refresh_the_page();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_mobile_number();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            this.i_get_the_otp();
        }
    }
    @When("I switch to the child window")
    public void i_switch_to_the_child_window() throws InterruptedException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }
    @When("I Enter the OTP in personal loan page")
    public void i_enter_the_otp_in_personal_loan_page() throws InterruptedException, IOException, ParseException {
        /*qr.getEnterMobileOTP().click();
        Thread.sleep(1000);*/
        String otp= json.jsonReadData("OTP");
       // String otp=readexceldata.readExcel("Sheet1","OTP");
        qr.getEnterMobileOTP().clear();
        Thread.sleep(1000);
        qr.getEnterMobileOTP().sendKeys(otp);
        Thread.sleep(1000);
    }
    @Then("I click on the verify button")
    public void i_click_on_the_verify_button() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        Thread.sleep(54000);
       // qr.getDatacollectionok().click();
       qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @Then("I click on the verify button in home loan")
    public void i_click_on_the_verify_button_in_home_loan() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        Thread.sleep(8000);
        String msg="Thank you for application. Our team shall contact you at the earliest.";
        String getmsg=qr.getOTPSentMessage().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
        }
        else {
            throw new InterruptedException("Thank you for application Our team shall contact you at the earliest message not dispalyed please check....");
        }
        ArrayList<String>tab=new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I click on the verify button in home loan option")
    public void i_click_on_the_verify_button_in_home_loan_option() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        Thread.sleep(10000);
        String msg="Thank you for application. Our team shall contact you at the earliest.";
        String getmsg=qr.getOTPSentMessage().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
        }
        else {
            throw new InterruptedException("Thank you for application Our team shall contact you at the earliest message not dispalyed please check....");
        }
    }

    @When("I Enter the First name in person details")
    public void i_enter_the_first_name_in_person_details() throws IOException, InterruptedException, ParseException {
        String firstname=json.jsonActualReadData("FirstName");
        qr.getFirstname().clear();
        Thread.sleep(1000);
        qr.getFirstname().sendKeys(firstname);
        Thread.sleep(1000);
    }
    @Then("I verify the first name and last name field")
    public void i_verify_the_first_name_and_last_name_field() throws InterruptedException, IOException, ParseException {
        String firstname=json.jsonActualReadData("InvalidFirstName");
        String firstnamealter="Please enter a valid first name";
        qr.getFirstname().sendKeys(firstname);
        Thread.sleep(1000);
        qr.getFirstNameLabel().click();
        Thread.sleep(1000);
        String verifyalterforFirstName=qr.getMobileAlter().getText();
        if (verifyalterforFirstName.equals(firstnamealter))
        {
            System.out.println("Verification done for first name successfully...");
        }
        else {
            throw new InterruptedException("No validation for the first name...");
        }
        String lastname=json.jsonActualReadData("InvalidLastName");
        String lastnamealter="Please enter a valid last name";
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
        qr.getLastNameLabel().click();
        Thread.sleep(1000);
        String getLastnameVerification=qr.getLastNameVerification().getText();
        if (getLastnameVerification.equals(lastnamealter))
        {
            System.out.println("Verification done for last name successfully...");
        }
        else {
            throw new InterruptedException("No validation for the last name...");
        }
    }
    @When("I Enter Last name for Personal Loan")
    public void i_enter_last_name_for_personal_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("PersonalLastName");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last name for Business Loan")
    public void i_enter_last_name_for_business_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("BusinessLastName");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last name for Home Loan")
    public void i_enter_last_name_for_home_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("HomeLastName");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last name for Loan Against property")
    public void i_enter_last_name_for_loan_against_property() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("LoanAgainstLastName");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last name for creditCard")
    public void i_enter_last_name_for_credit_card() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("creditCarsLastName");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Last name")
    public void i_enter_the_last_name() throws IOException, InterruptedException, ParseException {
        String lastname= json.jsonActualReadData("Lastname");
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Date of Birth")
    public void i_enter_the_date_of_birth() throws IOException, InterruptedException {
        qr.getDOB().click();
        Thread.sleep(1000);
        qr.getCurrentdate().click();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        qr.getYear().click();
        Thread.sleep(1000);
        qr.getMonth().click();
        Thread.sleep(1000);
        qr.getDay().click();
        Thread.sleep(1000);
    }
    @Then("I verify the PAN number")
    public void i_verify_the_pan_number() throws InterruptedException, IOException, ParseException {
        String invalidpan=json.jsonActualReadData("InvalidPAN");
        qr.getPanNumber().sendKeys(invalidpan);
        Thread.sleep(1000);
        qr.getPincodeLabel().click();
        Thread.sleep(3000);
        String getalter=qr.getMobileAlter().getText();
        String data="Please enter a valid pan number";
        if (getalter.equals(data))
        {
            System.out.println("Pan number have verification");
        }
        else {
            throw new InterruptedException("No validation for PAN number");
        }
    }

    @When("I Enter the Pan Number in personal Details")
    public void i_enter_the_pan_number_in_personal_details() throws InterruptedException, IOException, ParseException {
       String pannumber=json.jsonActualReadData("panno");
         qr.getPanNumber().clear();
        Thread.sleep(1000);
        //qr.getPanNumber().sendKeys(inputgenerator.panCardNumber());
        qr.getPanNumber().sendKeys(pannumber);
        Thread.sleep(1000);
        /*String pannumber=readactuactualdata.readExcel("Sheet1","panno");
        qr.getPanNumber().sendKeys(pannumber);
        Thread.sleep(1000);*/
    }
    @Then("I verify the pincode field")
    public void i_verify_the_pincode_field() throws InterruptedException, IOException, ParseException {
        String invalidpincode=json.jsonActualReadData("InvalidPincode");
        qr.getPDppincode().sendKeys(invalidpincode);
        Thread.sleep(1000);
        qr.getNetIcomeLabel().click();
        Thread.sleep(2000);
        String data="Please enter valid pincode";
        String getalter=qr.getValidPin().getText();
        if (getalter.equals(data))
        {
            System.out.println("Pan number have verification");
        }
        else {
            throw new InterruptedException("No validation for PAN number");
        }
    }
    @When("I Enter the pincode in personal details")
    public void i_enter_the_pincode_in_personal_details() throws IOException, InterruptedException, ParseException {
        String pincode= json.jsonActualReadData("pincodeno");
        qr.getPDppincode().clear();
        Thread.sleep(1000);
        qr.getPDppincode().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @Then("I click on the save and next button")
    public void i_click_on_the_save_and_next_button() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        qr.getSaveAndNext().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }

    @Then("I verify the send otp button in professional details")
    public void i_verify_the_send_otp_button_in_professional_details() throws InterruptedException {
       js=(JavascriptExecutor) driver;
       js.executeScript("window.scrollBy(0,600)");
       Thread.sleep(1000);
       WebElement sendotp=qr.getSendOTPButton();
       if(sendotp.getAttribute("disabled").equals("true"))
       {
           System.out.println("Send OTP button is disable");
       }
       else
       {
           throw new InterruptedException("Send OTP button is not disable professional details please check...");
       }
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-600)");
        Thread.sleep(1000);
    }
    @When("I choose the occupation")
    public void i_choose_the_occupation() throws InterruptedException {
        qr.getOccupation().click();
        Thread.sleep(1000);
        /*qr.getConfirmButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);*/
    }
    @When("I get application id")
    public void i_get_application_id() throws IOException, InterruptedException, ParseException {
        ngwebdriver.waitForAngularRequestsToFinish();
        String applicationid=qr.getPDApplicationID().getText();
        json.jsonWrite("AppID",applicationid);
       // writedata.setBulkOfData("Sheet1",1,3,applicationid);
        Thread.sleep(1000);
    }
    @When("I Enter the current address")
    public void i_enter_the_current_address() throws IOException, InterruptedException, ParseException {
        String currentaddress=json.jsonActualReadData("CurrentAddress");
        qr.getCurrentAddress().sendKeys(currentaddress);
        Thread.sleep(1000);
    }
    @Then("I verify the email address field")
    public void i_verify_the_email_address_field() throws NoSuchFieldException, InterruptedException {
        qr.getEmaild().sendKeys("t274764gmailcom");
        Thread.sleep(2000);
        qr.getEmailLabel().click();
        Thread.sleep(1000);
        String msg="Please enter valid email";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg)){
            System.out.println("system showing the Please enter valid email alert");
        }
        else {
            throw new NoSuchFieldException("alert is not showing");
        }
    }

    @When("I Enter Email Address")
    public void i_enter_email_address() throws IOException, InterruptedException, ParseException {
        String emailid=json.jsonActualReadData("OfficialEmail_id");
        qr.getEmaild().clear();
        Thread.sleep(1000);
        qr.getEmaild().sendKeys(emailid);
        Thread.sleep(1000);
    }
    @When("I Enter the loan amount")
    public void i_enter_the_loan_amount() throws IOException, InterruptedException, ParseException {
        String loanamount=json.jsonActualReadData("LoanAmount");
        qr.getLoanAmount().sendKeys(loanamount);
        Thread.sleep(1000);
    }
    @Then("I Enter the loan amount for quick loan")
    public void i_enter_the_loan_amount_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String loanamount=json.jsonActualReadData("LoanAmount");
        qr.getLoanAmt().clear();
        Thread.sleep(1000);
        qr.getLoanAmt().sendKeys(loanamount);
        Thread.sleep(1000);
    }
    @When("I Enter the Net Monthly income")
    public void i_enter_the_net_monthly_income() throws IOException, InterruptedException, ParseException {
        String netincome=json.jsonActualReadData("NetMonthlyIcome");
        qr.getNetMonthlyIcome().clear();
        Thread.sleep(1000);
        qr.getNetMonthlyIcome().sendKeys(netincome);
        Thread.sleep(1000);
    }
    @Then("I verify the pincode")
    public void i_verify_the_pincode() throws InterruptedException, IOException, ParseException {
        String invalidpincode=json.jsonActualReadData("InvalidPincode");
        qr.getOfficePincode().sendKeys(invalidpincode);
        Thread.sleep(1000);
        qr.getOfficePinCodeLabel().click();
        Thread.sleep(2000);
        String data="Please enter valid pincode";
        String getalter=qr.getValidPin().getText();
        if (getalter.equals(data))
        {
            System.out.println("Pan number have verification");
        }
        else {
            throw new InterruptedException("No validation for PAN number");
        }
    }
    @When("I Enter the office pincode")
    public void i_enter_the_office_pincode() throws IOException, InterruptedException, ParseException {
        String pincode=json.jsonActualReadData("pincodeno");
        qr.getOfficePincode().clear();
        Thread.sleep(1000);
        qr.getOfficePincode().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @When("I click on the send OTP in personal loan")
    public void i_click_on_the_send_otp_in_personal_loan() throws InterruptedException {
        qr.getSentOTP().click();
        Thread.sleep(56000);
        qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @When("I Enter the OTP in personal loan")
    public void i_enter_the_otp_in_personal_loan() throws IOException, InterruptedException, ParseException {
        String otp=json.jsonReadData("OTP");
        qr.getOTPEnter().sendKeys(otp);
        Thread.sleep(1000);
    }

    @Then("I click on verify button in personal loan page")
    public void i_click_on_verify_button_in_personal_loan_page() throws InterruptedException {
        qr.getVerifyOTP().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @Then("I click on verify button in personal loan")
    public void i_click_on_verify_button_in_personal_loan() throws InterruptedException {
        qr.getVerifyOTP().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @When("I Tick The Bank selection")
    public void i_tick_the_bank_selection() throws InterruptedException {
        qr.getTickBankSelection().click();
        Thread.sleep(1000);
    }
    @Then("I click on the submit button in personal loan")
    public void si_click_on_the_submit_button_in_personal_loan() throws InterruptedException {
        qr.getPersonalSubmit().click();
        Thread.sleep(5000);
        String alter="Thank you for the request, we have sent you a link to download the App for Indifi.";
        String verificationalter=qr.getAlterVerification().getText();
        if(alter.equals(verificationalter))
        {
            System.out.println("Verification Done Successfully...");
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(1));
            driver.close();
            Thread.sleep(1000);
        }
        else {
            throw new NullPointerException("something wents wrong please check again...");
        }
    }
    @Then("I Switch the tab")
    public void i_switch_the_tab() {
        ArrayList<String>tab=new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
    }
    @Then("I click on the report option")
    public void i_click_on_the_report_option() throws InterruptedException {
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(8000);
        Actions act=new Actions(driver);
        act.moveToElement(qr.getReport()).click().build().perform();
        Thread.sleep(1000);
    }
    @When("I click on the loan option")
    public void i_click_on_the_loan_option() throws InterruptedException {
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        Actions actions=new Actions(driver);
        actions.moveToElement(qr.getLoans()).click().build().perform();
        Thread.sleep(1000);
        qr.getLoanApplication().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @And("I search the application id")
    public void i_search_the_application_id() throws IOException, ParseException, InterruptedException {
        String appid=json.jsonReadData("AppID");
        qr.getQuickAppId().click();
        Thread.sleep(1000);
        qr.getQuickAppId().sendKeys(appid);
        Thread.sleep(1000);
        qr.getQuickAppId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I check the status of the personal loan application id")
    public void i_check_the_status_of_the_personal_loan_application_id() throws InterruptedException, IOException, ParseException {
        String getstatus=qr.getFinalStatus().getText();
        json.jsonWrite("BankStatus",getstatus);
        Thread.sleep(1000);
       /* if (getstatus.equals(status))
        {
            System.out.println("Correct bank selection final status showing");
        }
        else {
            throw new InterruptedException("Incorrect Bank Selection Final Status Showing please check......");
        }*/
    }
    @Then("I check the status of the business loan application id")
    public void i_check_the_status_of_the_business_loan_application_id() throws InterruptedException, IOException, ParseException {
        //String status="Bank Declined";
        String getstatus=qr.getFinalStatus().getText();
        json.jsonWrite("BusinessStatus",getstatus);
        Thread.sleep(1000);
        /*if (getstatus.equals(status))
        {
            System.out.println("Correct bank selection final status showing");
        }
        else {
            throw new InterruptedException("Incorrect Bank Selection Final Status Showing please check......");
        }*/
    }

    @When("I select the microloan queue")
    public void i_select_the_microloan_queue() throws InterruptedException {
        qr.getMicroLoanQueue().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I search the application in microloan queue")
    public void i_search_the_application_in_microloan_queue() throws InterruptedException, IOException, ParseException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String appid=json.jsonReadData("AppID");
        qr.getSearchId().sendKeys(appid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        /*qr.getSearch().click();
        ngwebdriver.waitForAngularRequestsToFinish();*/
        String getAppid=qr.getMicroId().getText();
        if (getAppid.equals(appid))
        {
            System.out.println("Application ID is corret");
        }
        else
        {
            qr.getNextButton().click();
            Thread.sleep(1000);
            this.i_search_the_application_in_microloan_queue();
            Thread.sleep(1000);
        }
    }
    @When("I Enter the remark in microloan-QL")
    public void i_enter_the_remark_in_microloan_ql() throws IOException, ParseException, InterruptedException {
        String remark=json.jsonActualReadData("NewRemark");
        qr.getNewRemark().sendKeys(remark);
        Thread.sleep(1000);
    }
    @When("I click on the data collection button")
    public void i_click_on_the_data_collection_button() throws InterruptedException {
        qr.getDatacollection().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        String alter="Customer Application Status updated successfully.";
        String getalterdata=qr.getUpdateStatusAlter().getText();
        if (getalterdata.equals(alter))
        {
            System.out.println("status updated successfully...");
            Thread.sleep(1000);
            qr.getDatacollectionok().click();
          Thread.sleep(5000);
        }
        else
        {
            throw new NullPointerException("status is not updated for data collection button");
        }
    }
    @When("I click on Data Collection Queue")
    public void i_click_on_data_collection_queue() throws InterruptedException {
        qr.getQuicDataCollectionQueue().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I Put the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_put_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @Then("I select the salutation")
    public void i_select_the_salutation() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//p[text()='Data Collection Queue']"));
        ngwebdriver.waitForAngularRequestsToFinish();
        driver.findElement(By.xpath("//select[@formcontrolname='salutation']")).click();
        Thread.sleep(6000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='salutation']")));
        select.selectByVisibleText("Mr.");
        Thread.sleep(5000);
    }
    @Then("I Enter the alternate mobile number")
    public void i_enter_the_alternate_mobile_number() throws IOException, ParseException, InterruptedException {
        String alternateno=json.jsonActualReadData("Alternatnumber");
        qr.getAlternateMobileNumber().clear();
        Thread.sleep(1000);
        qr.getAlternateMobileNumber().sendKeys(alternateno);
        Thread.sleep(1000);
    }
    @When("I Enter the FatherName")
    public void i_enter_the_father_name() throws IOException, ParseException, InterruptedException {
        String fathername=json.jsonActualReadData("FatherName");
        qr.getFatherName().sendKeys(fathername);
        Thread.sleep(1000);
    }
    @When("I Enter the Mother Name")
    public void i_enter_the_mother_name() throws IOException, ParseException, InterruptedException {
        String mothername=json.jsonActualReadData("MotherName");
        qr.getMothername().sendKeys(mothername);
        Thread.sleep(1000);
    }
    @When("I Entered the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_entered_the_as(String string, String string2) throws InterruptedException, IOException, ParseException {
        String address=json.jsonActualReadData(string2);
        driver.findElement(By.xpath("//input[@formcontrolname='"+string+"']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='"+string+"']")).sendKeys(address);
        Thread.sleep(1000);
    }
    @When("I pick the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_pick_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @Then("I tick the permanent address same as the resident address")
    public void i_tick_the_permanent_address_same_as_the_resident_address() throws InterruptedException {
      qr.getCheckBoxTick().click();
      Thread.sleep(1000);
    }
    @Then("I Tick the office address same as Residence address")
    public void i_tick_the_office_address_same_as_residence_address() throws InterruptedException {
        qr.getResOfficeSame().click();
        Thread.sleep(1000);
    }
    @When("I Enter the New Remark")
    public void i_enter_the_new_remark() throws IOException, ParseException, InterruptedException {
        String Remark=json.jsonActualReadData("NewRemark");
        qr.getRemarkNew().sendKeys(Remark);
        Thread.sleep(1000);
    }
    @And("I click on the submit button in quick loan")
    public void i_click_on_the_submit_button_in_quick_loan() throws InterruptedException {
        qr.getPersonalSubmit().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @Then("I click on the loan application for quick loan")
    public void i_click_on_the_loan_application_for_quick_loan() throws InterruptedException {
        qr.getLoanApplication().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I again search the applicationId for quick loan")
    public void i_again_search_the_application_id_for_quick_loan() throws InterruptedException, IOException, ParseException {
        qr.getCloseApplicationId().click();
       ngwebdriver.waitForAngularRequestsToFinish();
        String appid=json.jsonReadData("AppID");
        qr.getQuickAppId().click();
        Thread.sleep(1000);
        qr.getQuickAppId().sendKeys(appid);
        Thread.sleep(1000);
        qr.getQuickAppId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I click on attach document")
    public void i_click_on_attach_document() {
        qr.getpinicon().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @When("I clik on upload button")
    public void i_clik_on_upload_button() throws InterruptedException {
        qr.getUpoadDocument().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        ArrayList<String>tab=new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I Upload the {int} Year Bank Statement")
    public void i_upload_the_year_bank_statement(Integer int1) throws InterruptedException, IOException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        qr.getText();
        Thread.sleep(1000);
        qr.getChooseFile().click();
        Thread.sleep(1000);
        Runtime.getRuntime().exec("AutoITFile/1Year_BankStatement.exe");
        Thread.sleep(2000);
        qr.getCreditQEDSendOTP().click();
        Thread.sleep(1000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @Then("I Upload the Aadhar card")
    public void i_upload_the_aadhar_card() {
    }
    @Then("I Upload the Business Proof")
    public void i_upload_the_business_proof() {

    }
    @Then("I Upload Office Address Proof")
    public void i_upload_office_address_proof() {

    }
    @Then("I Upload PAN Card Proof")
    public void i_upload_pan_card_proof() {

    }
    @Then("I Upload the Photo")
    public void i_upload_the_photo() {
    }
    @When("I Enter the net salary")
    public void i_enter_the_net_salary() throws InterruptedException, IOException, ParseException {
        String netsalary=json.jsonActualReadData("NetMonthlyIcome");
        qr.getNetSalary().sendKeys(netsalary);
        Thread.sleep(1000);
    }
    @When("I Enter the required loan amount for quick loan")
    public void i_enter_the_required_loan_amount_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String salary=json.jsonActualReadData("LoanAmount");
        qr.getRequiredLoanAmount().sendKeys(salary);
        Thread.sleep(1000);
    }
    @And("I close the quick loan flow for bank selection")
    public void i_close_the_quick_loan_flow_for_bank_selection() {
        ArrayList<String>tab=new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Given("I close the chrome browser for all flows")
    public void i_close_the_chrome_browser_for_all_flows() {
        ArrayList<String>tab=new ArrayList<>();
        driver.switchTo().window(tab.get(0));
        end();
    }

}
