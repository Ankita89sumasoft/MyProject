package StepDefination;

import Helper.BaseClass;
import Helper.PropertiesReader;
import Helper.QRCodeHelper;
import Utilities.InputGenerator;
import Utilities.JsonDataReadAndWrite;
//import com.aspose.pdf.internal.imaging.internal.bouncycastle.crypto.engines.TnepresEngine;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.springframework.security.core.parameters.P;
//import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.security.Key;
//import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Negative_QuickLoan extends BaseClass {
    PropertiesReader pro=new PropertiesReader();
    String thankyoudata="Thank you for the request";
    public InputGenerator inputgenerator=new InputGenerator();
    JsonDataReadAndWrite read=new JsonDataReadAndWrite();
    WebDriverWait wait;
    QRCodeHelper qr=null;
    String parentwindow=null;
    JavascriptExecutor js=null;
    @Given("I am on the login page for quick loan")
    public void i_am_on_the_login_page_for_quick_loan() throws IOException, ParseException, InterruptedException, ParseException, java.text.ParseException {
        set();
        Thread.sleep(1000);
        String url=pro.propertyReader("url");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        wait=new WebDriverWait(driver,30);
    }
    @Then("I navigate the home page for the quick loan")
    public void i_navigate_the_home_page_for_the_quick_loan() throws InterruptedException {
        login();
    }

    @When("I click on navigation bar")
    public void i_click_on_navigation_bar() {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I click on channel for quick loan")
    public void i_click_on_channel_for_quick_loan() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
    }
    @When("I click on GenerateQRCode for Quick loan")
    public void i_click_on_generate_qr_code_for_quick_loan() throws InterruptedException {
        qr.getGenerateqrcode().click();
        Thread.sleep(3000);
    }
    @Then("I take the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_take_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @When("I copy the URL for the quick loan")
    public void i_copy_the_url_for_the_quick_loan() throws InterruptedException, IOException, ParseException {
        qr.getCopyURL().click();
        Thread.sleep(2000);
        qr.getClosealter().click();
        Thread.sleep(1000);
        String pastdata=qr.getURL().getAttribute("value");
        System.out.println("Pastdata is"+pastdata);
        Thread.sleep(1000);
        json.jsonWrite("URL",pastdata);
    }
    /*@Then("I search the mobile number for quick loan")
    public void i_search_the_mobile_number_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String searchmobile= json.jsonReadData("MobileNumber");
        qr.getSendMobileNumber().sendKeys(searchmobile);
        Thread.sleep(1000);
        qr.getSendMobileNumber().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
    }*/
    @Then("I switch the tab for Quick loan")
    public void i_switch_the_tab_for_quick_loan() throws IOException, ParseException, InterruptedException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I Switch the child window")
    public void i_switch_the_child_window() throws InterruptedException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
    }
    @When("I select the loan application option")
    public void i_select_the_loan_application_option() throws InterruptedException {
        qr.getLoanApplication().click();
        Thread.sleep(1000);
    }
    @Then("I click on Loans")
    public void i_click_on_loans() throws InterruptedException {
        qr.getLoans().click();
        Thread.sleep(1000);
    }
    @When("I Enter the OTP for the Quick loan")
    public void i_enter_the_otp_for_the_quick_loan() throws IOException, ParseException, InterruptedException {
        String otp=json.jsonReadData("OTP");
        qr.getEnterOTPCreditQDE().sendKeys(otp);
        Thread.sleep(1000);
    }
    @Then("I verify that when user click on the other than quick loan option that time Quick loan respective page should not open")
    public void i_verify_that_when_user_click_on_the_other_than_quick_loan_option_that_time_quick_loan_respective_page_should_not_open() throws InterruptedException {
       List<WebElement>product=new ArrayList<>();
        qr.getInsurance().click();
       product.add(qr.getGeneral_Insurance());
       product.add(qr.getCreaditcardQDE());
       product.add(qr.getInstaLoan());

       int i=0;

       while (i<=2) {
           product.get(i).click();
           Thread.sleep(1000);
           int quickfiels =3;

           ArrayList<WebElement> list1 = new ArrayList<>();
           list1.add(qr.getFormverification());
           int all = list1.size();

           if (quickfiels != all) {

               System.out.println("Quick loan page is not display...");
               driver.navigate().back();
               ngwebdriver.waitForAngularRequestsToFinish();
           } else {
               throw new NullPointerException("Something Went Wrong....");
           }
           i++;
       }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        end();

    }
    @And("I close the browser for respective scenario")
    public void i_close_the_browser_for_respective_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @Then("I click on the quick loan")
    public void i_click_on_the_quick_loan() throws InterruptedException {
        qr.getQuickLoan().click();
        Thread.sleep(1000);
    }
    @Then("I click on personal loan")
    public void i_click_on_personal_loan() throws InterruptedException {
        qr.getPersonalLoan().click();
        Thread.sleep(1000);
    }
    @When("I click on home loan option")
    public void i_click_on_home_loan_option() throws InterruptedException {
        qr.getHomeloan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I click on the Business Loan Option")
    public void i_click_on_the_business_loan_option() throws InterruptedException {
        qr.getBusinessloan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I click on the Loan Against Property Option")
    public void i_click_on_the_loan_against_property_option() throws InterruptedException {
        qr.getLoanagainstproperty().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }

    @Then("I verify the contact details page for quick loan")
    public void i_verify_the_contact_details_page_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String mobile=read.jsonActualReadData("invalidMobileNumber");
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(1000);
        qr.getLabel().click();
        Thread.sleep(1000);
        String verify="Please enter valid mobile number";
        String getVerify=qr.getMobileAlter().getText();
        if (getVerify.equals(verify))
        {
            System.out.println("mobile number verification done");
        }
        else
        {
            throw new InterruptedException("no validation for mobile number....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @When("I Enter the mobile number for quick loan")
    public void i_enter_the_mobile_number_for_quick_loan() throws InterruptedException, IOException, ParseException {
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        inputgenerator.mobileNumberGenerator();
        String mobile=read.jsonReadData("MobileNumber");
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(5000);
        json.jsonWrite("MobileNumber",mobile);
        Thread.sleep(1000);
        qr.getNextButton().click();
        Thread.sleep(2000);
    }
    @When("I click on agree terms and condition")
    public void i_click_on_agree_terms_and_condition() throws InterruptedException {
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getAgreeStatement().click();
        Thread.sleep(1000);
    }
    @Then("I click on terms and condition check box")
    public void i_click_on_terms_and_condition_check_box() throws InterruptedException {
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
    }
    @When("I click on the send OTP for quick loan")
    public void i_click_on_the_send_otp_for_quick_loan() throws InterruptedException {
        qr.getSendOTP().click();
        Thread.sleep(2000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @Then("I clicked on send otp")
    public void i_clicked_on_send_otp() throws InterruptedException {
        qr.getSentOTP().click();
        Thread.sleep(2000);
        qr.getClosealter().click();
        Thread.sleep(1000);
    }

    @When("I switch to parent window for quick loan")
    public void i_switch_to_parent_window_for_quick_loan() throws InterruptedException {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        Thread.sleep(3000);
    }
    @When("I click on the report for quick loan")
    public void i_click_on_the_report_for_quick_loan() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getReport().click();
        Thread.sleep(1000);
        qr.getSMSLog().click();
        Thread.sleep(1000);
    }
    @Then("I refresh the page for quick loan")
    public void i_refresh_the_page_for_quick_loan() throws InterruptedException {
        qr.getRefreshpage().click();
        Thread.sleep(10000);
    }
    @When("I Search the Entered mobile number")
    public void i_search_the_entered_mobile_number() throws IOException, ParseException, InterruptedException {
        String mobilenumber=json.jsonReadData("MobileNumber");
        qr.getSearchdata().sendKeys(mobilenumber);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
        Thread.sleep(35000);
    }
    @When("I get the OTP for quick loan")
    public void i_get_the_otp_for_quick_loan() throws InterruptedException, IOException, ParseException {
        String otp = null;
        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
            this.i_refresh_the_page_for_quick_loan();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_entered_mobile_number();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }
        List<WebElement>list=new ArrayList<WebElement>();
        list.add(qr.getSearchiconFirst());
        list.add(qr.getSearchiconSecond());
        list.add(qr.getSearchiconThird());
        int i=0;
        while (i<3)
        {
            list.get(i).click();
            Thread.sleep(2000);
            int size= qr.getACLSMSDetails().size();
            if (size==10)
            {
                String get_thanks_data=qr.getOTPVerificationContainsText().getText();
                if (get_thanks_data.contains(thankyoudata))
                {
                    otp=get_thanks_data.replaceAll("\\D","");
                    Thread.sleep(1000);
                    json.jsonWrite("OTP",otp);
                    // writedata.setBulkOfData("Sheet1",1,2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if (size==3||size==9)
                {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
                else {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
            else {
                qr.getCloseOTPAlter().click();
                Thread.sleep(2000);
            }
            i++;
        }
        if (otp.isEmpty())
        {
            qr.getCloseOTPAlter().click();
            ngwebdriver.waitForAngularRequestsToFinish();
            this.i_get_the_otp_for_quick_loan();
        }
    }

    @When("I switch to the child window to verify OTP")
    public void i_switch_to_the_child_window_to_verify_otp() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }
    @When("I Enter the OTP in personal loan tab")
    public void i_enter_the_otp_in_personal_loan_tab() throws IOException, ParseException, InterruptedException {
        String otp= json.jsonReadData("OTP");
        // String otp=readexceldata.readExcel("Sheet1","OTP");
        qr.getEnterMobileOTP().sendKeys(otp);
        Thread.sleep(1000);
    }
    @Then("I click on the verify button for quick loan")
    public void i_click_on_the_verify_button_for_quick_loan() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        Thread.sleep(60000);
       // ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @Then("I verify the bank page")
    public void i_verify_the_bank_page() throws InterruptedException {
        WebElement bankpageverify=qr.getBankSelectionPage();
        if (bankpageverify.isDisplayed())
        {
            System.out.println("Bank selection page display");
        }
        else
        {
            throw new InterruptedException("incorrect merchant type pass that why bank page not show");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I verify the submit button should be dispalyed disable format")
    public void i_verify_the_submit_button_should_be_dispalyed_disable_format() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,1000)");

        WebElement button=qr.getSaveAndNextButtonofBankSelection();
        if(!button.isEnabled())
        {
            System.out.println("save and next button is disable format...");
        }
        else {
            throw new InterruptedException("Something want wrong....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the verification of save and next button window")
    public void i_close_the_verification_of_save_and_next_button_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I enter the \"([^\"]*)\"$")
    public void i_enter_the(String string) throws InterruptedException {
        qr.getEnterMobileNumber().sendKeys(string);
        Thread.sleep(1000);
        qr.getLabel().click();
        Thread.sleep(1000);
        String msg="Please enter valid mobile number";
        String getmsg=qr.getMobileAlter().getText();
        if(getmsg.equals(msg))
        {
            System.out.println("mobile verification done correctly...");
        }
        else
        {
            throw new InterruptedException("for mobile number no validation is their...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I Enter \"([^\"]*)\"$")
    public void i_enter(String string) throws InterruptedException {
        qr.getEnterMobileNumber().sendKeys(string);
        Thread.sleep(1000);
        qr.getCreaditNext().click();
        Thread.sleep(1000);
        String msg="Please enter valid mobile number";
        String getmsg=qr.getMobileAlter().getText();
        if(getmsg.equals(msg)&&!qr.getLoanSalutation().isDisplayed())
        {
            System.out.println("mobile verification done correctly...");
        }
        else
        {
            throw new InterruptedException("for mobile number no validation is their...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the mobile verification window")
    public void i_close_the_mobile_verification_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I verify the sent OTP button should be displayed disable format")
    public void i_verify_the_sent_otp_button_should_be_displayed_disable_format() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(1000);
        WebElement button=qr.getSendOTPButton();
        if (!button.isEnabled())
        {
            System.out.println("Sent OTP button should be displayed disable format");
        }
        else {
            throw new InterruptedException("Something want wrong please check again....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the verification of sent OTP button")
    public void i_close_the_verification_of_sent_otp_button() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @When("I Enter the First name in person details for quick loan")
    public void i_enter_the_first_name_in_person_details_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String firstname=json.jsonActualReadData("FirstName");
        qr.getFirstname().sendKeys(firstname);
        Thread.sleep(1000);
    }
    @When("I Enter Last Name for Business Loan")
    public void i_enter_last_name_for_business_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("BusinessLastName");
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last Name for Home Loan")
    public void i_enter_last_name_for_home_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("HomeLastName");
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter Last Name for Loan againstProperty")
    public void i_enter_last_name_for_loan_against_property() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("LoanAgainstLastName");
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Last name for quick loan")
    public void i_enter_the_last_name_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String lastname= json.jsonActualReadData("PersonalLastName");
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Date of Birth for quick loan")
    public void i_enter_the_date_of_birth_for_quick_loan() throws InterruptedException {
        qr.getDOB().click();
        Thread.sleep(1000);
        qr.getCurrentdate().click();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        qr.getYear().click();
        Thread.sleep(1000);
        qr.getMonth().click();
        Thread.sleep(1000);
        qr.getDay().click();
        Thread.sleep(1000);
    }
    @Then("I verify the PAN number in personal Details")
    public void i_verify_the_pan_number_in_personal_details() throws IOException, ParseException, InterruptedException {
        String invalidpan=json.jsonActualReadData("InvalidPAN");
        qr.getPanNumber().sendKeys(invalidpan);
        Thread.sleep(1000);
        qr.getPincodeLabel().click();
        Thread.sleep(1000);
        String getalter=qr.getMobileAlter().getText();
        String data="Please enter a valid pan number";
        if (getalter.equals(data))
        {
            System.out.println("Pan number have verification");
        }
        else {
            throw new InterruptedException("No validation for PAN number");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();

    }
    @When("I Enter the Pan Number in personal Details for quick loan")
    public void i_enter_the_pan_number_in_personal_details_for_quick_loan() throws InterruptedException, IOException, ParseException {
       // String pannumber=json.jsonActualReadData("panno");
        qr.getPanNumber().sendKeys(inputgenerator.panCardNumber());
        Thread.sleep(1000);
    }
    @When("I Enter the pincode in personal details for quick loan")
    public void i_enter_the_pincode_in_personal_details_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String pincode= json.jsonActualReadData("pincodeno");
        qr.getPDppincode().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @When("I enter the netsalary")
    public void i_enter_the_netsalary() throws IOException, ParseException, InterruptedException {
        String pincode= json.jsonActualReadData("NetMonthlyIcome");
        qr.getNetMonthlyIcome().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @Then("I Keep the net salery field bank")
    public void i_keep_the_net_salery_field_bank() throws IOException, ParseException, InterruptedException {
        qr.getNetMonthlyIcome().sendKeys("");
        Thread.sleep(1000);
    }
    @When("I Enter the required loan amount for negative scenario of quick loan")
    public void i_enter_the_required_loan_amount_for_negative_scenario_of_quick_loan() throws IOException, ParseException, InterruptedException {
        String pincode= json.jsonActualReadData("LoanAmount");
        qr.getRequiredLoanAmount().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @Then("I Enter the required loan amount")
    public void i_enter_the_required_loan_amount() throws IOException, ParseException, InterruptedException {
        String loanamount=json.jsonActualReadData("LoanAmount");
        qr.getQuickLoanAmount().sendKeys(loanamount);
        Thread.sleep(1000);
    }
    @Then("I click on the save and next button for quick loan")
    public void i_click_on_the_save_and_next_button_for_quick_loan() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        qr.getSaveAndNext().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I choose the occupation for quick loan")
    public void i_choose_the_occupation_for_quick_loan() throws InterruptedException {
        qr.getOccupation().click();
        Thread.sleep(1000);
    }

    @Then("I verify that click on anywhere rather agree button in than terms and condition page still terms and condition page is open")
    public void i_verify_that_click_on_anywhere_rather_agree_button_in_than_terms_and_condition_page_still_terms_and_condition_page_is_open() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-10000)");
        for (int i=0;i<=3;i++) {
            qr.getTerm().click();
            Thread.sleep(1000);
            if(qr.getTermDisplayPage().isDisplayed())
            {
                System.out.println("term and condition page is display...");
            }
            else {
                throw new InterruptedException("Something wants wrong with term and condition page  please check again...");
            }
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the verification of terms and condition window")
    public void i_close_the_verification_of_terms_and_condition_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("verify that user should be able to open & close multiple time Terms and Conditions page")
    public void verify_that_user_should_be_able_to_open_close_multiple_time_terms_and_conditions_page() throws InterruptedException {
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getAgreeStatement().click();
        Thread.sleep(1000);
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getAgreeStatement().click();
        Thread.sleep(1000);
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @And("I close the open & close multiple time Terms and Conditions page")
    public void i_close_the_open_close_multiple_time_terms_and_conditions_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I keep the mobile field is to be blank")
    public void i_keep_the_mobile_field_is_to_be_blank() throws InterruptedException {
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        qr.getEnterMobileNumber().sendKeys("");
        Thread.sleep(1000);
    }
    @When("I verify the send OTP button is disable or not")
    public void i_verify_the_send_otp_button_is_disable_or_not() {

    }

    @Then("I verify that the OTP is generate for second time after click resend OTP button")
    public void i_verify_that_the_otp_is_generate_for_second_time_after_click_resend_OTP_button() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(15000);
        if(!(wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()=' Resend OTP '])[1]"))) ==null))
        {
            qr.getResendOTP().click();
            Thread.sleep(1000);
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("Resend OTP sended.....");
        }
        else
        {
            throw new InterruptedException("Enable to click on resend button...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I close the resend OTP scenario")
    public void i_close_the_resend_otp_scenario() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I verify the enter OTP field when OTP is not generated")
    public void i_verify_the_enter_otp_field_when_otp_is_not_generated() throws InterruptedException {
       if(!qr.getEnterMobileNumber().isDisplayed())
       {
           System.out.println("Enter OTP field is not present");
       }
       else {
           throw new InterruptedException("Something want wrong please try again...");
       }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the Verification of the enter OTP page")
    public void i_close_the_verification_of_the_enter_otp_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I do mutiple time OTP Verification")
    public void i_do_mutiple_time_otp_verification() throws InterruptedException, IOException, ParseException {
        String data=json.jsonActualReadData("invalidOTP");
        qr.getEnterOTPCreditQDE().sendKeys(data);
        Thread.sleep(1000);
        qr.getVerifyCreditQDE().click();
        Thread.sleep(5000);
        String msg="Failure";
        String getmsg=qr.getOTPAlter().getText();
        if (qr.getAlter().isDisplayed()&&getmsg.equals(msg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter is their");
        }
        else {
            throw new InterruptedException("1st time OTP verification is wrong...");
        }

        String data2=json.jsonActualReadData("invalid_OPT2");
        qr.getEnterOTPCreditQDE().clear();
        Thread.sleep(1000);
        qr.getEnterOTPCreditQDE().sendKeys(data2);
        Thread.sleep(1000);
        qr.getVerifyCreditQDE().click();
        Thread.sleep(5000);
        if (qr.getAlter().isDisplayed())
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter is their");
        }
        else {
            throw new InterruptedException("2nd time OTP verification is wrong...");
        }


        String data3=json.jsonActualReadData("invalid_OPT3");
        qr.getEnterOTPCreditQDE().clear();
        Thread.sleep(1000);
        qr.getEnterOTPCreditQDE().sendKeys(data3);
        Thread.sleep(1000);
        qr.getVerifyCreditQDE().click();
        Thread.sleep(5000);
        if (qr.getAlter().isDisplayed())
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter is their");
        }
        else {
            throw new InterruptedException("3nd time OTP verification is wrong...");
        }

        String data4=json.jsonActualReadData("invalid_OPT4");
        qr.getEnterOTPCreditQDE().clear();
        Thread.sleep(1000);
        qr.getEnterOTPCreditQDE().sendKeys(data4);
        Thread.sleep(1000);
        qr.getVerifyCreditQDE().click();
        Thread.sleep(5000);

        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I enter invalid OTP")
    public void i_enter_invalid_otp() throws IOException, ParseException, InterruptedException {
        String data=json.jsonActualReadData("invalidOTP");
        qr.getEnterOTPCreditQDE().sendKeys(data);
        Thread.sleep(1000);
        qr.getVerifyButton().click();
        Thread.sleep(5000);
        if (qr.getAlter().isDisplayed())
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter is their");
        }
        else {
            throw new InterruptedException("1st time OTP verification is wrong...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I switch the parent tab")
    public void i_switch_the_parent_tab() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
    }

    @And("I close the multiple opt verification window")
    public void i_close_the_multiple_opt_verification_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @And("I close the verification of contact details")
    public void i_close_the_verification_of_contact_details() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I verify the App id should not generated")
    public void i_verify_the_app_id_should_not_generated() throws InterruptedException {
        String data="No data available";
        String getdata=qr.getTextOfApplicationId().getText();
        if(getdata.equals(data))
        {
            System.out.println("Application working fine");
        }
        else {
            throw new InterruptedException("Entering invalid OTP but still show the application ID....");
        }
        Thread.sleep(1000);
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the App id should not generated page")
    public void i_close_the_app_id_should_not_generated_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I verify the first name and Last Name")
    public void i_verify_the_first_name_and_last_name() throws IOException, ParseException, InterruptedException {
        String firstname=json.jsonActualReadData("InvalidFirstName");
        String firstnamealter="Please enter a valid first name";
        qr.getFirstname().sendKeys(firstname);
        Thread.sleep(1000);
        qr.getFirstNameLabel().click();
        Thread.sleep(1000);
        String verifyalterforFirstName=qr.getMobileAlter().getText();
        if (verifyalterforFirstName.equals(firstnamealter))
        {
            System.out.println("Verification done for first name successfully...");
        }
        else {
            throw new InterruptedException("No validation for the first name...");
        }
        String lastname=json.jsonActualReadData("InvalidLastName");
        String lastnamealter="Please enter a valid last name";
        qr.getPdLastName().sendKeys(lastname);
        Thread.sleep(1000);
        qr.getLastNameLabel().click();
        Thread.sleep(1000);
        String getLastnameVerification=qr.getLastNameVerification().getText();
        if (getLastnameVerification.equals(lastnamealter))
        {
            System.out.println("Verification done for last name successfully...");
        }
        else {
            throw new InterruptedException("No validation for the last name...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @Then("I close the mandatory field is required alert should be displayed page")
    public void i_close_the_mandatory_field_is_required_alert_should_be_displayed_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I Verify the Date of Birth field for quick loan")
    public void i_verify_the_date_of_birth_field_for_quick_loan() throws InterruptedException, IOException, ParseException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,80)");
        Thread.sleep(1000);
        qr.getDOB().click();
        Thread.sleep(1000);
        String dob=json.jsonActualReadData("InvalidDOB");
        qr.getDateOfBirth().click();
        Thread.sleep(1000);
        qr.getDateOfBirth().sendKeys(dob);
        Thread.sleep(1000);
        String verification=qr.getDateOfBirth().getText();
        String jsonverify="Invalid date";
        if (verification.equals(jsonverify))
        {
            System.out.println("Date of birth have validation");
        }
        else {
            throw new InterruptedException("Date of birth field don't have any validation please check...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the date of birth validation page")
    public void i_close_the_date_of_birth_validation_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }

    @Then("I Keep DOB field blank")
    public void i_keep_dob_field_blank() throws InterruptedException {
        qr.getDOB().click();
        Thread.sleep(1000);
        WebElement button=qr.getSaveAndNextButtonofBankSelection();
        if(!button.isEnabled())
        {
            System.out.println("System have correct flow");
        }
        else {
            throw new InterruptedException("button is enable please check agian.......");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I Save And Next button should be displayed disabled format window")
    public void i_save_and_next_button_should_be_displayed_disabled_format_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @And("I close the PAN verify window")
    public void i_close_the_pan_verify_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I verify the Pincode for quick loan")
    public void i_verify_the_pincode_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String invalidpincode=json.jsonActualReadData("InvalidPincode");
        qr.getPDppincode().sendKeys(invalidpincode);
        Thread.sleep(1000);
        qr.getNetIcomeLabel().click();
        Thread.sleep(2000);
        String data="Please enter valid pincode";
        String getalter=qr.getValidPin().getText();
        if (getalter.equals(data))
        {
            System.out.println("Pan number have verification");
        }
        else {
            throw new InterruptedException("No validation for PAN number");
        }
    }
    @And("I close the verification of pincode for Quick loan")
    public void i_close_the_verification_of_pincode_for_quick_loan() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I keep the first name to be bank")
    public void i_keep_the_first_name_to_be_bank() throws InterruptedException {
        qr.getFirstname().click();
        Thread.sleep(1000);
        qr.getFirstname().sendKeys(Keys.TAB);
        Thread.sleep(1000);
    }
    @Then("I verify the save and next button")
    public void i_verify_the_save_and_next_button() throws InterruptedException {
        if(!qr.getSaveAndNextButton().isEnabled())
        {
            System.out.println("Some fields are blank");
        }
        else
        {
            throw new InterruptedException("Something want wrong please try again...");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the save and next button verification page")
    public void i_close_the_save_and_next_button_verification_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("verify the occuption option for quick loan")
    public void verify_the_occuption_option_for_quick_loan() throws InterruptedException {
        List<WebElement>list=new ArrayList<WebElement>();
        list.add(qr.getOccuption());
        int getsize=list.size();
        if (getsize==1)
        {
            System.out.println("All options ia available");
        }
        else {
            throw new InterruptedException("Some Option is missing please check");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the verification occuption option window")
    public void i_close_the_verification_occuption_option_window() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }
    @Then("I refresh the page for negative scerio")
    public void i_refresh_the_page_for_negative_scerio() throws InterruptedException {
        qr.getRefreshpage().click();
        Thread.sleep(10000);
    }
    @Then("I get OTP for quick loan")
    public void i_get_otp_for_quick_loan() throws InterruptedException, IOException, ParseException {
        String otp = null;
        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
           this.i_refresh_the_page_for_negative_scerio();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_mobile_number_for_quick_loan();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }
        List<WebElement>list=new ArrayList<WebElement>();
        list.add(qr.getSearchiconFirst());
        list.add(qr.getSearchiconSecond());
        list.add(qr.getSearchiconThird());
        int i=0;
        while (i<3)
        {
            list.get(i).click();
            Thread.sleep(2000);
            int size=qr.getACLSMSDetails().size();
            if (size==10)
            {
                String get_thanks_data=qr.getOTPVerificationContainsText().getText();
                if (get_thanks_data.contains(thankyoudata))
                {
                    otp=get_thanks_data.replaceAll("\\D","");
                    Thread.sleep(1000);
                    json.jsonWrite("OTP",otp);
                    // writedata.setBulkOfData("Sheet1",1,2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if (size==3||size==9)
                {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
                else {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
            else {
                qr.getCloseOTPAlter().click();
                Thread.sleep(2000);
            }
            i++;
        }
        if (otp.isEmpty())
        {
            qr.getCloseOTPAlter().click();
            ngwebdriver.waitForAngularRequestsToFinish();
            this.i_get_otp_for_quick_loan();
        }
    }
    @Then("I click on the loan application option")
    public void i_click_on_the_loan_application_option() throws InterruptedException {
        qr.getLoans().click();
        Thread.sleep(1000);
        qr.getLoanApplication().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I click on the report drop-down for quick laon")
    public void i_click_on_the_report_drop_down_for_quick_laon() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getReport().click();
        Thread.sleep(1000);
        qr.getSMSLog().click();
        Thread.sleep(1000);
    }
    @When("I click of navigation bar for Quick loan")
    public void i_click_of_navigation_bar_for_quick_loan() throws InterruptedException {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        Thread.sleep(1000);
    }

    @When("pick in the {string} as {string} for Quick loan")
    public void pick_in_the_as_for_quick_loan(String string, String string2) throws InterruptedException {
        driver.findElement(By.xpath("//a[text()='"+string+"']")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[text()='"+string2+"']")).click();
        Thread.sleep(5000);
    }

    @Then("I click on the refresh SMS page for for Quick loan")
    public void i_click_on_the_refresh_sms_page_for_for_quick_loan() throws InterruptedException {
        qr.getRefreshpage().click();
        Thread.sleep(9000);
    }

    @When("I search the mobile number for Quick loan")
    public void i_search_the_mobile_number_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String mobiledata = json.jsonReadData("MobileNumber");
        qr.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
        Thread.sleep(30000);
    }
    @Then("I search the mobile number for the validation")
    public void i_search_the_mobile_number_for_the_validation() throws IOException, ParseException, InterruptedException {
        String mobiledata = json.jsonReadData("MobileNumber");
        qr.getSearchMobileNo().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchMobileNo().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I search the mobile number for negative flow")
    public void i_search_the_mobile_number_for_negative_flow() throws IOException, ParseException, InterruptedException {
        String mobiledata = json.jsonReadData("MobileNumber");
        qr.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
       // ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(25000);
    }

    @When("I get the OTP in SMS log for Quick loan")
    public void i_get_the_otp_in_sms_log_for_quick_loan() throws InterruptedException, IOException, ParseException {
        String otp=null;

        Actions act=new Actions(driver);
        act.moveToElement(qr.getRefreshpage()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        List<WebElement> list = new ArrayList<WebElement>();

        String mobiledata = json.jsonReadData("MobileNumber");
        qr.getSearchdata().clear();
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
        //Thread.sleep(30000);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(6000);

        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
            act.moveToElement(qr.getRefreshpage()).click().build().perform();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(10000);
            qr.getSearchdata().sendKeys(mobiledata);
            Thread.sleep(1000);
            qr.getSearchdata().sendKeys(Keys.ENTER);
            Thread.sleep(10000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }

        list.add(qr.getClickFirstSearchIcon());
        list.add(qr.getClickSecondSearchIcon());
        list.add(qr.getSearchThird());
        list.add(qr.getSearchFourth());
        int i = 0;
        while (i <4) {
            Thread.sleep(2000);
            list.get(i).click();
            Thread.sleep(1000);
            int size=qr.getACLSMSDetails().size();
            System.out.println("div size is" + size);
            if(size==10)
            {
                String condition =qr.getOTPVerificationContainsText().getText();
                if(condition.contains(thankyoudata)){
                    otp = String.valueOf(Integer.parseInt(condition.replaceAll("\\D", "")));
                    System.out.println(otp);
                    json.jsonWrite("OTP",otp);
                    //writedata.setBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if(size==3||size==9)
                {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
                else {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
            else {
                qr.getCloseOTPAlter().click();
                Thread.sleep(2000);
            }
            i++;
        }
        if (otp==null)
        {
            qr.getCloseOTPAlter().click();
            ngwebdriver.waitForAngularRequestsToFinish();
            this.i_get_the_otp_in_sms_log_for_quick_loan();
        }
    }

    @Then("I click on the child tab for Quick loan")
    public void i_click_on_the_child_tab_for_quick_loan() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }

    @Then("I enter the OTP for Quick loan")
    public void i_enter_the_otp_for_quick_loan() throws IOException, ParseException, InterruptedException {
        JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,350)");
        String OTP=json.jsonReadData("OTP");
        qr.getEnterOTPCreditQDE().sendKeys(OTP);
        Thread.sleep(5000);

    }

    @When("I Click on Submit OTP for Quick loan")
    public void i_click_on_submit_otp_for_quick_loan() throws InterruptedException {
        qr.getVerifyButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }

    @When("I accept the ok alter for Quick loan")
    public void i_accept_the_ok_alter_for_quick_loan() throws InterruptedException {
        qr.getClosealter().click();
        Thread.sleep(1000);
    }

    @Then("I select the {string} as {string} for Quick loan")
    public void i_select_the_as_for_quick_loan(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }

    @Then("I Enter the current address for Quick loan")
    public void i_enter_the_current_address_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String currentAddress=read.jsonActualReadData("CurrentAddress");
        qr.getCurrentAddress().sendKeys(currentAddress);
        Thread.sleep(1000);
    }

    @Then("I Enter Email Address for Quick loan")
    public void i_enter_email_address_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String emailID=read.jsonActualReadData("OfficialEmail_id");
        qr.getEmaild().clear();
        Thread.sleep(1000);
        qr.getEmaild().sendKeys(emailID);
        Thread.sleep(2000);
    }

    @Then("I Enter the loan amount for Quick loan")
    public void i_enter_the_loan_amount_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String loanAmt=read.jsonActualReadData("LoanAmount");
        qr.getLoanAmt().clear();
        Thread.sleep(1000);
        qr.getLoanAmt().sendKeys(loanAmt);
        Thread.sleep(1000);
    }

    @Then("I Enter the Net Monthly income for Quick loan")
    public void i_enter_the_net_monthly_income_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String NetIncome=read.jsonActualReadData("NetMonthlyIcome");
        qr.getNetMonthlyIcome().sendKeys(NetIncome);
        Thread.sleep(1000);
    }

    @Then("I select {string} as {string}")
    public void i_select_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }

    @Then("I Enter the Pincode for Quick loan")
    public void i_enter_the_pincode_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String pincode=read.jsonActualReadData("pincodeno");
        qr.getOffiPin().sendKeys(pincode);
        Thread.sleep(1000);
    }

    @Then("I verify the submit button should be displayed disable format for Quick loan")
    public void i_verify_the_submit_button_should_be_displayed_disable_format_for_quick_loan() throws InterruptedException {
        if (!qr.getSubmit().isEnabled())
        {
            System.out.println("Sent OTP button should be displayed disable format");
        }
        else {
            throw new InterruptedException("Something want wrong please check again....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @Then("I close the verification of submit button window for Quick loan")
    public void i_close_the_verification_of_submit_button_window_for_quick_loan() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }

    @When("I enter Required loan amount for quick loan")
    public void i_enter_required_loan_amount_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String Amount=read.jsonActualReadData("LoanAmount");
        qr.getLoanAmount().sendKeys(Amount);
        Thread.sleep(2000);
    }

    @Then("I Enter the invalid Pincode for Quick loan")
    public void i_enter_the_invalid_pincode_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String pincode=json.jsonActualReadData("Invalidalphapincode");
        qr.getOfficePincode().sendKeys(pincode);
        Thread.sleep(1000);
        qr.getOfficePinCodeLabel().click();
        Thread.sleep(1000);
    }

    @Then("I verify the please enter valid pincode alert displayed or not")
    public void i_verify_the_please_enter_valid_pincode_alert_displayed_or_not() {
        String alter=qr.getMobileAlter().getText();
        String msg="Please enter valid pincode";
        if (alter.equals(msg)) {
            System.out.println("system showing alert Pincode is invalid");
        }
        else
        {
            throw new IllegalArgumentException("Pincode is invalid alert is not showing....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @Then("I Enter the invalid loan amount for Quick loan")
    public void i_enter_the_invalid_loan_amount_for_quick_loan() throws InterruptedException, IOException, ParseException {
        String loanamt=json.jsonActualReadData("InvalidLoanAmount");
        qr.getCurrentAddress().sendKeys(loanamt);
        Thread.sleep(1000);
        qr.getLoanAmountLabel().click();
        Thread.sleep(1000);
    }

    @Then("I enter the less than six digit otp for Quick loan")
    public void i_enter_the_less_than_six_digit_otp_for_quick_loan() throws IOException, ParseException, InterruptedException {
        String invalidotp=json.jsonActualReadData("InvalidOTPBank");
        qr.getOTPEnter().sendKeys(invalidotp);
        Thread.sleep(1000);
    }

    @Then("I verify the Verify_OTP button should be displayed disable format")
    public void i_verify_the_verify_otp_button_should_be_displayed_disable_format() throws InterruptedException {
        WebElement button=driver.findElement(By.xpath("//button[text()='Verify OTP']"));
        if (!button.isEnabled())
        {
            System.out.println("Sent OTP button should be displayed disable format");
        }
        else {
            throw new InterruptedException("Something want wrong please check again....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @Then("I enter the less than six digit or alphanumaric {string} for Quick loan")
    public void iEnterTheLessThanSixDigitOrAlphanumaricForQuickLoan(String arg0) throws InterruptedException {
        Thread.sleep(1000);
        qr.getOTPEnter().sendKeys(arg0);
        Thread.sleep(1000);
        qr.getDivMainOTP().click();
        Thread.sleep(1000);
    }

    @Then("I verify the please enter valid OTP alert displayed or not")
    public void iVerifyThePleaseEnterValidOTPAlertDisplayedOrNot() throws NoSuchFieldException
    {
        String msg="Please enter valid OTP";
        String alter=qr.getMobileAlter().getText();
        if (alter.equals(msg))
        {
            System.out.println("system showing the please enter valid OTP alert");
        }else
        {
            throw new NoSuchFieldException("alert is not showing");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @Then("I enter the expired OTP for quick loan")
    public void i_enter_the_expired_otp_for_quick_loan() throws InterruptedException, IOException, ParseException {
        String otp= json.jsonActualReadData("invalidOTP");
        qr.getOTPEnter().sendKeys(otp);
        Thread.sleep(1000);
    }

    @Then("I verify the OTP is either invalid or expired alert displayed or not")
    public void i_verify_the_otp_is_either_invalid_or_expired_alert_displayed_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(1000);
        qr.getVerifyOTP().click();
        Thread.sleep(5000);
        if (qr.getAlter().isDisplayed())
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("system showing alert OTP either invalid or expired");
        } else {
            throw new IllegalArgumentException("OTP either invalid or expired alert is not showing....");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();

    }

    @Then("I Enter the invalid value of Net Monthly income for Quick loan")
    public void i_enter_the_invalid_value_of_net_monthly_income_for_quick_loan() throws InterruptedException {
        qr.getNetMonthlyIcome().sendKeys("46674hghr");
        Thread.sleep(2000);
    }

    @Then("I Verify the please enter valid amount alert displayed or not")
    public void i_verify_the_please_enter_valid_amount_alert_displayed_or_not() throws NoSuchFieldException
    {
        String msg="Please enter valid amount";
        String getmsg=qr.geterrorMsg().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("system showing the Please enter valid amount alert");
        }
        else {
            throw new NoSuchFieldException("alert is not showing");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }

    @Then("I enter invalid value for loan amount for Quick loan")
    public void i_enter_invalid_value_for_loan_amount_for_quick_loan() throws InterruptedException {
        qr.getLoanAmt().sendKeys("467uyg");
        Thread.sleep(1000);
        qr.getLoanAmountLabel().click();
        Thread.sleep(1000);
    }

    @Then("I Enter invalid Email Address for Quick loan")
    public void i_enter_invalid_email_address_for_quick_loan() throws InterruptedException {
        qr.getEmaild().sendKeys("t274764gmailcom");
        Thread.sleep(2000);
    }

    @Then("I Verify the please enter valid email alert displayed or not")
    public void i_verify_the_please_enter_valid_email_alert_displayed_or_not() throws NoSuchFieldException {
        String msg="Please enter valid email";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg)){
            System.out.println("system showing the Please enter valid email alert");
        }
        else {
            throw new NoSuchFieldException("alert is not showing");
        }
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(1));
        end();
    }
    @And("I close the verification of page")
    public void i_close_the_verification_of_page() {
        ArrayList<String>tab=new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tab.get(0));
        end();
    }









}
