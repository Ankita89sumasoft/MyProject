package StepDefination;

import Helper.BaseClass;
import Helper.PropertiesReader;
import Helper.QRCodeHelper;
import Utilities.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.eo.Se;
import io.cucumber.java.sl.In;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import javax.swing.text.Document;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.security.Key;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Negative_QRCodeGeneration extends BaseClass {
    PropertiesReader pro=new PropertiesReader();
    QRCodeHelper qr=null;
    WriteExcelData writedata=new WriteExcelData();
    JavascriptExecutor js;
    String parentwindow=null;
    ReadExcelData readdata=new ReadExcelData();
    WebDriverWait wait;
    Random random=new Random();
    JsonDataReadAndWrite json=new JsonDataReadAndWrite();

    FinequsReadData readfinequsdata=new FinequsReadData();
    public InputGenerator inputGenerator=new InputGenerator();
    String data="Thank you for the request";
    @Given("I am on the login page")
    public void i_am_on_the_login_page() throws InterruptedException, IOException, ParseException, ParseException, java.text.ParseException {
        set();
        Thread.sleep(1000);
        String url=pro.propertyReader("url");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
       this.wait=new WebDriverWait(driver, 40);
    }
    @When("I Fill userid with \"([^\"]*)\"$")
    public void i_fill_userid_with(String string) throws InterruptedException {
        qr=new QRCodeHelper();
        qr.getLogin_Email_Id().sendKeys(string);
        Thread.sleep(1000);
    }
    @When("fill password field with \"([^\"]*)\"$")
    public void fill_password_field_with(String string) throws InterruptedException {
        qr.getPassword().sendKeys(string);
        Thread.sleep(1000);
    }
    @When("click on login button")
    public void click_on_login_button() throws InterruptedException {
        qr.getLoginSubmit().click();
        Thread.sleep(2000);
      /*  if(!qr.getLoginAlterVerificaton().isDisplayed())
        {
            throw new InterruptedException("system allow alphanumberic and numberic value also");
        }*/
       String alter = "Email must be a valid email address";
        String getaltermessage = qr.getLoginAlterVerificaton().getText();
        if(alter.equals(getaltermessage)) {
             System.out.println("for login their is validation...");
        }
        else{

            throw new InterruptedException("system not allowed invalid data...");
        }
    }

    @Then("I not able to see home page")
    public void i_not_able_to_see_home_page() {
        driver.close();
    }
    @When("I am navigate to home page")
    public void i_am_navigate_to_home_page() throws InterruptedException {
        login();
    }

    @When("I Click on the navigation bar")
    public void i_click_on_the_navigation_bar() throws InterruptedException {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I click on the channel drop-down")
    public void i_click_on_the_channel_drop_down() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
    }
    @When("I select the generate QR code option")
    public void i_select_the_generate_qr_code_option() throws InterruptedException {
        qr.getGenerateqrcode().click();
        Thread.sleep(3000);
    }
    @Then("I Keep Blank for the Generate for dropdown")
    public void i_keep_blank_for_the_generate_for_dropdown() throws InterruptedException {
        qr.getGenerateFor().click();
        Thread.sleep(1000);
        qr.getGenerateFor().sendKeys(Keys.TAB);
        Thread.sleep(1000);
    }
    @Then("I choose in the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_choose_in_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @Then("I Select the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_select_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @When("I copy the url")
    public void i_copy_the_url() throws IOException, InterruptedException, ParseException, org.json.simple.parser.ParseException {
        qr.getCopyURL().click();
        Thread.sleep(2000);
        qr.getClosealter().click();
        Thread.sleep(1000);
        String pastdata=qr.getURL().getAttribute("value");
        System.out.println("Pastdata is"+pastdata);
        Thread.sleep(1000);
        json.jsonWrite("URL",pastdata);
       // writedata.setBulkOfData("Sheet1",1,0,pastdata);
    }
    @When("I switch to the child tab")
    public void i_switch_to_the_child_tab() throws IOException, InterruptedException, ParseException, org.json.simple.parser.ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);

    }
    @And("system should not be display welcome page")
    public void system_should_not_be_display_welcome_page() throws InterruptedException, IOException, ParseException {
      /*  ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);*/
        String url=json.jsonReadData("URL");
        //driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        if (url.isEmpty())
        {
            System.out.println("system should not be display welcome page");
        }
        else
        {
            throw new InterruptedException("system should is display welcome page");
        }
       /* if(qr.getChildWindowElement().isDisplayed())
        {
            System.out.println("page is displayed successfully");
        }
        else {
            throw new NullPointerException("welcome child window page to much time to load...");
        }*/
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(1000);
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @Then("I move the tab")
    public void i_move_the_tab() throws IOException, InterruptedException, AWTException, ParseException, org.json.simple.parser.ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        driver.get(url);
        Thread.sleep(8000);
        System.out.println("Zoom in");
        Robot robot=new Robot();
        for (int i=0;i<4;i++)
        {
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ADD);
            robot.keyRelease(KeyEvent.VK_ADD);
            robot.keyRelease(KeyEvent.VK_CONTROL);
        }
        Thread.sleep(3000);
        System.out.println("Zoom out");
        for (int i=0;i<4;i++)
        {
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_SUBTRACT);
            robot.keyRelease(KeyEvent.VK_SUBTRACT);
            robot.keyRelease(KeyEvent.VK_CONTROL);
        }
        Thread.sleep(3000);
        driver.close();
        Thread.sleep(2000);
    }
    @Then("Message should not be goes to out the box")
    public void message_should_not_be_goes_to_out_the_box() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
     driver.close();
    }
    @When("I switch to the another tab")
    public void i_switch_to_the_another_tab() throws IOException, InterruptedException, ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        //Thread.sleep(5000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(1000);
        //--------------------------Move hover--------------------------------------
        Actions act=new Actions(driver);
       // act.moveByOffset(460,540).click().build().perform();
        act.moveToElement(qr.getRow()).perform();
        Thread.sleep(2000);
        driver.close();
        Thread.sleep(2000);
    }
    @And("Without hover call us icon should not display popup Call us number")
    public void without_hover_call_us_icon_should_not_display_popup_call_us_number() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @And("Without hover message us icon should not display popup Call us number")
    public void without_hover_message_us_icon_should_not_display_popup_call_us_number() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @And("I control the tab")
    public void i_control_the_tab() throws IOException, InterruptedException, ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        driver.get(url);
        Thread.sleep(5000);
    }
    @Then("I Choose the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_choose_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@id='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(2000);
    }
    @Then("I put the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_put_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@id='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @And("After reselecting Language drop down, Menu should be showing in selected language only")
    public void after_reselecting_language_drop_down_menu_should_be_showing_in_selected_language_only() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I click on insta loan option")
    public void i_click_on_insta_loan_option() throws InterruptedException {
        qr.getOtherLangInstaLoan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        ngwebdriver.waitForAngularRequestsToFinish();
     js = (JavascriptExecutor) driver;

        String language = js.executeScript("return window.navigator.userlanguage || window.navigator.language").toString();
        if (language.equalsIgnoreCase("en-US"))
        {
            System.out.println("language is English");
        }else {
            throw new NullPointerException("Language is another");
        }
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @And("Only Menu Page should be showing in selected language other pages should be English Only")
    public void only_menu_page_should_be_showing_in_selected_language_other_pages_should_be_english_only() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I click on the credit card option")
    public void i_click_on_the_credit_card_option() throws InterruptedException {
        qr.getCreaditcardQDE().click();
        Thread.sleep(5000);

        ArrayList<WebElement>fields=new ArrayList<WebElement>();
        fields.add(qr.getEnterMobileNumber());
       // fields.add(qr.getTickCheckBox());
       // fields.add(qr.getSendOTP())
        int i=0;
        while (i<fields.size())
        {
            if (fields.get(i).isDisplayed())
            {
                System.out.println("Field is present");
                ngwebdriver.waitForAngularRequestsToFinish();
            }

            else {
                throw new NullPointerException("Field is not present");
            }
            WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[text()=' Send OTP '])[1]")));

            if (element.isDisplayed())
            {
                System.out.println("element is present");
            }
            else {
                System.out.println("element is not present");
            }

            i++;
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(1000);
    }
    @And("that the System should display on the CreditQDE page")
    public void that_the_system_should_display_on_the_credit_qde_page() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @And("I click on the insurance")
    public void i_click_on_the_insurance() throws InterruptedException {
        qr.getInsurance().click();
        Thread.sleep(1000);
        qr.getGeneral_Insurance().click();
        Thread.sleep(1000);
        ArrayList<WebElement>fields=new ArrayList<WebElement>();
        fields.add(qr.getInsurance_mobile());
        fields.add(qr.getInsurance_salutation());
        fields.add(qr.getInsurance_firstname());
        fields.add(qr. getInsurance_lastname());
        fields.add(qr.getInsurance_dob());
        fields.add(qr.getInsurance_Geneder());
        fields.add(qr. getInsurance_Email());
        //fields.add(qr.getInsurance_Finish());
        //fields.add(qr.getInsurance_Cancel());
        int i=0;
        while (i<fields.size())
        {
            if (fields.get(i).isDisplayed())
            {
                System.out.println("Field is available");
            }
            else {
                throw new NullPointerException("Field is not available");
            }
            i++;
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(1000);
    }
    @And("the System should display on the Insurance page")
    public void the_system_should_display_on_the_insurance_page() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @And("I click on insta loan")
    public void i_click_on_insta_loan() {
        ngwebdriver.waitForAngularRequestsToFinish();
        qr.getInstaLoan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I Enter the \"([^\"]*)\"$")
    public void i_enter_the(String string) throws InterruptedException {
        qr.getSearchMobileNo().sendKeys(string);
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(2000);
    }
    @And("System should displayed alert when user enter number less than {int} digit")
    public void system_should_displayed_alert_when_user_enter_number_less_than_digit(Integer int1) {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @And("System should allow user to enter firstname in the field and enter name should display on the field")
    public void system_should_allow_user_to_enter_firstname_in_the_field_and_enter_name_should_display_on_the_field() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I Entered the mobile number")
    public void i_entered_the_mobile_number() throws InterruptedException, IOException, ParseException {
        driver.findElement(By.xpath("//div[@class='container mt-3 mt-lg-5']")).click();
        inputGenerator.mobileNumberGenerator();
        String data=json.jsonReadData("MobileNumber");
        qr.getMobilenumber().sendKeys(data);
        Thread.sleep(1000);
    }
    @Then("I verify the pincode in the insta loan")
    public void i_verify_the_pincode_in_the_insta_loan() throws IOException, InterruptedException, ParseException {
        String incorrectpincode=json.jsonActualReadData("uincorrectpin");
        qr.getPincode().sendKeys(incorrectpincode);
        Thread.sleep(2000);
        String msg="Pincode is invalid";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            System.out.println("Pincode have validation...");
        }
        else {
            throw new InterruptedException("Pincode dont have any validation please check...");
        }
        /*qr.getLabelPincode().click();
        Thread.sleep(1000);*/

        qr.getPincode().clear();
        Thread.sleep(1000);
        qr.getPincode().clear();
        Thread.sleep(1000);
        qr.getPincode().sendKeys("$#@&");
        Thread.sleep(2000);
        qr.getLabelPincode().click();
        Thread.sleep(1000);
        String msg1="Please enter valid Pincode.";
        String getmsg1=qr.getPincodeLabelVerify().getText();
        if (getmsg1.equals(msg1))
        {
            System.out.println("for special character Pincode have validation...");
        }
        else {
            throw new InterruptedException("For special charater Pincode dont have any validation please check...");
        }

        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @When("I Enter the First name in insta loan QDE")
    public void i_enter_the_first_name_in_insta_loan_qde() throws IOException, InterruptedException, ParseException {
        String firstname=json.jsonActualReadData("firstnameverification");
        Actions act=new Actions(driver);
        act.moveToElement(qr.getFirstName()).doubleClick();
        Thread.sleep(2000);
        qr.getFirstName().sendKeys(firstname);
        Thread.sleep(1000);
    }
    @And("I valid the first name field")
    public void i_valid_the_first_name_field() throws InterruptedException, IOException, ParseException {
        String firstname=json.jsonActualReadData("firstnameverification");
        Actions act=new Actions(driver);
        act.moveToElement(qr.getFirstName()).doubleClick();
        Thread.sleep(2000);
        qr.getFirstName().sendKeys(firstname);
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @And("first name field should accept more than {int} chars and should accept only alphabets")
    public void first_name_field_should_accept_more_than_chars_and_should_accept_only_alphabets(Integer int1) {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @When("I click on the credit card")
    public void i_click_on_the_credit_card() {
        qr.getCreaditcardQDE().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @And("I Enter mobile number in credit card QDE page")
    public void i_enter_mobile_number_in_credit_card_qde_page() throws IOException, InterruptedException, ParseException {
    /*    driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        driver.findElement(By.xpath("//div[@class='container mt-3 mt-lg-5']")).click();
        Thread.sleep(1000);*/
        qr.getEnterMobileNumber().click();
        Thread.sleep(1000);
        inputGenerator.mobileNumberGenerator();
        String mobile=json.jsonReadData("MobileNumber");
        qr.getEnterMobileNumber().sendKeys(mobile);
        Thread.sleep(5000);
        json.jsonWrite("MobileNumber",mobile);
        Thread.sleep(1000);
        qr.getCreaditNext().click();
        Thread.sleep(3000);
    }
    @Then("I agree the term and conditions in credit card QDE page")
    public void i_agree_the_term_and_conditions_in_credit_card_qde_page() throws InterruptedException {
        qr.getTickCheckBox().click();
        Thread.sleep(1000);
        qr.getAgreeStatement().click();
        Thread.sleep(1000);
    }
    @And("I switch the previous tab")
    public void i_switch_the_previous_tab() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
    }
    @Then("I click on send OTP button")
    public void i_click_on_send_otp_button() throws InterruptedException {
        qr.getCreditQEDSendOTP().click();
        Thread.sleep(2000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
    }
    @And("I click on sms log for credit QDE")
    public void i_click_on_sms_log_for_credit_qde() throws InterruptedException {
        qr.getNavigationBar().click();
        Thread.sleep(1000);
        qr.getReport().click();
        Thread.sleep(1000);
        qr.getSMSLog().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @When("I get the OTP for credit QDE page")
    public void i_get_the_otp_for_credit_qde_page() throws InterruptedException, IOException, ParseException {
         String otp=null;
        Actions act=new Actions(driver);
        act.moveToElement(qr.getRefreshpage()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();

        String mobiledata = json.jsonReadData("MobileNumber");
        qr.getSearchdata().clear();
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qr.getSearchdata().sendKeys(Keys.ENTER);
        //Thread.sleep(30000);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
            act.moveToElement(qr.getRefreshpage()).click().build().perform();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(10000);
            qr.getSearchdata().sendKeys(mobiledata);
            Thread.sleep(1000);
            qr.getSearchdata().sendKeys(Keys.ENTER);
            Thread.sleep(10000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }

        List<WebElement> list = new ArrayList<WebElement>();
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[1]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[3]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[5]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[7]")));

        int i = 0;
        while (i <4) {
            Thread.sleep(1000);
            list.get(i).click();
            Thread.sleep(1000);
            int size= driver.findElements(By.xpath("//section[@class='segment segment-type-string ng-star-inserted']")).size();
            System.out.println("div size is" + size);
            Thread.sleep(1000);
            if(size==10)
            {
                String condition = driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")).getText();
                if(condition.contains(data)){
                    otp =condition.replaceAll("\\D", "");
                    System.out.println(otp);
                    json.jsonWrite("OTP",otp);
                   // writedata.setBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if(size==3||size==9)
                {
                    ngwebdriver.waitForAngularRequestsToFinish();
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
            else {
                ngwebdriver.waitForAngularRequestsToFinish();
                qr.getCloseOTPAlter().click();
                Thread.sleep(2000);
            }
            i++;
        }
        if (otp==null)
        {
            qr.getCloseOTPAlter().click();
            ngwebdriver.waitForAngularRequestsToFinish();
            this.i_get_the_otp_for_credit_qde_page();
        }
    }
    @When("I switch to the next tab")
    public void i_switch_to_the_next_tab() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I Enter OTP")
    public void i_enter_otp() throws IOException, InterruptedException, ParseException {
        String otp=json.jsonReadData("OTP");
        qr.getEnterOTPCreditQDE().sendKeys(otp);
        Thread.sleep(1000);
    }
    @Then("I Click on verify button")
    public void i_click_on_verify_button() throws InterruptedException {
        qr.getVerifyCreditQDE().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @And("I verify the first name field in credit card QDE")
    public void i_verify_the_first_name_field_in_credit_card_qde() throws IOException, InterruptedException, ParseException {
        String alphanuberictext=json.jsonActualReadData("CreditQDEFirstname");
        qr.getCreditcardFirstname().sendKeys(alphanuberictext);
        Thread.sleep(1000);
        qr.getCreaditLastName().click();
        Thread.sleep(1000);
        String lastnameverificaton="Please enter a valid first name";
        String getnameverificationalter=qr.getFirstnameverification().getText();
        if (getnameverificationalter.equals(lastnameverificaton))
        {
            System.out.println("firstname verified successfully....");
        }
        else {
            throw new NullPointerException("bug found in firstname verifycaton for credit card");
        }

        qr.getCreditcardFirstname().sendKeys(Keys.ARROW_UP);
        Thread.sleep(1000);
        qr.getCreditcardFirstname().click();
        Thread.sleep(1000);
        qr.getCreditcardFirstname().clear();
        Thread.sleep(1000);
        qr.getCreditcardFirstname().sendKeys("44455");
        Thread.sleep(1000);
        qr.getCreaditLastName().click();
        Thread.sleep(1000);

        String lastnameverificaton2="Please enter a valid first name";
        String getnameverificationalter2=qr.getFirstnameverification().getText();
        if (getnameverificationalter2.equals(lastnameverificaton2))
        {
            System.out.println("firstname verified successfully....");
        }
        else {
            throw new NullPointerException("bug found in firstname verifycaton for credit card");
        }

        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(2000);
    }
    @Then("I verify the \"([^\"]*)\"$")
    public void i_verify_the(String string) throws InterruptedException {
        qr.getCreditcardFirstname().sendKeys(string);
        Thread.sleep(1000);
        qr.getCreditcardFirstname().sendKeys(Keys.TAB);
        Thread.sleep(2000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(2000);
    }
    @Then("Validate the first name Field in Credit card")
    public void validate_the_first_name_field_in_credit_card() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I verify the last name in insta loan QDE")
    public void i_verify_the_last_name_in_insta_loan_qde() throws IOException, InterruptedException, ParseException {
        String lastname=json.jsonActualReadData("LastnameVerifycation");
        Actions act=new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("//label[text()='Last Name']"))).click().build().perform();
        Thread.sleep(1000);
        qr.getLastName().sendKeys(lastname);
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @And("I verify the lastname in insta loan")
    public void i_verify_the_lastname_in_insta_loan() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I verify the last name in credit card")
    public void i_verify_the_last_name_in_credit_card() throws IOException, InterruptedException, ParseException {
        String alphanuberictext=json.jsonActualReadData("CreditQDELastname");
        qr.getPdLastName().sendKeys(alphanuberictext);
        Thread.sleep(1000);
        qr.getLastNameLabel().click();
        Thread.sleep(1000);

        String verifylastname="Please enter a valid last name";
        String getlastnameverification=qr.getLastnameVerification().getText();
        if (verifylastname.equals(getlastnameverification))
        {
            System.out.println("lastname field verified successfully...");
        }
        else {
            throw new NullPointerException("Bug found in lastname field of the credit card...");

        }
        qr.getPdLastName().sendKeys(Keys.ARROW_UP);
        Thread.sleep(1000);
        qr.getPdLastName().click();
        Thread.sleep(1000);
        qr.getPdLastName().clear();
        Thread.sleep(1000);
        qr.getPdLastName().sendKeys("444455");
        Thread.sleep(1000);
        qr.getPdLastName().click();
        Thread.sleep(1000);

        String verifylastname2="Please enter a valid last name";
        String getlastnameverification2=qr.getLastnameVerification().getText();
        if (verifylastname2.equals(getlastnameverification2))
        {
            System.out.println("lastname field verified successfully...");
        }
        else {
            throw new NullPointerException("Bug found in lastname field of the credit card...");

        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
        Thread.sleep(2000);

    }
    @And("Validate the last name Field in Credit card")
    public void validate_the_last_name_field_in_credit_card() throws InterruptedException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
        Thread.sleep(2000);
    }
    @Then("I Enter the first name in credit card")
    public void i_enter_the_first_name_in_credit_card() throws InterruptedException, IOException, ParseException {
        qr.getCreditcardFirstname().click();
        Thread.sleep(1000);
        String lastname=json.jsonActualReadData("FirstName");
        qr.getCreditcardFirstname().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @And("pincode verification in insta loan")
    public void pincode_verification_in_insta_loan() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I Verify that without fill all details OTP should not be send")
    public void i_verify_that_without_fill_all_details_otp_should_not_be_send() throws InterruptedException {
        qr.getMobilenumber().click();
        Thread.sleep(1000);
        qr.getMobilenumber().sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @And("Verify that without fill all details OTP not send")
    public void verify_that_without_fill_all_details_otp_not_send() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @When("I fill all mandatory details in insta loan")
    public void i_fill_all_mandatory_details_in_insta_loan() throws IOException, InterruptedException, ParseException {
        inputGenerator.mobileNumberGenerator();
        String mobile=json.jsonReadData("MobileNumber");
        qr.getSearchMobileNo().sendKeys(mobile);
        Thread.sleep(5000);
        json.jsonWrite("MobileNumber",mobile);
        Thread.sleep(1000);

        // writedata.setBulkOfData("Sheet1",1,1, inputGenerator.mobileNumberGenerator());
        Thread.sleep(1000);

        String firstname=json.jsonActualReadData("FirstName");
        qr.getFirstName().sendKeys(firstname);
        Thread.sleep(1000);

        String lastname=json.jsonActualReadData("InstLastname");
        qr.getLastName().sendKeys(lastname);
        Thread.sleep(1000);

        Select select=new Select(driver.findElement(By.xpath("//select[@placeholder='Occupation']")));
        select.selectByVisibleText("Salaried");
        Thread.sleep(1000);

        String pincode=json.jsonActualReadData("pincodeno");
        qr.getPincode().sendKeys(pincode);
        Thread.sleep(1000);

        String dob=json.jsonActualReadData("DOB");
        qr.getDateofBirth().sendKeys(dob);
        Thread.sleep(1000);

        //String pan=json.jsonActualReadData("panno");
        qr.getPanNumber().sendKeys(inputGenerator.panCardNumber());
        Thread.sleep(1000);

        String loan=json.jsonActualReadData("LoanAmount");
        qr.getLoan().sendKeys(loan);
        Thread.sleep(1000);

        qr.getCheckBoxTick().click();
        Thread.sleep(1000);

        qr.getAgreeStatement().click();
        Thread.sleep(1000);

        qr.getSendotp().click();
        Thread.sleep(2000);

        qr.getClosealter().click();
        Thread.sleep(1000);
    }
    @Then("I verify the OTP")
    public void i_verify_the_otp() throws InterruptedException {
        qr.getEnterOTP().sendKeys("458710");
        Thread.sleep(1000);
        qr.getSubmitOTP().click();
        Thread.sleep(1000);
        String msgvalid="OTP is either invalid or expired.	2	attempts remaining";
        String getmsg=driver.findElement(By.xpath("//div[@id='swal2-content']")).getText();
        if (getmsg.equals(msgvalid))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("Invalid OTP Entered");
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();

    }
    @And("OTP Verification of the insta loan")
    public void otp_verification_of_the_insta_loan() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }
    @Then("I verify the bank OTP filed")
    public void i_verify_the_bank_otp_filed() throws InterruptedException {
        qr.getSubmitOTP().click();
        Thread.sleep(1000);
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.close();
    }
    @And("Bank OTP Enter in insta Loan")
    public void bank_otp_enter_in_insta_loan() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        driver.close();
    }






}
