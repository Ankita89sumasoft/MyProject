package StepDefination;

import Helper.BaseClass;
import Helper.QRCodeHelper;
import Utilities.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.util.*;

public class QRCodeGeneration extends BaseClass {
    JsonDataReadAndWrite json=new JsonDataReadAndWrite();
    QRCodeHelper qrcode=null;
    WriteExcelData writedata=new WriteExcelData();
    JavascriptExecutor js;
    ReadExcelData readdata=new ReadExcelData();
    FinequsReadData readfinequsdata=new FinequsReadData();
    Random random=new Random();
    ReadActualData actualdata=new ReadActualData();
    String parentwindow=null;
    InputGenerator inputGenerator=new InputGenerator();

    String data="Thank you for the request";
    @Given("I launch chrome browser for the QR code generation")
    public void i_launch_chrome_browser_for_the_qr_code_generation() throws IOException, ParseException, ParseException, java.text.ParseException {
        set();
    }
    @When("I login in the finequs application")
    public void i_login_in_the_finequs_application() throws InterruptedException {
        login();
    }
    @When("I click of navigation bar")
    public void i_click_of_navigation_bar() throws InterruptedException {
        qrcode=new QRCodeHelper();
        qrcode.getNavigationBar().click();
        Thread.sleep(1000);
       // qrcode.getNavigationdrawer().click();
       // Thread.sleep(1000);
    }
    @Then("I switch the tab for the Quick loan flow")
    public void i_switch_the_tab_for_the_quick_loan_flow() throws InterruptedException {
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().back();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
    }

    @Then("I switch the tab for the Home loan flow")
    public void i_switch_the_tab_for_the_home_loan_flow() throws InterruptedException {
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().back();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }

    @Then("I switch the tab for the Business loan flow")
    public void i_switch_the_tab_for_the_business_loan_flow() throws InterruptedException {
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().back();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I switch the tab for the Loan Against Property flow")
    public void i_switch_the_tab_for_the_loan_against_property_flow() throws InterruptedException {
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().back();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I switch the tab for the credit card")
    public void i_switch_the_tab_for_the_credit_card() throws InterruptedException {
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        Thread.sleep(1000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().back();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I choose the channel drop-down for QR code generation")
    public void i_choose_the_channel_drop_down_for_qr_code_generation() throws InterruptedException {
        qrcode.getChannel().click();
        Thread.sleep(1000);
    }
    @When("I select the generate QR code option in channel drop-down")
    public void i_select_the_generate_qr_code_option_in_channel_drop_down() throws InterruptedException {
        qrcode.getGenerateqrcode().click();
        Thread.sleep(5000);
    }
    @When("I select the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_select_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @Then("I copy the url in QR code generation")
    public void i_copy_the_url_in_qr_code_generation() throws InterruptedException, IOException, ParseException {
        qrcode.getCopyURL().click();
        Thread.sleep(2000);
        qrcode.getClosealter().click();
        Thread.sleep(1000);
        String pastdata=qrcode.getURL().getAttribute("value");
        System.out.println("Pastdata is"+pastdata);
        Thread.sleep(1000);
        json.jsonWrite("URL",pastdata);
        //writedata.setBulkOfData("Sheet1",1,0,pastdata);
//********************** copy past***************
        /*Actions act=new Actions(driver);
        String pastdata=String.valueOf(act.keyDown(Keys.CONTROL).sendKeys("v"));
        System.out.println("Past data is"+pastdata);
        act.keyUp(Keys.CONTROL).build().perform();*/
    }
    @Then("I click on Generate QRcode for generating QRCode")
    public void i_click_on_generate_q_rcode_for_generating_qr_code() throws InterruptedException {
      qrcode.getGenerateQRcode().click();
      Thread.sleep(3000);
      qrcode.getScroll();
      Thread.sleep(1000);
      js=(JavascriptExecutor) driver;
      js.executeScript("window.scrollBy(0,999)");
      Thread.sleep(1000);
      qrcode.getHeader();
        js.executeScript("window.scrollBy(0,-4000)");
        Thread.sleep(1000);
    }
    @When("I switch the tab and paste url")
    public void i_switch_the_tab_and_paste_URL() throws IOException, InterruptedException, ParseException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        // String url=readdata.readExcel("Sheet1","URL");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
       // Thread.sleep(8000);

        /*String parentwindow=driver.getWindowHandle();
        Set<String> handles = driver.getWindowHandles();
        for (String handle : handles)
        {
            System.out.println("child window is...." + handle);
            if (!handle.equals(parentwindow))
            {
                driver.switchTo().window(handle);
                Thread.sleep(1000);
            }
        }*/

    }
    @Then("I click on the insta loan option")
    public void i_click_on_the_insta_loan_option() throws InterruptedException {
        qrcode.getInstaLoan().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I Enter the mobile number")
    public void i_enter_the_mobile_number() throws InterruptedException, IOException, ParseException {
       // mobileno=random.nextInt(76+(Integer.SIZE+1)+34567890);
        inputGenerator.mobileNumberGenerator();
        String mobile=json.jsonReadData("MobileNumber");
        qrcode.getSearchMobileNo().sendKeys(mobile);
        Thread.sleep(1000);
        json.jsonWrite("MobileNumber",mobile);
        Thread.sleep(1000);
    }
    @Then("I Verify all field in insta loan page")
    public void i_verify_all_field_in_insta_loan_page() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        qrcode.getInstaSendOTPButton().click();
        Thread.sleep(1000);
        List<WebElement>altermsg=new ArrayList<>();
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[1]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[2]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[3]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[4]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[5]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[6]")));
        altermsg.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[7]")));

        int i=0;
        while (i<altermsg.size())
        {
            if (altermsg.get(i).isDisplayed())
            {
                System.out.println("All Field having validation...");
            }
            else {
                throw new InterruptedException("Few insta loan Fields dont have validation please check..."+altermsg.get(i));
            }
            i++;
        }
    }
    @When("I Enter the First Name")
    public void i_enter_the_first_name() throws InterruptedException, IOException, ParseException {
        String firstname=json.jsonActualReadData("FirstName");
        Actions act=new Actions(driver);
        act.moveToElement(qrcode.getFirstName()).doubleClick();
        Thread.sleep(1000);
        qrcode.getFirstName().sendKeys(firstname);
        Thread.sleep(1000);
    }

    @When("I Enter Last name for Insta Loan")
    public void i_enter_last_name_for_insta_loan() throws IOException, ParseException, InterruptedException {
        String lastname=json.jsonActualReadData("InstLastname");
        Actions act=new Actions(driver);
        act.moveToElement(qrcode.getCreaditLastName()).click().build().perform();
        Thread.sleep(1000);
        qrcode.getLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Last Name")
    public void i_enter_the_last_name() throws InterruptedException, IOException, ParseException {
        String lastname=json.jsonActualReadData("Lastname");
        Actions act=new Actions(driver);
        act.moveToElement(qrcode.getCreaditLastName()).click().build().perform();
        Thread.sleep(1000);
        qrcode.getLastName().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I Enter the Pincode")
    public void i_enter_the_pincode() throws InterruptedException, IOException, ParseException {
        String pincode=json.jsonActualReadData("pincodeno");
        qrcode.getPincode().click();
        Thread.sleep(1000);
        qrcode.getPincode().sendKeys(pincode);
        Thread.sleep(1000);
    }
    @When("I Enter the Date of birth for insta loan")
    public void i_enter_the_date_of_birth_for_insta_loan() throws IOException, ParseException, InterruptedException {
        String dob=json.jsonActualReadData("DOB");
        qrcode.getDateofBirth().sendKeys(dob);
        Thread.sleep(1000);
    }

 /*   @When("I enter the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_enter_the_as(String string, String string2) throws IOException, InterruptedException {
        driver.findElement(By.xpath("//div[@class='container mt-3 mt-lg-5']")).click();
        Thread.sleep(1000);
        qrcode=new QRCodeHelper();
        String data=readfinequsdata.readExcelData("Sheet1",string2);
        Actions act=new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("//input[@name='"+string+"']"))).click().build().perform();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='"+string+"']")).sendKeys(data);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='"+string+"']")).sendKeys(Keys.TAB);
        Thread.sleep(1000);
    }*/
   /* @Then("I put in the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_put_in_the_as(String string, String string2) throws IOException, InterruptedException {
        String lastname=readfinequsdata.readExcelData("Sheet1",string2);
        driver.findElement(By.xpath("//input[@name='"+string+"']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='"+string+"']")).sendKeys(lastname);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='"+string+"']")).sendKeys(Keys.TAB);
        Thread.sleep(1000);
    }*/
 @Then("I verify the submit button")
 public void i_verify_the_submit_button() {
     try
     {
         WebDriverWait wait = new WebDriverWait(driver, 30);
        if (wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Send OTP']")))==null)
        {
            System.out.println("send otp button is disable...");
        }
     }
     catch(Exception e)
     {
         System.out.println("send OTP button us enable please check...");
     }
 }

    @Then("I tick the finequs terms and condition checkbox")
    public void i_tick_the_finequs_terms_and_condition_checkbox() throws InterruptedException {
        qrcode.getCheckbox().click();
        Thread.sleep(5000);
    }
    @When("I agree the terms and conditions")
    public void i_agree_the_terms_and_conditions() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,9999)");
        qrcode.getAgreeStatement().click();
        Thread.sleep(1000);
       /* qrcode.getDiv().click();
        Thread.sleep(1000);*/
    }
    @When("I click on the send OTP")
    public void i_click_on_the_send_otp() throws InterruptedException {
        qrcode.getSendotp().click();
        Thread.sleep(5000);
        qrcode.getClosealter().click();
        Thread.sleep(1000);
    }
    @Then("I Enter the PAN number for instaloan")
    public void i_enter_the_pan_number_for_instaloan() throws IOException, ParseException, InterruptedException {
        String panno=json.jsonActualReadData("panno");
        //qrcode.getPanNumber().sendKeys(inputGenerator.panCardNumber());
        qrcode.getPanNumber().sendKeys(panno);
        Thread.sleep(1000);
    }
    @When("I Enter the required loan amount for instaloan")
    public void i_enter_the_required_loan_amount_for_instaloan() throws IOException, ParseException, InterruptedException {
        String loanamount=json.jsonActualReadData("LoanAmount");
        qrcode.getLaonAmount().sendKeys(loanamount);
        Thread.sleep(1000);
    }
    @Then("I switch to parent window")
    public void i_switch_to_parent_window() throws InterruptedException {
        String parentwindow=driver.getWindowHandle();
        Set<String> handles = driver.getWindowHandles();
        for (String handle : handles)
        {
            System.out.println("child window is...." + handle);
            if (!handle.equals(parentwindow))
            {
                driver.switchTo().window(handle);
                Thread.sleep(1000);
            }
        }

    }
    @When("pick in the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void pick_in_the_as(String string, String string2) throws InterruptedException {
        driver.findElement(By.xpath("//a[text()='"+string+"']")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[text()='"+string2+"']")).click();
        Thread.sleep(18000);
    }
    @Then("I click on the refresh SMS page")
    public void i_click_on_the_refresh_sms_page() throws InterruptedException {
        qrcode.getRefreshpage().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @When("I search the mobile number")
    public void i_search_the_mobile_number() throws IOException, InterruptedException, ParseException {
        String mobiledata = json.jsonReadData("MobileNumber");
        qrcode.getSearchdata().clear();
        Thread.sleep(1000);
        qrcode.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qrcode.getSearchdata().sendKeys(Keys.ENTER);
        Thread.sleep(40000);
        /*ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);*/

    }
    @When("I get the OTP in SMS log")
    public void i_get_the_otp_in_sms_log() throws IOException, InterruptedException, ParseException {
        String otp = null;
        if(qr.getTable1().getText().isEmpty()||qr.getTable2().getText().isEmpty()||qr.getTable3().getText().isEmpty()||qr.getTable4().getText().isEmpty())
        {
            this.i_click_on_the_refresh_sms_page();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_mobile_number();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }
        List<WebElement>list=new ArrayList<WebElement>();
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[19]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[13]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[7]")));
        int i=0;
        while (i<3)
        {
            Actions act=new Actions(driver);
            act.moveToElement(list.get(i)).click().build().perform();
            Thread.sleep(5000);
            int size= driver.findElements(By.xpath("//section[@class='segment segment-type-string ng-star-inserted']")).size();
            if (size==10)
            {
                String get_thanks_data=driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")).getText();
                if (get_thanks_data.contains(data))
                {
                    otp=get_thanks_data.replaceAll("\\D","");
                    Thread.sleep(1000);
                    json.jsonWrite("OTP",otp);
                    // writedata.setBulkOfData("Sheet1",1,2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if (size==3||size==9)
                {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
                else {
                    qr.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
            i++;
        }
        if (otp==null)
        {
            this.i_click_on_the_refresh_sms_page();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            qr.getSearchdata().clear();
            Thread.sleep(1000);
            this.i_search_the_mobile_number();
            Thread.sleep(1000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            this.i_get_the_otp_in_sms_log();
        }
       /* String otp=null;
        Actions act=new Actions(driver);
        act.moveToElement(qrcode.getRefreshpage()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(40000);
        List<WebElement> list = new ArrayList<WebElement>();

        String mobiledata = json.jsonReadData("MobileNumber");
        qrcode.getSearchdata().clear();
        Thread.sleep(1000);
        qrcode.getSearchdata().sendKeys(mobiledata);
        Thread.sleep(1000);
        qrcode.getSearchdata().sendKeys(Keys.ENTER);
        Thread.sleep(35000);
        //Thread.sleep(30000);
       *//* ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);*//*

        if(qrcode.getTable1().getText().isEmpty()||qrcode.getTable2().getText().isEmpty()||qrcode.getTable3().getText().isEmpty()||qrcode.getTable4().getText().isEmpty())
        {
            act.moveToElement(qrcode.getRefreshpage()).click().build().perform();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(10000);
            qrcode.getSearchdata().sendKeys(mobiledata);
            Thread.sleep(1000);
            qrcode.getSearchdata().sendKeys(Keys.ENTER);
            Thread.sleep(10000);
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
        }

        list.add(qrcode.getClickFirstSearchIcon());
        list.add(qrcode.getClickSecondSearchIcon());
        list.add(qrcode.getSearchThird());
        list.add(qrcode.getSearchFourth());
        int i = 0;
        while (i <4) {
            Thread.sleep(2000);
            list.get(i).click();
            Thread.sleep(1000);
            int size=qrcode.getACLSMSDetails().size();
            System.out.println("div size is" + size);
            if(size==10)
            {
                String condition =qrcode.getMessage().getText();
                if(condition.contains(data)){
                    otp = String.valueOf(Integer.parseInt(condition.replaceAll("\\D", "")));
                    System.out.println(otp);
                    json.jsonWrite("OTP",otp);
                    //writedata.setBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                    Thread.sleep(1000);
                    qrcode.getCloseOTPAlter().click();
                    Thread.sleep(1000);
                    break;
                }
                else if(size==3||size==9)
                {
                    qrcode.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
                else {
                    qrcode.getCloseOTPAlter().click();
                    Thread.sleep(2000);
                }
            }
             else {
                qrcode.getCloseOTPAlter().click();
                Thread.sleep(2000);
            }
            i++;
        }
        if (otp==null)
        {
            qrcode.getCloseOTPAlter().click();
            ngwebdriver.waitForAngularRequestsToFinish();
            this.i_get_the_otp_in_sms_log();
        }*/
    }

       /* List<WebElement>list=new ArrayList<>();
       list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[1]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[3]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[5]")));
        list.add(driver.findElement(By.xpath("(//mat-icon[text()='search'])[7]")));
        int i=0;
        while (i<3) {

            list.get(i).click();
            int divsize=driver.findElements(By.xpath("//div[@id='cdk-overlay-4']")).size();
            System.out.println("size of div is:"+divsize);*/

          /* int a= driver.findElements(By.xpath("//app-aclsms-data-view[@class='ng-star-inserted']")).size();
            System.out.println("Size of text div is"+a);
            String condition=driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[8]")).getText();
            if(size.equals(a)) {
                int otp = Integer.parseInt(condition.replaceAll("\\D", ""));
                System.out.println(otp);
                writedata.SetBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                Thread.sleep(1000);
            }
            else {
                qrcode.getCloseOTPAlter().click();
            }*/

           /*switch(a)
            {
                case 9: String condition=driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[8]")).getText();
                        if (condition.contains(data))
                        {
                                int otp = Integer.parseInt(condition.replaceAll("\\D", ""));
                                System.out.println(otp);
                                writedata.SetBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                                Thread.sleep(1000);
                        }
                        else
                        {
                            qrcode.getCloseOTPAlter().click();
                        }
                        case 10:
                                String condition1 = driver.findElement(By.xpath("(//span[@class='segment-value ng-star-inserted'])[10]")).getText();
                                if (condition1.contains(data)) {
                                    int otp = Integer.parseInt(condition1.replaceAll("\\D", ""));
                                    System.out.println(otp);
                                    writedata.SetBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                                    Thread.sleep(1000);
                                }
                                else
                                {
                                    qrcode.getCloseOTPAlter().click();
                                }*/

           // }
           // i++;

            /*String icondata1=driver.findElement(By.xpath("(//section[@class='segment-main expanded'])[8]")).getText();

            if (icondata1.equals(data))
            {
                int otp = Integer.parseInt(icondata1.replaceAll("\\D", ""));
                System.out.println(otp);
                writedata.SetBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                Thread.sleep(1000);
            }
            else if (!icondata1.equals(data))
            {

            }*/



            /*if (qrcode.getMessage().equals(qrcode.getMessage())) {
                String otp_message = qrcode.getMessage().getText();
                int otp = Integer.parseInt(otp_message.replaceAll("\\D", ""));
                System.out.println(otp);
                writedata.SetBulkOfData("Sheet1", 1, 2, String.valueOf(otp));
                Thread.sleep(1000);
                break;
            } else if (qrcode.getSegmentkey().equals(qrcode.getSegmentkey())) {
                qrcode.getCloseOTPAlter().click();
                Thread.sleep(1000);
                break;
            } else if (icondata.equals(qrcode.getMessage().getText())) {
                qrcode.getCloseOTPAlter().click();
                Thread.sleep(1000);
                break;
            } else {
                System.out.println("Something wants wrong please check again.......");
            }*/


  /*  @Then("I close the OTP message Box")
    public void i_close_the_otp_message_box() throws InterruptedException {
        qrcode.getCloseOTPAlter().click();
        Thread.sleep(1000);
    }*/
    @When("I click on the child tab")
    public void i_click_on_the_child_tab() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }
    @Then("I enter the OTP")
    public void i_enter_the_otp() throws IOException, InterruptedException, ParseException {
        String OTP=json.jsonReadData("OTP");
        qrcode.getEnterOTP().sendKeys(OTP);
        Thread.sleep(5000);
    }
    @When("I Click on Submit OTP")
    public void i_click_on_submit_otp() throws InterruptedException {
        qrcode.getSubmitOTP().click();
        Thread.sleep(12000);
        /*ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);*/
    }
    @When("I accept the ok alter")
    public void i_accept_the_ok_alter() throws InterruptedException {
        qrcode.getOk().click();
        Thread.sleep(5000);
        driver.close();
        Thread.sleep(1000);
    }
    @Then("I accept ok alter")
    public void i_accept_ok_alter() throws InterruptedException {
        qrcode.getOk().click();
        Thread.sleep(5000);
    }
    @When("I switch to the parent tab")
    public void i_switch_to_the_parent_tab() throws InterruptedException {
        driver.switchTo().window(parentwindow);
        Thread.sleep(1000);
    }
    @Then("I click on loan")
    public void i_click_on_loan() throws InterruptedException {
       qrcode.getReport().click();
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-8000)");
        qrcode.getLoans().click();
        Thread.sleep(1000);
    }
   @When("I click on the loan application")
    public void i_click_on_the_loan_application() throws InterruptedException {
        qrcode.getLoanApplication().click();
        Thread.sleep(5000);
    }
    @Then("I click on pin icon")
    public void i_click_on_pin_icon() throws InterruptedException {
      qrcode.getpinicon().click();
      Thread.sleep(2000);
    }
    @When("I click on the upload button")
    public void i_click_on_the_upload_button() throws InterruptedException {
       qrcode.getUploadButton().click();
       Thread.sleep(5000);
    }

    @When("I search the mobile number in all application form")
    public void i_search_the_mobile_number_in_all_application_form() throws InterruptedException, IOException, ParseException {
        qrcode.getSearchMobileNo().click();
        Thread.sleep(1000);
        String mobiledata = json.jsonReadData("MobileNumber");
        qrcode.getSearchMobileNo().sendKeys(mobiledata);
        Thread.sleep(1000);
        qrcode.getSearchMobileNo().sendKeys(Keys.ENTER);
        Thread.sleep(20000);
    }
    @When("I click on the Micro Loan Queue")
    public void i_click_on_the_micro_loan_queue() throws InterruptedException {
        qrcode.getMicroLoanQueue().click();
        Thread.sleep(8000);
    }
    @When("I write Application ID")
    public void i_write_application_id() throws IOException, InterruptedException, ParseException {
        String applicationid=qrcode.getApplicationID().getText();
        json.jsonWrite("AppID",applicationid);
        //writedata.setBulkOfData("Sheet1",1,3,applicationid);
        Thread.sleep(1000);
    }
    @Then("I verify the applicationID")
    public void i_verify_the_application_id() throws IOException, ParseException {
        String getapplicationid=qrcode.getMicroId().getText();
        String exceldata=json.jsonReadData("AppID");
        if(!getapplicationid.equals(exceldata))
        {
            qrcode.getNextButton().click();
            System.out.println("Application id successfully verify...");
        }
    }
    @Then("I select in the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_select_in_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("(//select[@placeholder='"+string+"'])[3]")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @When("I enter the new remark")
    public void i_enter_the_new_remark() throws IOException, InterruptedException, ParseException {
        qrcode.getNo_Data_Avilable();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
        String remark=json.jsonActualReadData("NewRemark");
        Thread.sleep(2000);
        /*Actions act=new Actions(driver);
        act.moveToElement(qrcode.getNewRemark()).doubleClick();
        Thread.sleep(1000);*/
        qrcode.getNewRemark().sendKeys(remark);
        Thread.sleep(1000);
    }
    @When("I click on the data collection")
    public void i_click_on_the_data_collection() throws InterruptedException {
        qrcode.getDatacollection().click();
        Thread.sleep(3000);
        qrcode.getDatacollectionok().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I select the salution")
    public void i_select_the_salution() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(1000);
        qrcode.getDataCollectionQueueText();
        ngwebdriver.waitForAngularRequestsToFinish();
        qrcode.getSalutation().click();
       Thread.sleep(15000);
       Select select=new Select(qrcode.getDataCollectionSalutation());
       select.selectByVisibleText("Mr.");
       Thread.sleep(5000);
    }
    @When("I Enter the alternate contact")
    public void i_enter_the_alternate_contact() throws InterruptedException, IOException, ParseException {
        String alternateno=json.jsonActualReadData("Alternatnumber");
        qrcode.getAlternateMobileNumber().sendKeys(alternateno);
        Thread.sleep(1000);
    }
    @When("I Enter the fatherName")
    public void i_enter_the_father_name() throws IOException, InterruptedException, ParseException {
        String fathername=json.jsonActualReadData("FatherName");
        qrcode.getFatherName().click();
        Thread.sleep(1000);
        qrcode.getFatherName().sendKeys(fathername);
        Thread.sleep(1000);
    }
    @When("I Enter the MotherName")
    public void i_enter_the_mother_name() throws IOException, InterruptedException, ParseException {
        String monthername=json.jsonActualReadData("MotherName");
        qrcode.getMothername().click();
        Thread.sleep(1000);
        qrcode.getMothername().sendKeys(monthername);
        Thread.sleep(1000);
    }
    @Then("I Enter the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_enter_the_as(String string, String string2) throws InterruptedException, IOException, ParseException {
        String address1=json.jsonActualReadData(string2);
        driver.findElement(By.xpath("//input[@formcontrolname='"+string+"']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='"+string+"']")).sendKeys(address1);
        Thread.sleep(1000);
    }
    @When("I Enter the permanent Residence address same as current address")
    public void i_enter_the_permanent_residence_address_same_as_current_address() throws InterruptedException {
        qrcode.getCheckBoxTick().click();
        Thread.sleep(2000);
    }
    @When("I enter the office address same as the current address")
    public void i_enter_the_office_address_same_as_the_current_address() throws InterruptedException {
        qrcode.getResOfficeSame().click();
        Thread.sleep(2000);
    }
    @When("I click on the submit button")
    public void i_click_on_the_submit_button() throws InterruptedException {
        qrcode.getSumbitMicro().click();
        Thread.sleep(15000);
    }
    @Then("I close page")
    public void i_close_page() throws InterruptedException {
        qrcode.getClosealter().click();
        Thread.sleep(10000);
    }
    @When("I click on the document collection queue")
    public void i_click_on_the_document_collection_queue() throws InterruptedException {
        qrcode.getDataCollectionQueue().click();
        Thread.sleep(11000);
    }
    @When("I search the application id in document collection queue")
    public void i_search_the_application_id_in_document_collection_queue() throws InterruptedException, IOException {
        qrcode.getDocCollectionID().click();
        Thread.sleep(2000);
        String applicationID=readdata.readExcel("Sheet1","AppID");
        qrcode.getDDAppID().sendKeys(applicationID);
        Thread.sleep(1000);
        qrcode.getDDAppID().sendKeys(Keys.ENTER);
        Thread.sleep(10000);
    }
    @Then("I check the status for the insta loan application ID")
    public void i_check_the_status_for_the_insta_loan_application_id() throws InterruptedException, IOException, ParseException {
        //String status="WBDML-IL";
        String getstatus=qrcode.getApplicationfinalstatus().getText();
        json.jsonWrite("InstaLoanStatus",getstatus);
        Thread.sleep(1000);
       /* if (getstatus.equals(status))
        {
            System.out.println("Insta loan final status is correct");
        }
        else {
            throw new InterruptedException("Final status is not correct for insta loan please check...");
        }*/
    }
    @And("I close the positive flow of the insta loan")
    public void i_close_the_positive_flow_of_the_insta_loan() {
        end();
    }
}
