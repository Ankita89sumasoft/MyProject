package StepDefination;

import Helper.BaseClass;
import Helper.PropertiesReader;
import Helper.QRCodeHelper;
import Utilities.InputGenerator;
import Utilities.JsonDataReadAndWrite;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en_scouse.An;
import org.apache.poi.ss.formula.functions.T;
import org.apache.tools.ant.taskdefs.Java;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.security.core.parameters.P;

import java.io.File;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Negative_Remaining_NavigationOptions extends BaseClass {
    PropertiesReader pro=new PropertiesReader();
   // QRCodeHelper qr=null;
    WebDriverWait wait;
    JsonDataReadAndWrite json=new JsonDataReadAndWrite();
    JavascriptExecutor js;
    String parentwindow=null;
    File file= new File("C:\\Users\\pooja.sapkal\\IdeaProjects\\WheelEMIAPK\\Finequs\\DownloadedFile");
    File[]filelist=null;
    InputGenerator inputGenerator=new InputGenerator();
    @Given("I Login for the navigation drawer option")
    public void i_login_for_the_navigation_drawer_option() throws InterruptedException, IOException, ParseException {
        set();
        Thread.sleep(1000);
        String url=pro.propertyReader("url");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        wait=new WebDriverWait(driver,30);
    }
    @When("I Click on the navigation bar in navigation drawer option")
    public void i_click_on_the_navigation_bar_in_navigation_drawer_option() throws InterruptedException {
        login();
    }
    @When("I on channel Menu")
    public void i_on_channel_menu() {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @Then("I verify that when user click on the Channel menue that time Channel menu respective submenu should be open")
    public void i_verify_that_when_user_click_on_the_channel_menue_that_time_channel_menu_respective_submenu_should_be_open() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        int size=driver.findElements(By.xpath("(//div[@class='collapse sideNavbarBody'])[2]")).size();
        if(size==1)
        {
            System.out.println("All navigation dropdown optiona are present");
        }
        else
        {
            throw new InterruptedException("Some Options are missing issue....");
        }
    }
    @And("I close the navigation drawer option")
    public void i_close_the_navigation_drawer_option() {
        end();
    }
    @Then("I verify that when Channel page is open & user click on the other menu submenu that time opened Channel page should be closed & clicked menu submenu related page should be open")
    public void i_verify_that_when_channel_page_is_open_user_click_on_the_other_menu_submenu_that_time_opened_channel_page_should_be_closed_clicked_menu_submenu_related_page_should_be_open() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getLoans().click();
        int size=driver.findElements(By.xpath("(//div[@class='collapse sideNavbarBody'])[3]")).size();
        if (size==1)
        {
            System.out.println("All Navigation dropdown option are present");
        }
        else {
            throw new InterruptedException("Some option are missing in the loan dropdown option");
        }
        int channelsize=driver.findElements(By.xpath("(//li[@class='ng-star-inserted'])[8]")).size();
        if(channelsize==0)
        {
            System.out.println("Previous dropdown option is close...");
        }
        else
        {
            throw new InterruptedException("Previous drop-down option not able to close...");
        }
    }
    @And("I close the submenu related page should be open")
    public void i_close_the_submenu_related_page_should_be_open() {
       end();
    }
    @When("I click on white label partner option")
    public void i_click_on_white_label_partner_option() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getWhiteLabel().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        int size=driver.findElements(By.xpath("//form[@class='merchant-verify-form ng-untouched ng-pristine ng-invalid']")).size();
        if(size==1)
        {
            System.out.println("white label partner submenu respective sub-menu should be open successfully...");
        }
        else
        {
            throw new InterruptedException("white label partner submenu respective sub-menu should not be open...");
        }
    }
    @And("I close white label partner submenu respective sub-menu should be open scenario")
    public void i_close_white_label_partner_submenu_respective_sub_menu_should_be_open_scenario() {
     end();
    }
    @Then("I click on white label partner")
    public void i_click_on_white_label_partner() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getWhiteLabel().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I verify without entering merchant id that time alert should be displyed merchant id is required")
    public void i_verify_without_entering_merchant_id_that_time_alert_should_be_displyed_merchant_id_is_required() throws InterruptedException {
        qr.getWhiteLabelVerify().click();
        Thread.sleep(1000);
        String alter="MerchantId is required";
        String getalter=driver.findElement(By.xpath("(//div[@class='ng-star-inserted'])[2]")).getText();
        if (getalter.equals(alter))
        {
            System.out.println("alert should be displyed merchant id is required");
        }
        else
        {
            throw new InterruptedException("Merchant alter is not displayed please check...");
        }
    }
    @And("I close the without entering merchant id that time alert should be displyed merchant id is required")
    public void i_close_the_without_entering_merchant_id_that_time_alert_should_be_displyed_merchant_id_is_required() {
       end();
    }
    @Then("I verify that merchant details should be displayed when entering valid data")
    public void i_verify_that_merchant_details_should_be_displayed_when_entering_valid_data() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        String merchantiddata=json.jsonActualReadData("MerchantId");
        qr.getMerchantInput().sendKeys(merchantiddata);
        Thread.sleep(1000);
        qr.getWhiteLabelVerify().click();
        Thread.sleep(1000);
        ArrayList<WebElement>list=new ArrayList<WebElement>();
        list.add(driver.findElement(By.xpath("//div[@class='modal-header ng-star-inserted']")));
        list.add(driver.findElement(By.xpath("//button[@class='close pull-right']")));
        list.add(driver.findElement(By.xpath("(//div[@class='row'])[2]")));
        list.add(driver.findElement(By.xpath("(//div[@class='col-xs-12 col-12 col-md-4 form-group'])[2]")));
        list.add(driver.findElement(By.xpath("(//div[@class='col-xs-12 col-12 col-md-4 form-group'])[3]")));
        list.add(driver.findElement(By.xpath("//button[text()=' Confirm ']")));
        list.add(driver.findElement(By.xpath("//button[@class=' mb-6 mr-2 ml-4 btn btn-primary text-white']")));
        int i=0;
        while (i<=6)
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("valid alter accepted...");
                Thread.sleep(1000);
            }
            else {
                throw new InterruptedException("something valid wrong with merchant details should be displayed when entering valid data");
            }
            i++;
        }
    }
    @Then("I close the after entering valid merchant id that time merchant details should be displayed page")
    public void i_close_the_after_entering_valid_merchant_id_that_time_merchant_details_should_be_displayed_page() throws InterruptedException {
        qr.getMerchantClose().click();
        Thread.sleep(1000);
        end();
    }
    @When("I click on merchant list submenu option")
    public void i_click_on_merchant_list_submenu_option() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getMerchant_List().click();
        Thread.sleep(1000);
    }
    @Then("I verify that the Merchant list respective page should be open")
    public void i_verify_that_the_merchant_list_respective_page_should_be_open() throws InterruptedException {
        String actualctedtest=qr.getCustomerName().getText();
        String expectdtest="All Merchants";
        if (actualctedtest!=null&&actualctedtest.contains(expectdtest))
        {
            System.out.println("Correct page is open...");
        }
        else
        {
            throw new InterruptedException("Merchent List page is not open please check again...");
        }
    }
    @And("I close the verify Merchant list respective page")
    public void i_close_the_verify_merchant_list_respective_page() {
        end();
    }
    @Then("I verify that Merchant field should be displayed")
    public void i_verify_that_merchant_field_should_be_displayed() throws InterruptedException {
        int table_length=driver.findElements(By.xpath("(//tr[@class='mat-header-row ng-star-inserted'])[1]")).size();
        if (table_length==1)
        {
            System.out.println("All Table headers are present...");
            Thread.sleep(1000);
        }
        else {
            throw new InterruptedException("Some Header is missing in table please check...");
        }
    }
    @Then("I close the verify that Merchant field should be displayed")
    public void i_close_the_verify_that_merchant_field_should_be_displayed() {
        end();
    }
    @Then("I Verify the all search box field should be displayed")
    public void i_verify_the_all_search_box_field_should_be_displayed() throws InterruptedException {
        ArrayList<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@name='dateString']")));
        list.add(driver.findElement(By.xpath("//input[@name='merchantID']")));
        list.add(driver.findElement(By.xpath("//input[@name='fullName']")));
        list.add(driver.findElement(By.xpath("//input[@name='mobile']")));
        list.add(driver.findElement(By.xpath("//input[@name='associateTypeName']")));
        list.add(driver.findElement(By.xpath("//input[@name='shopName']")));
        list.add(driver.findElement(By.xpath("//input[@name='createdBy']")));
        list.add(driver.findElement(By.xpath("//input[@name='modifiedOn']")));
        list.add(driver.findElement(By.xpath("//input[@name='merchantStatus']")));
        int i=0;
        while (i<=8)
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Search field is available");
                Thread.sleep(1000);
            }
            else {
                throw new InterruptedException("search field is not available");
            }
            i++;
        }
    }
    @Then("I close the Verify search box webpage")
    public void i_close_the_verify_search_box_webpage() {
        end();
    }
    @Then("verify that action icon should be display under the Action label")
    public void verify_that_action_icon_should_be_display_under_the_action_label() throws InterruptedException {
        WebElement table=driver.findElement(By.xpath("//thead//tr/th[1]//span[text()='Action']"));
        WebElement column_1_data=table.findElement(By.xpath("//tbody//tr//td//div[@class='row']//child::mat-icon"));
        if (column_1_data.isDisplayed()&& table.isDisplayed()){
            System.out.println("action icon is display under the Action label");
            Thread.sleep(1000);
        }
        else {
            throw new InterruptedException("action icon not display under the Action label");
        }
    }
    @Then("I close the verify that action icon display under the Action label page")
    public void i_close_the_verify_that_action_icon_display_under_the_action_label_page() {
            end();
    }
    @Then("I verify the first page and last page should be open")
    public void iVerifyTheFirstPageAndLastPageShouldBeOpen() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        qr.getFinalPrivousButton().click();
        Thread.sleep(1000);
        String getrange=driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        //String range="411 - 417 of 417";
        if (!getrange.isEmpty())
        {
            System.out.println("first page and last page is open");
        }
        else {
            throw new InterruptedException("First page and last page is not open please check...");
        }

    }
    @And("I close first page and last page should be open webpage")
    public void iCloseFirstPageAndLastPageShouldBeOpenWebpage() {
        end();
    }
    @Then("I verify the previous page or next page is open")
    public void iVerifyThePreviousPageOrNextPageIsOpen() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(5000);
        qr.getFinalPrivousButton().click();
        Thread.sleep(2000);
        if (qr.getMiddlepreviousbutton().isEnabled())
        {
            qr.getMiddlepreviousbutton().click();
            Thread.sleep(2000);
            System.out.println("previous button is clicked");
        }
        if (qr.getMiddlenextbutton().isEnabled())
        {
            qr.getMiddlenextbutton().click();
            Thread.sleep(2000);
            System.out.println("Next Button is clicked");
        }
        else {
            throw new InterruptedException("buttons is not enabled please check...");
        }
    }
    @And("I close the previous page or next page is open webpage")
    public void iCloseThePreviousPageOrNextPageIsOpenWebpage() {
        end();
    }
    @Then("I verify the according to select value record should be displayed")
    public void i_verify_the_according_to_select_value_record_should_be_displayed() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(5000);
        qr.getRangearrow().click();
        Thread.sleep(1000);
        ArrayList<By>list=new ArrayList<>();
        list.add(By.xpath("//span[text()='5']"));
        list.add(By.xpath("//span[text()='10']"));
        list.add(By.xpath("//span[text()='25']"));
        list.add(By.xpath("//span[text()='100']"));
        int i=0;
        while (i<4)
        {
            driver.findElement(list.get(i)).click();
            Thread.sleep(2000);
            int selectedValue= Integer.parseInt(driver.findElement(list.get(i)).getText());
            Thread.sleep(1000);

           /* list.get(i).click();
           int selectedValue= Integer.parseInt(list.get(i).getText());
            Thread.sleep(1000);
           int getrecordsize=driver.findElements(By.xpath("//*[@id=\"appm\"]/div/app-associate-list/div[2]/div[2]/main/app-grid/div[2]/div/table/tbody")).size();
            List<WebElement> recordlist=new ArrayList<>();
            int j=0;
            while(j<5) {
                recordlist.add(driver.findElement(By.xpath("//tr[@class='mat-row ng-star-inserted']")));
                recordlist.get(j);
                break;
            }
            j++;*/
            int rowSize=  driver.findElements(By.xpath("//tr[@class='mat-row ng-star-inserted']")).size();
            if (selectedValue==rowSize)
          {
              System.out.println("recored count is correct");
          }
          else
          {
              throw new InterruptedException("recording count is missmatch please check again....");
          }
            qr.getRangearrow().click();
            i++;


        /*    int recored_size=recordlist.size();
            if (recored_size==getrecordsize)*/
            /*{
                System.out.println("recored count is correct");
            }
            else
            {
                throw new InterruptedException("recording count is missmatch please check again....");
            }
            i++;*/
        }
    }
    @Then("I close the according to select value record should be displayed web page")
    public void i_close_the_according_to_select_value_record_should_be_displayed_web_page() {
        end();
    }
    @When("I click on Merchent_Peromotions option")
    public void i_click_on_merchent_peromotions_option() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getMerchantPromotion().click();
        Thread.sleep(1000);
    }
    @Then("I verify that when we click on the merchant promotions that time merchant promotions respective page should be open")
    public void i_verify_that_when_we_click_on_the_merchant_promotions_that_time_merchant_promotions_respective_page_should_be_open() throws InterruptedException {
        String get_merchant_promotions=qr.getMechant_Promotions().getText();
        String merchant_promotions="Merchant Promotions";
        if (get_merchant_promotions!=null&&get_merchant_promotions.equals(merchant_promotions))
        {
            System.out.println("correct MerchantPromotions page found");
        }
        else {
            throw new InterruptedException("MerchantPromotions page not found try again...");
        }
    }
    @Then("I close the merchant promotions respective page should be open")
    public void i_close_the_merchant_promotions_respective_page_should_be_open() {
     end();
    }
    @When("I click on the Self Onboarding QR Code option")
    public void i_click_on_the_self_onboarding_qr_code_option() throws InterruptedException {
        qr.getChannel().click();
        Thread.sleep(1000);
        qr.getSelf_Onboarding_QR_Code().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I verify that when user click on the self onboarding QR code submenu that time respective page should be open")
    public void i_verify_that_when_user_click_on_the_self_onboarding_qr_code_submenu_that_time_respective_page_should_be_open() throws InterruptedException {
        String merchantonboardingtext="Merchant Onboarding - Generate QR Code";
        String get_merchantonboardingtext=qr.getMerchant_Onboarding_text().getText();
        if (get_merchantonboardingtext!=null&&get_merchantonboardingtext.equals(merchantonboardingtext))
        {
            System.out.println("Correct Merchant onboarding generate QR code page is open");
        }
        else
        {
            throw new InterruptedException("Correct Merchant onboarding generate QR code page is not open");
        }
    }
    @Then("I close the self onboarding QR code submenu that time respective page should be open scenario")
    public void i_close_the_self_onboarding_qr_code_submenu_that_time_respective_page_should_be_open_scenario() {
        end();
    }
    @When("I enter the Merchant name in select Merchant text_box")
    public void i_enter_the_merchant_name_in_select_merchant_text_box() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        String name=json.jsonActualReadData("MerchantName");
        qr.getSelect_Merchant().click();
        Thread.sleep(1000);
        qr.get_Merchant_Name_Entered().sendKeys(name);
        Thread.sleep(1000);
    }
    @Then("I verify that when user enter merchant name in select merchant text_box that time matched details should be show in suggestion box")
    public void i_verify_that_when_user_enter_merchant_name_in_select_merchant_text_box_that_time_matched_details_should_be_show_in_suggestion_box() throws InterruptedException {
        String searchoptions="James Kale , Zonal Vendor";
        WebElement options=qr.getSelectOptions();
        Select selectoption=new Select(options);
        selectoption.selectByVisibleText("James Kale , Zonal Vendor");
        WebElement element=selectoption.getFirstSelectedOption();
        String getelement=element.getText();
        System.out.println("get Element is:"+getelement);
        if (getelement.equals(searchoptions))
        {
            qr.get_Merchant_Name_Entered().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            System.out.println("match details is suggest");
        }
        else {
            throw new InterruptedException("Matched details is not suggest please check agian...");
        }
        }


        /*List<WebElement>getoption=selectoption.getOptions();
        int size=getoption.size();
        for (int i=0;i<size;i++)
        {
            String option=getoption.get(i).getText();
            if (option.contains(searchoptions))
            {
                System.out.println("match details is suggest");
            }
            else {
                throw new InterruptedException("Matched details is not suggest please check agian...");
            }
        }*/

    @Then("I close the user enter merchant name in select merchant text_box that time matched details should be show in suggestion box scenario")
    public void i_close_the_user_enter_merchant_name_in_select_merchant_text_box_that_time_matched_details_should_be_show_in_suggestion_box_scenario() {
        end();
    }
    @When("I enter the invalid merchant name in select merchant field")
    public void i_enter_the_invalid_merchant_name_in_select_merchant_field() throws InterruptedException {
        String name="abcd";
        qr.getSelect_Merchant().click();
        Thread.sleep(1000);
        qr.get_Merchant_Name_Entered().sendKeys(name);
        Thread.sleep(1000);
        qr.getSelect_Merchant().click();
        Thread.sleep(1000);
    }
    @Then("I verify URL is generate or not")
    public void i_verify_url_is_generate_or_not() throws InterruptedException {
        String url=qr.getBlankURL().getAttribute("value");
        System.out.println("URL is:="+url);
        if(url.isEmpty())
        {
            System.out.println("URL should not generate");
        }
        else {
            throw new InterruptedException("something wants wrong URL shoukd not be generated...");
        }

    }
    @Then("I close verify that when user enter another merchants name which are not present in the DB that time URL should not generate scenario")
    public void i_close_verify_that_when_user_enter_another_merchants_name_which_are_not_present_in_the_db_that_time_url_should_not_generate_scenario() {
        end();
    }
    @When("I select the merchant name")
    public void i_select_the_merchant_name() throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='Merchant']")));
        select.selectByVisibleText("James Kale , Zonal Vendor");
        Thread.sleep(1000);
    }
    @When("I copy the url for the self onboarding")
    public void i_copy_the_url_for_the_self_onboarding() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        qr.getCopyURL().click();
        Thread.sleep(2000);
        qr.getClosealter().click();
        Thread.sleep(1000);
        String pastdata=qr.getURL().getAttribute("value");
        System.out.println("Pastdata is"+pastdata);
        Thread.sleep(1000);
        json.jsonWrite("URL",pastdata);
    }
    @Then("I verify the copy URL should be open")
    public void i_verify_the_copy_url_should_be_open() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        // String url=readdata.readExcel("Sheet1","URL");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        String verify="finequs Partner Onboarding - QDE";
        String getverify=driver.findElement(By.xpath("//div[@id='merchantQDELink']")).getText();
        if (getverify.equals(verify))
        {
            System.out.println("copy URL should be open successfully...");
        }
        else {
            throw new InterruptedException("Something wants wrong with copied url please check....");
        }
        driver.switchTo().window(tabs.get(1)).close();
    }
    @Then("I close the verify the copy URL should be open scenario")
    public void i_close_the_verify_the_copy_url_should_be_open_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @Then("I verify the copy valid alter is displayed or not")
    public void i_verify_the_copy_valid_alter_is_displayed_or_not() throws InterruptedException {
        qr.getCopyURL().click();
        Thread.sleep(2000);
        String copyalter="URL Copied to Clipboard";
        String getcopyalter=qr.getCopyAlter().getText();
        if (getcopyalter.equals(copyalter)) {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("URL Copied successfully...");
        }
        else {
            throw new InterruptedException("URL is not able to copy please check again...");
        }
    }
    @Then("I close the verify that when user enter valid merchant name that time user should be able to copy URL and get the valid alter scenario")
    public void i_close_the_verify_that_when_user_enter_valid_merchant_name_that_time_user_should_be_able_to_copy_url_and_get_the_valid_alter_scenario() {
        end();
    }
    @When("I switch the tab for the self on boarding")
    public void i_switch_the_tab_for_the_self_on_boarding() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        ((JavascriptExecutor) driver).executeScript("window.open()");
        this.parentwindow= driver.getWindowHandle();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        String url=json.jsonReadData("URL");
        // String url=readdata.readExcel("Sheet1","URL");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I verify that when we onboarding-Generate QR code\\(copy URL through) open finques partner onboarding-QDE page that time Mobile, Email, First name, Last name, DOB, PAN card, Residence Pincode, Office pincode field should be displayed  mandatory format")
    public void i_verify_that_when_we_onboarding_generate_qr_code_copy_url_through_open_finques_partner_onboarding_qde_page_that_time_mobile_email_first_name_last_name_dob_pan_card_residence_pincode_office_pincode_field_should_be_displayed_mandatory_format() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_mobile_0']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_email_1']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_firstName_2']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_lastName_3']")));
        list.add(driver.findElement(By.xpath("//input[@id='dob-id']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_panCard_5']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_residencePinCode_6']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_9_input_officePinCode_7']")));
        int i=0;
        WebElement fields=list.get(i);
            if (fields.isDisplayed())
            {
                System.out.println("Finequs partner onboarding-QDE page all fields are available..");
            }
            else {
                throw new InterruptedException("some fields are not available please check...");
            }

        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1)).close();
    }
    @Then("I close verify that when we onboarding-Generate QR code\\(copy URL through) open finques partner onboarding-QDE page that time Mobile, Email, First name, Last name, DOB, PAN card, Residence Pincode, Office pincode field should be displayed  mandatory format scenario")
    public void i_close_verify_that_when_we_onboarding_generate_qr_code_copy_url_through_open_finques_partner_onboarding_qde_page_that_time_mobile_email_first_name_last_name_dob_pan_card_residence_pincode_office_pincode_field_should_be_displayed_mandatory_format_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @Then("I verify that when we onboarding-Generate QR code\\(copy URL through) open finques partner onboarding-QDE page that time Mobile, Email, First name, Last name, DOB, PAN card, Residence Pincode, Office pincode field should be displayed in mandatory format")
    public void i_verify_that_when_we_onboarding_generate_qr_code_copy_url_through_open_finques_partner_onboarding_qde_page_that_time_mobile_email_first_name_last_name_dob_pan_card_residence_pincode_office_pincode_field_should_be_displayed_in_mandatory_format() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        qr.getInsurance_Finish().click();
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,-200)");
        Thread.sleep(1000);
        List<String>list=new ArrayList<>();
        list.add("Mobile number required");
        list.add("Email is required");
        list.add("First Name is required");
        list.add("Last Name is required");
        list.add("DOB is required");
        list.add("Pan Card is required");
        list.add("Residence PinCode is required");
        list.add("Office Pincode is required");
        List<WebElement>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[1]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[2]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[3]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[4]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[5]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[6]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[7]")));
        list1.add(driver.findElement(By.xpath("(//div[@class='invalid-feedback'])[8]")));
        int i=0;
        while(i< list1.size())
        {
            String comparedata=list.get(i);
            String getdata=list1.get(i).getText();
            if (getdata.equals(comparedata))
            {
                System.out.println("All fields are mandatory...");
            }else {
                throw new InterruptedException("some field is newly added or missing please check....");
            }
            i++;
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        end();

    }
    @And("I close verify that when we onboarding-Generate QR code\\(copy URL through) open finques partner onboarding-QDE page that time Mobile, Email, First name, Last name, DOB, PAN card, Residence Pincode, Office pincode field should be displayed in mandatory format scenario")
    public void iCloseVerifyThatWhenWeOnboardingGenerateQRCodeCopyURLThroughOpenFinquesPartnerOnboardingQDEPageThatTimeMobileEmailFirstNameLastNameDOBPANCardResidencePincodeOfficePincodeFieldShouldBeDisplayedInMandatoryFormatScenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @When("I enter the mobile number")
    public void i_enter_the_mobile_number() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        inputGenerator.mobileNumberGenerator();
        String mobile=json.jsonReadData("MobileNumber");
        qr.get_FPO_Mobilenumber().sendKeys(mobile);
        Thread.sleep(1000);
    }
    @When("I enter the email id")
    public void i_enter_the_email_id() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
       // String email_id=json.jsonActualReadData("OfficialEmail_id");
        qr.get_FPO_EmailID().sendKeys(inputGenerator.getEmailAddress()+"@gmail.com");
        Thread.sleep(1000);
    }
    @When("I enter the invalid first name")
    public void i_enter_the_invalid_first_name() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        String firstname=json.jsonActualReadData("InvalidFirstName");
        qr.get_FPO_FirstName().sendKeys(firstname);
        Thread.sleep(1000);
    }
    @When("I enter the Last name")
    public void i_enter_the_last_name() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String lastname=json.jsonActualReadData("Lastname");
        qr.get_FPO_Lastname().sendKeys(lastname);
        Thread.sleep(1000);
    }
    @When("I enter the DOB")
    public void i_enter_the_dob() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String dob=json.jsonActualReadData("DOB");
        qr.get_FPO_DOB().sendKeys(dob);
        Thread.sleep(1000);
    }
    @When("I enter PAN card number")
    public void i_enter_pan_card_number() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String pan=json.jsonActualReadData("panno");
        qr.get_FPO_PAN_Number().sendKeys(pan);
        Thread.sleep(1000);
    }
    @When("I enter the residence pincode")
    public void i_enter_the_residence_pincode() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String residencepincode= json.jsonActualReadData("Residence_pincode");
        qr.get_Residence_Pincode().sendKeys(residencepincode);
        Thread.sleep(1000);
    }
    @When("I enter the office pincode")
    public void i_enter_the_office_pincode() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String office_pincode=json.jsonActualReadData("pincodeno");
        qr.get_FPO_OfficePincode().sendKeys(office_pincode);
        Thread.sleep(1000);
    }
    @When("I click on the finish button")
    public void i_click_on_the_finish_button() throws InterruptedException {
        qr.getInsurance_Finish().click();
        Thread.sleep(5000);
    }
    @Then("I verify the please enter valid details is displayed or not")
    public void i_verify_the_please_enter_valid_details_is_displayed_or_not() throws InterruptedException {
        String msg="Please enter valid name";
        String getmsg=driver.findElement(By.xpath("//div[@class='invalid-feedback']")).getText();
        if (getmsg.equals(msg))
        {
            System.out.println("please enter valid details is displayed...");
        }
        else {
            throw new InterruptedException("for madatory field alter is not displyed....");
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        end();
    }
    @And("I close the verify the please enter valid details is displayed or not scenario")
    public void i_close_the_verify_the_please_enter_valid_details_is_displayed_or_not_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }
    @When("I click on the loan")
    public void i_click_on_the_loan() throws InterruptedException {
       /* qr.getChannel().click();
        Thread.sleep(1000);*/
        qr.getLoans().click();
        Thread.sleep(1000);
    }
    @When("I click on reverse file upload option")
    public void i_click_on_reverse_file_upload_option() throws InterruptedException {
        qr.get_Reverse_File_Upload_Option().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I verify Reverse File Upload respective page should be open or not")
    public void i_verify_reverse_file_upload_respective_page_should_be_open_or_not() throws InterruptedException {
        String reversefileUploadpage="File upload";
        String getreversefileuploadpage=qr.getReverseFilePage().getText();
        if (getreversefileuploadpage.equals(reversefileUploadpage))
        {
            System.out.println("Correct Reverse File Page Open");
        }
        else {
            throw new InterruptedException("incorrect reverse file page Open please check...");
        }
    }
    @Then("I close the verify Reverse File Upload respective page should be open or not scenario")
    public void i_close_the_verify_reverse_file_upload_respective_page_should_be_open_or_not_scenario() {
        end();
    }
    @When("I select the bank selection Q option")
    public void i_select_the_bank_selection_q_option() throws InterruptedException {
        qr.get_Bank_Selction_Q().click();
       Thread.sleep(9000);
    }
    @Then("I write the Application id for verification")
    public void i_write_the_application_id_for_verification() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String applicationid=qr.getPDApplicationID().getText();
        json.jsonWrite("AppID",applicationid);
        Thread.sleep(1000);
    }
    @Then("I verify that the Bank Slection Q webpage is displayed or not")
    public void i_verify_that_the_bank_slection_q_webpage_is_displayed_or_not() throws InterruptedException {
        String bankselectionmsg="Bank Selection Queue";
        String getbankseletionmsg=driver.findElement(By.xpath("//p[text()='Bank Selection Queue']")).getText();
        if (getbankseletionmsg!=null&&getbankseletionmsg.equals(bankselectionmsg))
        {
            System.out.println("Bank Selection QUeue page found successfully...");
        }
        else {
            throw new InterruptedException("Wrong page is displayed please check....");
        }
    }
    @Then("I close the Verify that bank selection Q Webpage is displayed or nor scenario")
    public void i_close_the_verify_that_bank_selection_q_webpage_is_displayed_or_nor_scenario() {
        end();
    }

    @Then("I verify that all fields are in read only format or not")
    public void i_verify_that_all_fields_are_in_read_only_format_or_not() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_firstName_1']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_lastName_2']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_DOB_3']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_mobile_4']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_panNumber_5']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_occupation_6']")));
        list.add(driver.findElement(By.xpath("//select[@id='formly_11_select_loanAppliedFor_7']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_11_input_pincode_9']")));
        int i=0;
        while (i<list.size())
        {
       if (!list.get(i).isEnabled()){
           System.out.println("field is read only format");
       }
       else {
           throw new InterruptedException("field is not in read only format...");
       }
       i++;
        }
    }
    @Then("I close the verify that all fields are in red only format or not scenario")
    public void i_close_the_verify_that_all_fields_are_in_red_only_format_or_not_scenario() {
        end();
    }
    @Then("I verify field should be display editable format in Bank selection Q page")
    public void i_verify_field_should_be_display_editable_format_in_bank_selection_q_page() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@id='formly_11_select_loan2AppliedFor_8']")));
        list.add(driver.findElement(By.xpath("//select[@name='gender']")));
        list.add(driver.findElement(By.xpath("//input[@name='currentAddress']")));
        list.add(driver.findElement(By.xpath("//input[@name='email']")));
        list.add(driver.findElement(By.xpath("//input[@name='loanAmount']")));
        list.add(driver.findElement(By.xpath("//input[@name='netMonthlyIncome']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
       // list.add(driver.findElement(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        //list.add(driver.findElement(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isEnabled()&&list.get(i).isDisplayed())
            {
                System.out.println("field should be display editable format successfully...");
            }
            else {
                throw new InterruptedException("Field is not in editable format please check...");
            }
            i++;
        }
    }
    @Then("I close the verify field should be display editable format in Bank selection Q page scenario")
    public void i_close_the_verify_field_should_be_display_editable_format_in_bank_selection_q_page_scenario() {
        end();
    }
    @When("I Enter the valid details for the bank selection Q page")
    public void i_enter_the_valid_details_for_the_bank_selection_q_page() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='gender']")));
        select.selectByVisibleText("Male");
        Thread.sleep(1000);

        String currentaddress=json.jsonActualReadData("CurrentAddress");
        driver.findElement(By.xpath("//input[@formcontrolname='currentAddress']")).sendKeys(currentaddress);
        Thread.sleep(1000);

        String email=json.jsonActualReadData("OfficialEmail_id");
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).sendKeys(email);
        Thread.sleep(1000);

        Select select1=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
        select1.selectByVisibleText("Yes");
        Thread.sleep(1000);

        String pincode=json.jsonActualReadData("pincodeno");
        driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")).sendKeys(pincode);
        Thread.sleep(1000);

       /* Select ss=new Select(driver.findElement(By.xpath("//select[@formcontrolname='residenceType']")));
        ss.selectByVisibleText("Owned");
        Thread.sleep(1000);


        Select s=new Select(driver.findElement(By.xpath("//select[@formcontrolname='OfficeType']")));
        s.selectByVisibleText("Owned");
        Thread.sleep(1000);*/


      Select select2=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        select2.selectByVisibleText("Yes");
        Thread.sleep(1000);

        Select select3=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        select3.selectByVisibleText("Yes");
        Thread.sleep(1000);
    }
    @Then("I verify that when we enter valid details for Additional Data Required section,that time sent OTP button should be displayed enable format")
    public void i_verify_that_when_we_enter_valid_details_for_additional_data_required_section_that_time_sent_otp_button_should_be_displayed_enable_format() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='gender']")));
        select.selectByVisibleText("Male");
        Thread.sleep(1000);

        String currentaddress=json.jsonActualReadData("CurrentAddress");
        driver.findElement(By.xpath("//input[@formcontrolname='currentAddress']")).sendKeys(currentaddress);
        Thread.sleep(1000);

        String email=json.jsonActualReadData("OfficialEmail_id");
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).sendKeys(email);
        Thread.sleep(1000);

        Select select1=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
        select1.selectByVisibleText("Yes");
        Thread.sleep(1000);

       /* Select select2=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        select2.selectByVisibleText("Yes");
        Thread.sleep(1000);

        Select select3=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        select3.selectByVisibleText("Yes");
        Thread.sleep(1000);
*/
        String pincode=json.jsonActualReadData("pincodeno");
        driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")).sendKeys(pincode);
        Thread.sleep(1000);

        if(qr.getSubmitBankSelectionQ().isEnabled())
        {
            System.out.println("sent OTP button is displayed enable format");
        }
        else {
            throw new InterruptedException("sent OTP button is not displayed enable format");
        }
    }
    @Then("I close verify that when we enter valid details for Additional Data Required section,that time sent OTP button should be displayed enable format scenario")
    public void i_close_verify_that_when_we_enter_valid_details_for_additional_data_required_section_that_time_sent_otp_button_should_be_displayed_enable_format_scenario() {
       end();
    }
    @Then("I search the application for the bank selection page")
    public void i_search_the_application_for_the_bank_selection_page() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
           Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

                if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
                {
                    System.out.println("Process the application id....");
                }
                else {
                    js=(JavascriptExecutor)driver;
                    js.executeScript("window.scrollBy(0,-3000)");
                    Thread.sleep(1000);

                   // this.i_search_the_application_for_the_bank_selection_page();
                }
        }
    }

    @When("I click on the send OTP button in bank selection Q page")
    public void i_click_on_the_send_otp_button_in_bank_selection_q_page() throws InterruptedException {
        qr.getSendOTP().click();
        Thread.sleep(3000);
        String verifymsg="An OTP has been sent to your mobile number";
        String alter=qr.getAlter().getText();
        if (alter.equals(verifymsg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter accepted...");
        }
        else {
            throw new InterruptedException("OTP is nor send successfully please check....");
        }
    }
    @Then("I verify the field should be displayed read only format")
    public void i_verify_the_field_should_be_displayed_read_only_format() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@name='gender']")));
        list.add(driver.findElement(By.xpath("//input[@name='currentAddress']")));
        list.add(driver.findElement(By.xpath("//input[@name='email']")));
        list.add(driver.findElement(By.xpath("//input[@name='loanAmount']")));
        list.add(driver.findElement(By.xpath("//input[@name='netMonthlyIncome']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
        //list.add(driver.findElement(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        //list.add(driver.findElement(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")));
        int i=0;
        while (i<list.size())
        {
            if (!list.get(i).isEnabled()&&list.get(i).isDisplayed())
            {
                System.out.println("field not in non-editable format");
            }
            else {
                throw new InterruptedException("Field is editable format please check...");
            }
            i++;
        }
    }
    @Then("I close the verify that,when we generate OTP on the Bank Selection Queue page that time Gender, Current Address, Email, Loan Amount, Net Monthely Income, Do you have Banking, is your salary credited in bank account do you have salary slip or salary certificate office pincode field should be displayed read only format")
    public void i_close_the_verify_that_when_we_generate_otp_on_the_bank_selection_queue_page_that_time_gender_current_address_email_loan_amount_net_monthely_income_do_you_have_banking_is_your_salary_credited_in_bank_account_do_you_have_salary_slip_or_salary_certificate_office_pincode_field_should_be_displayed_read_only_format() {
        end();
    }
    @Then("I verify the Additional Data Required fields are mandatory or not for the bank selection Q page")
    public void i_verify_the_additional_data_required_fields_are_mandatory_or_not_for_the_bank_selection_q_page() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-200)");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='currentAddress']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).clear();
        Thread.sleep(1000);
        String email=json.jsonActualReadData("InvalidEmailId");
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).sendKeys(email);
        Thread.sleep(1000);
        qr.getLabelEmail().click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")).click();
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        qr.getOfficePinCodeLabel().click();
        Thread.sleep(1000);
        List<String>list=new ArrayList<>();
        list.add("Current Address is required");
        list.add("Please enter valid email");
        list.add("Office Pincode is required");
        List<WebElement>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[1]")));
        list1.add(driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")));
        list1.add(driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[3]")));
        int i=0;
        String getvalidmsg=list1.get(i).getText();
        String msg=list.get(i);
        while(i< list1.size())
        {
         if (getvalidmsg.equals(msg))
         {
             System.out.println("All fields having validation");
         }
         else {
             throw new InterruptedException("Some fielsds are not mandatory please check...");
         }
         i++;
        }
    }
    @Then("I close the verify the Additional Data Required fields are mandatory or not for the bank selection Q page scenario")
    public void i_close_the_verify_the_additional_data_required_fields_are_mandatory_or_not_for_the_bank_selection_q_page_scenario() {
        end();
    }
    @Then("I verify alert should be displayed please enter valid deatils or not")
    public void i_verify_alert_should_be_displayed_please_enter_valid_deatils_or_not() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);

        String email=json.jsonActualReadData("InvalidEmailId");
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).sendKeys(email);
        Thread.sleep(1000);

        String pincode=json.jsonActualReadData("CurrentAddress");
        driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")).sendKeys(pincode);
        Thread.sleep(1000);

        qr.getOfficePinCodeLabel().click();
        Thread.sleep(1000);
        List<String>list=new ArrayList<>();
        list.add("Please enter valid email");
        list.add("Please enter valid pincode");
        List<WebElement>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[1]")));
        list1.add(driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")));
        int i=0;
        String getmsg=list1.get(i).getText();
        String msg=list.get(i);
        while (i< list1.size())
        {
            if (getmsg.equals(msg))
            {
                System.out.println("alert is displayed for invalid data");
            }
            else {
                throw new InterruptedException("alter is displayed for the invalid data please check...");
            }
            i++;
        }
    }
    @Then("I close verify that when we enter inavlid deatils for Additional Data Required section Email, Loan Amount, Net Monthely Income, office pincode filed that time alert should be displayed please enter valid deatils")
    public void i_close_verify_that_when_we_enter_inavlid_deatils_for_additional_data_required_section_email_loan_amount_net_monthely_income_office_pincode_filed_that_time_alert_should_be_displayed_please_enter_valid_deatils() {
       end();
    }
    @Then("I verify Send OTP button should be displayed disable format")
    public void i_verify_send_otp_button_should_be_displayed_disable_format() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-300)");
        Thread.sleep(1000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='gender']")));
        select.selectByVisibleText("Male");
        Thread.sleep(1000);

        String currentaddress=json.jsonActualReadData("CurrentAddress");
        driver.findElement(By.xpath("//input[@formcontrolname='currentAddress']")).sendKeys(currentaddress);
        Thread.sleep(1000);

        String email=json.jsonActualReadData("OfficialEmail_id");
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='email']")).sendKeys(email);
        Thread.sleep(1000);

        driver.findElement(By.xpath("//input[@name='loanAmount']")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='loanAmount']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='loanAmount']")).sendKeys(Keys.SPACE);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='loanAmount']")).click();
        Thread.sleep(1000);
       // driver.findElement(By.xpath("//input[@name='loanAmount']")).click();

        driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")).click();
        Thread.sleep(1000);
        Select select1=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isNetBankingAvailable']")));
        select1.selectByVisibleText("Yes");
        Thread.sleep(1000);

        Select select2=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalaryAccountAvailable']")));
        select2.selectByVisibleText("Yes");
        Thread.sleep(1000);

        Select select3=new Select(driver.findElement(By.xpath("//select[@formcontrolname='isSalarySlipAvailable']")));
        select3.selectByVisibleText("Yes");
        Thread.sleep(1000);

        String pincode=json.jsonActualReadData("pincodeno");
        driver.findElement(By.xpath("//input[@formcontrolname='officePincode']")).sendKeys(pincode);
        Thread.sleep(1000);

        if(!qr.getSubmitBankSelectionQ().isEnabled())
        {
            System.out.println("sent OTP button is displayed enable format");
        }
        else {
            throw new InterruptedException("sent OTP button is not displayed enable format");
        }
    }
    @Then("I close verify Send OTP button should be displayed disable format scenario")
    public void i_close_verify_send_otp_button_should_be_displayed_disable_format_scenario() {
        end();
    }
    @Then("I verify the Enter OTP textbox field should be auto-populate or not")
    public void i_verify_the_enter_otp_textbox_field_should_be_auto_populate_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        if (qr.getEnterOTPCreditQDE().isDisplayed())
        {
            System.out.println("Enter OTP textbox field is auto-populate");
        }
        else {
            throw new InterruptedException("Enter OTP textbox field is not auto-populate please check...");
        }
    }
    @Then("I close the verify the Enter OTP textbox field should be auto-populate or not scenario")
    public void i_close_the_verify_the_enter_otp_textbox_field_should_be_auto_populate_or_not_scenario() {
        end();
    }
    @Then("I verify the alert should be displayed something went wrong or Please relogin in CENTURE App or not")
    public void i_verify_the_alert_should_be_displayed_something_went_wrong_or_please_relogin_in_centure_app_or_not() throws InterruptedException {
        qr.getCallButton().click();
        Thread.sleep(2000);
        String alter="Something Went Wrong OR Please re-login in CENTAUR App !";
        String getalter=qr.getAlter().getText();
        if (getalter.equals(alter))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("correct alter is display...");
        }
        else {
            throw new InterruptedException("alter is not display something wants wrong please check again...");
        }
    }
    @And("I close verify the alert should be displayed something went wrong or Please relogin in CENTURE App or not scenario")
    public void iCloseVerifyTheAlertShouldBeDisplayedSomethingWentWrongOrPleaseReloginInCENTUREAppOrNotScenario() {
        end();
    }
    @Then("I verify that  when user select decline reason & click on the submit button that time lead should be able to decline")
    public void i_verify_that_when_user_select_decline_reason_click_on_the_submit_button_that_time_lead_should_be_able_to_decline() throws InterruptedException {
        qr.getDeclineButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        Select select=new Select(qr.getDeclineReason());
        select.selectByVisibleText("Low bank balance");
        Thread.sleep(1000);

        qr.getDeclineReasonSubmitButton().click();
        Thread.sleep(5000);
        String msg="Decline reason updated successfully.";
        String getMsg=qr.getAlter().getText();
        if (getMsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("Correct Decline alter accepted...");
        }
        else {
            throw new InterruptedException("incorrect Decline alter is not dispalyed please chech again...");
        }

    }
    @Then("I close the verify that  when user select decline reason & click on the submit button that time lead should be able to decline scenario")
    public void i_close_the_verify_that_when_user_select_decline_reason_click_on_the_submit_button_that_time_lead_should_be_able_to_decline_scenario() {
       end();
    }
    @Then("I verify that when we click on the Decline button that time decline respective popup should be open or not")
    public void i_verify_that_when_we_click_on_the_decline_button_that_time_decline_respective_popup_should_be_open_or_not() throws InterruptedException {
        qr.getDeclineButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//h6[@id='modal-basic-title']")));
        list.add(driver.findElement(By.xpath("//label[text()='Declined Reason']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='declinereason']")));
        list.add(driver.findElement(By.xpath("//button[text()='Submit']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&!driver.findElement(By.xpath("//button[text()='Submit']")).isEnabled())
            {
                System.out.println("Decline pop up displayed successfully.....");
            }
            else {
                throw new InterruptedException("something wants wrong decline pop up is not displayed please check again....");
            }
            i++;
        }

    }
    @And("I close the verify that when we click on the Decline button that time decline respective popup should be open scenario")
    public void iCloseTheVerifyThatWhenWeClickOnTheDeclineButtonThatTimeDeclineRespectivePopupShouldBeOpenScenario() {
        end();
    }
    @Then("I verify that when user click on the diaries button that time diarise respective page should be open")
    public void i_verify_that_when_user_click_on_the_diaries_button_that_time_diarise_respective_page_should_be_open() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,3000)");
        Thread.sleep(1000);
        qr.getDiariseButton().click();
        Thread.sleep(1000);

        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@id='dob-id']")));
        list.add(driver.findElement(By.xpath("//td[@class='form-group']")));
        list.add(driver.findElement(By.xpath("//td[@class='form-group ng-star-inserted']")));
        list.add(driver.findElement(By.xpath("//select[@id='diariseReason']")));
        list.add(driver.findElement(By.xpath("//textarea[@id='comment']")));
        list.add(driver.findElement(By.xpath("//button[text()='Submit']")));
        list.add(driver.findElement(By.xpath("//button[@class='close']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("diaries respective page is open successfully...");
            }
            else {
                throw new InterruptedException("diaries respective page is not open please check...");
            }
            i++;
        }
    }
    @And("I close verify that when user click on the diaries button that time diarise respective page should be open")
    public void i_close_verify_that_when_user_click_on_the_diaries_button_that_time_diarise_respective_page_should_be_open() {
        end();
    }
    @When("I click on the diarise button")
    public void i_click_on_the_diarise_button() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        
        qr.getDiariseButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();

        Select select=new Select(driver.findElement(By.xpath("//select[@id='diariseReason']")));
        select.selectByVisibleText("customer asked to call back");
        Thread.sleep(1000);

        String comment=json.jsonActualReadData("Comment");
        qr.getComment().sendKeys(comment);
        Thread.sleep(1000);

        qr.getDeclineReasonSubmitButton().click();
        Thread.sleep(2000);
    }
    @Then("I update the diarise successfully")
    public void i_update_the_diarise_successfully() {
        qr.getDatacollectionok().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }

    @Then("I verify that when user enter valid details on the diarise popupe & click on the submit button that time lead should be dairise or not")
    public void i_verify_that_when_user_enter_valid_details_on_the_diarise_popupe_click_on_the_submit_button_that_time_lead_should_be_dairise_or_not() throws InterruptedException {
        String msg="Diarise updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("diarise updated successfully...");
        }
        else {
            throw new InterruptedException("diarise cant updated successfully please check...");
        }
    }
    @Then("I close the  verify that when user enter valid details e on the diarise popupe & click on the submit button that time lead should be dairise or not scenario")
    public void i_close_the_verify_that_when_user_enter_valid_details_e_on_the_diarise_popupe_click_on_the_submit_button_that_time_lead_should_be_dairise_or_not_scenario() {
        end();
    }
    @When("I click on the Diarise Queue")
    public void i_click_on_the_diarise_queue() throws InterruptedException {
        qr.getDiariseQueue().click();
        Thread.sleep(1000);
    }

    @Then("I verify that when diarise button through when we diarise lead that diarised lead should display in the Diarise queue or not")
    public void i_verify_that_when_diarise_button_through_when_we_diarise_lead_that_diarised_leadd_should_display_in_the_diarise_queue_or_not() throws IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,90)");
        String getAppId=qr.getApplicationID().getText();
        String AppId=json.jsonReadData("AppID");
        if (getAppId.equals(AppId))
        {
            System.out.println("diarised lead is display in the Diarise queue successfully...");
        }
        else {
            throw new InterruptedIOException("diarised lead is not  in the Diarise queue please check...");
        }
    }
    @Then("I close the verify that when diarise button through when we diarise lead that that diarised laed should dispaly in the Diarise queue scenario")
    public void i_close_the_verify_that_when_diarise_button_through_when_we_diarise_lead_that_that_diarised_laed_should_dispaly_in_the_diarise_queue_scenario() {
       end();
    }
    @Then("I verify that diarised lead should moved diarise queue to Bank selection queue or not")
    public void i_verify_that_diarised_lead_should_moved_diarise_queue_to_bank_selection_queue_or_not() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        qr.getNavigationBar().click();
        Thread.sleep(1000);

        /*qr.getLoans().click();
        Thread.sleep(1000);*/

        qr.getLoanApplication().click();
        ngwebdriver.waitForAngularRequestsToFinish();

        String appid=json.jsonReadData("AppID");
        qr.getQuickAppId().sendKeys(appid);
        Thread.sleep(1000);

        qr.getQuickAppId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        String status="Bank Selection";
        String getStatus=qr.getFinalStatus().getText();
        if (getStatus.equals(status))
        {
            System.out.println("diarised lead Final status is Bank selection...");
        }
        else {
            throw new InterruptedException("diarised lead is moved diarise queue to Bank selection queue please check....");

        }
    }
    @And("I close the verify that diarised lead should moved diarise queue to Bank selection queue or not scenario")
    public void i_close_the_verify_that_diarised_lead_should_moved_diarise_queue_to_bank_selection_queue_or_not_scenario() {
       end();
    }
    @Then("I verify Customer not intrested respective popup should be open or not")
    public void i_verify_customer_not_intrested_respective_popup_should_be_open_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);

        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);

        List<WebElement>list=new ArrayList<>();
        list.add(qr.getCopyAlter());
        list.add(qr.getDatacollectionok());
        list.add(qr.getCancelButton());
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Customer not intrested respective popup is open");
            }
            else {
                throw new InterruptedException("Customer not intrested respective popup is not open please check...");
            }
            i++;
        }
    }
    @And("I close the Customer not intrested respective popup should be open or not scenario")
    public void i_close_the_customer_not_intrested_respective_popup_should_be_open_or_not_scenario() {
      end();
    }
    @Then("I verify that when user click on the Ok button on the Customer not intrested popupe that time lead should be declined or not")
    public void i_verify_that_when_user_click_on_the_ok_button_on_the_customer_not_intrested_popupe_that_time_lead_should_be_declined_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);

        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);

        qr.getDatacollectionok().click();
        Thread.sleep(2000);
        String msg="Decline reason updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("lead is declined successfully...");
        }
        else {
            throw new InterruptedException("lead is not declined please check...");
        }
    }
    @And("I close verify that when user click on the Ok button on the Customer not intrested popupe that time lead should be declined or not Scenario")
    public void i_close_verify_that_when_user_click_on_the_ok_button_on_the_customer_not_intrested_popupe_that_time_lead_should_be_declined_or_not_scenario() {
       end();
    }
    @Then("I verify the submit button should be display enable or not")
    public void i_verify_the_submit_button_should_be_display_enable_or_not() throws InterruptedException {
        if(qr.getPersonalSubmit().isEnabled())
        {
            System.out.println("submit button should be display enable ");
        }
        else {
            throw new InterruptedException("submit button is not enable please check...");
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        end();
    }
    @Then("I verify the submit button should be display disable or not")
    public void i_verify_the_submit_button_should_be_display_disable_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        if(!driver.findElement(By.xpath("(//button[text()=' Submit '])[1]")).isEnabled())
        {
            System.out.println("submit button is display disable ");
        }
        else {
            throw new InterruptedException("submit button is not disableplease check...");
        }
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        end();
    }
    @Then("I close the verify the submit button should be display disable or not scenario")
    public void i_close_the_verify_the_submit_button_should_be_display_disable_or_not_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
        end();
    }

    @Then("I close the verify the submit button should be display enable or not scenario")
    public void i_close_the_verify_the_submit_button_should_be_display_enable_or_not_scenario() {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(0));
      end();
      
    }
    @When("I selects the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_selects_the_as(String string, String string2) throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@placeholder='"+string+"']")));
        select.selectByVisibleText(string2);
        Thread.sleep(1000);
    }
    @When("I choosed the \"([^\"]*)\" as \"([^\"]*)\"$")
    public void i_choosed_the_as(String string, String string2) throws InterruptedException {
       Select select=new Select(driver.findElement(By.xpath("//select[@name='"+string+"']")));
       select.selectByValue(string2);
       Thread.sleep(1000);
    }
    @Then("I verify the MIS Upload file respective page should be open or not")
    public void i_verify_the_mis_upload_file_respective_page_should_be_open_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@name='misName']")));
        list.add(driver.findElement(By.xpath("//button[@title='Refresh list']")));
        list.add(driver.findElement(By.xpath("(//tr[@class='mat-header-row ng-star-inserted'])[1]")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("The MIS Upload file respective page is open");
            }
            else {
                throw new InterruptedException("the MIS Upload file respective page is not open please check");
            }
            i++;
        }

    }
    @And("I close the verify the MIS Upload file respective page should be open or not scenario")
    public void i_close_the_verify_the_mis_upload_file_respective_page_should_be_open_or_not_scenario() {
       end();
    }
    @Then("I verify the Action, Batch No, UploadedBy, TotalRecords, Success, Failure, NotFoundException, OtherException column should be displayed or not")
    public void i_verify_the_action_batch_no_uploaded_by_total_records_success_failure_not_found_exception_other_exception_column_should_be_displayed_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[@class='d-flex align-items-center ng-star-inserted']")));
        list.add(driver.findElement(By.xpath("//span[text()='BatchNo']")));
        list.add(driver.findElement(By.xpath("//span[text()='UploadedBy']")));
        list.add(driver.findElement(By.xpath("//span[text()='TotalRecords']")));
        list.add(driver.findElement(By.xpath("//span[text()='Success']")));
        list.add(driver.findElement(By.xpath("//span[text()='Failure']")));
        list.add(driver.findElement(By.xpath("//span[text()='NotFoundException']")));
        list.add(driver.findElement(By.xpath("//span[text()='OtherException']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("The Action, Batch No, UploadedBy, TotalRecords, Success, Failure, NotFoundException, OtherException column should be displayed ");
            }
            else {
                throw new InterruptedException("some column are not available please check...");
            }
            i++;
        }
    }
    @And("I verify the Action, Batch No, UploadedBy, TotalRecords, Success, Failure, NotFoundException, OtherException column should be displayed or not scenario")
    public void i_verify_the_action_batch_no_uploaded_by_total_records_success_failure_not_found_exception_other_exception_column_should_be_displayed_or_not_scenario() {
      end();
    }
    @Then("I verify that searchbox field should be displayed under the Action, Batch No, UploadedBy, TotalRecords, Success, Failure, NotFoundException, OtherException field on the MIS Upload file page or not")
    public void i_verify_that_searchbox_field_should_be_displayed_under_the_action_batch_no_uploaded_by_total_records_success_failure_not_found_exception_other_exception_field_on_the_mis_upload_file_page_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//thead//tr//th[2]//span[text()='BatchNo']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[3]//span[text()='UploadedBy']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[4]//span[text()='TotalRecords']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[5]//span[text()='Success']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[6]//span[text()='Failure']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[7]//span[text()='NotFoundException']")));
        list.add(driver.findElement(By.xpath("//thead//tr//th[8]//span[text()='OtherException']")));
        List<WebElement>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("//thead//tr//th[2]//input[@placeholder='BatchNo']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[3]//input[@placeholder='UploadedBy']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[4]//input[@placeholder='TotalRecords']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[5]//input[@placeholder='Success']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[6]//input[@placeholder='Failure']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[7]//input[@placeholder='NotFoundException']")));
        list1.add(driver.findElement(By.xpath("//thead//tr//th[8]//input[@placeholder='OtherException']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed()&&list1.get(i).isDisplayed())
            {
                System.out.println("search box field is displayed");
            }
            else {
                throw new InterruptedException("search box field is not displayed please check...");
            }
            i++;
        }
    }
    @And("I close the verify that searchbox field should be displayed under the Action, Batch No, UploadedBy, TotalRecords, Success, Failure, NotFoundException, OtherException field on the MIS Upload file page or not scenario")
    public void i_close_the_verify_that_searchbox_field_should_be_displayed_under_the_action_batch_no_uploaded_by_total_records_success_failure_not_found_exception_other_exception_field_on_the_mis_upload_file_page_or_not_scenario() {
        end();
    }
    @Then("I verify that under the Action column Action icon should be displayed or not")
    public void i_verify_that_under_the_action_column_action_icon_should_be_displayed_or_not() throws InterruptedException {
        WebElement action_column=driver.findElement(By.xpath("//thead//tr//th//span[text()='Action']"));
        WebElement action_icon=driver.findElement(By.xpath("//tbody//tr//td//div//mat-icon[text()='remove_red_eye']"));
        if (action_column.isDisplayed()&& action_icon.isDisplayed())
        {
            System.out.println("Action icon is displayed under Action Column");
        }
        else {
            throw new InterruptedException("Action icon is not  under Action Column please check...");
        }
    }
    @And("I close the verify that under the Action column Action icon should be displayed or not scenario")
    public void i_close_the_verify_that_under_the_action_column_action_icon_should_be_displayed_or_not_scenario() {
        end();
    }
    @When("I click on the view icon")
    public void i_click_on_the_view_icon() throws InterruptedException {
        qr.getViewButtonIcon().click();
        Thread.sleep(2000);
    }

    @Then("I verify that when we click on the Click to view icon that time click to view respective page should be open or not")
    public void i_verify_that_when_we_click_on_the_click_to_view_icon_that_time_click_to_view_respective_page_should_be_open_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[text()='FileDate']")));
        list.add(driver.findElement(By.xpath("//span[text()='ApplicationId']")));
        list.add(driver.findElement(By.xpath("//span[text()='MobileNumber']")));
        list.add(driver.findElement(By.xpath("//span[text()='FirstName']")));
        list.add(driver.findElement(By.xpath("//span[text()='LastName']")));
        list.add(driver.findElement(By.xpath("//span[text()='ErrorMessage']")));
        list.add(driver.findElement(By.xpath("(//tr[@class='mat-header-row ng-star-inserted'])[2]")));
        //************button***************
        list.add(driver.findElement(By.xpath("//button[text()='Back']")));
        list.add(driver.findElement(By.xpath("//button[text()=' Download Excel ']")));
        list.add(driver.findElement(By.xpath("//button[@title='Refresh list']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("view icon respective page is open");
            }
            else {
                throw new InterruptedException("view icon respective page is not open please check...");
            }
            i++;
        }
    }
    @And("I close verify that when we click on the Click to view icon that time click to view respective page should be open or not scenario")
    public void i_close_verify_that_when_we_click_on_the_click_to_view_icon_that_time_click_to_view_respective_page_should_be_open_or_not_scenario() {
        end();
    }
    @When("I get the TotalRecord count")
    public void i_get_the_total_record_count() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        String viewrecordcount=qr.getViewRecordCount().getText();
        json.jsonWrite("ViewRecordCount",viewrecordcount);
        Thread.sleep(1000);
    }
    @Then("I verify the same number of record should be displayed in the click to view page which are showing TotalRecords On file upload report or not")
    public void i_verify_the_same_number_of_record_should_be_displayed_in_the_click_to_view_page_which_are_showing_total_records_on_file_upload_report_or_not() throws IOException, org.json.simple.parser.ParseException {
        int getcount=driver.findElements(By.xpath("//tr[@class='mat-row ng-star-inserted']")).size();
        int count= Integer.parseInt(json.jsonReadData("ViewRecordCount"));
        if (getcount==count)
        {
            System.out.println("same number of record is displayed in the click to view page which are showing TotalRecords On file upload report");
        }
        else {
            throw new InterruptedIOException("same number of record is not displayed in the click to view page which are showing TotalRecords On file upload report please check....");
        }
    }
    @And("I close the verify the same number of record should be displayed in the click to view page which are showing TotalRecords On file upload report or not scenario")
    public void i_close_the_verify_the_same_number_of_record_should_be_displayed_in_the_click_to_view_page_which_are_showing_total_records_on_file_upload_report_or_not_scenario() {
            end();
    }
    @Then("I verify the same number of record should be displayed in the click to view page which are showing failure On file upload report or not")
    public void i_verify_the_same_number_of_record_should_be_displayed_in_the_click_to_view_page_which_are_showing_failure_on_file_upload_report_or_not() throws IOException, org.json.simple.parser.ParseException {
        int getcount=driver.findElements(By.xpath("//tbody//tr//td//span[text()='APPLICATION NOT FOUND']")).size();
        int count= Integer.parseInt(json.jsonReadData("ViewRecordCount"));
        if(getcount==count)
        {
            System.out.println("same number of record is displayed in the click to view page which are showing Failure On file upload report");
        }
        else {
            throw new InterruptedIOException("same number of record is not displayed in the click to view page which are showing Failure On file upload report please check....");
        }
    }

    @And("I close the verify the same number of record should be displayed in the click to view page which are showing failure On file upload report or not")
    public void iCloseTheVerifyTheSameNumberOfRecordShouldBeDisplayedInTheClickToViewPageWhichAreShowingFailureOnFileUploadReportOrNot() {
        end();
    }
    @Then("I verify that when we click on the Refresh button that time whole page should be refreshed or not")
    public void i_verify_that_when_we_click_on_the_refresh_button_that_time_whole_page_should_be_refreshed_or_not() throws InterruptedException {
        int beforerefreshcount=driver.findElements(By.xpath("//tr[@class='mat-row ng-star-inserted']")).size();
        qr.getRefeshButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        int afrerrefreshcount=driver.findElements(By.xpath("//tr[@class='mat-row ng-star-inserted']")).size();
        if (afrerrefreshcount>=beforerefreshcount)
        {
            System.out.println("whole page refresh successfully...");
        }
        else {
            throw new InterruptedException("Whole page is not refresh successfully please check...");
        }
    }
    @And("I close the verify that when we click on the Refresh button that time whole page should be refreshed or not scenario")
    public void i_close_the_verify_that_when_we_click_on_the_refresh_button_that_time_whole_page_should_be_refreshed_or_not_scenario() {
        end();
    }
    @Then("I verify the matched details should be displayed")
    public void i_verify_the_matched_details_should_be_displayed() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
       js=(JavascriptExecutor)driver;
       js.executeScript("window.scrollBy(0,500)");
       Thread.sleep(1000);
        String data=json.jsonActualReadData("UploadByInput");
        qr.getUploadByInput().sendKeys(data);
        Thread.sleep(1000);
        qr.getUploadByInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        String getdata=driver.findElement(By.xpath("//td[@class='records mat-cell cdk-column-createdBy mat-column-createdBy ng-star-inserted']")).getText();
        if (getdata.equals(data))
        {
            System.out.println("matched details is displayed successfully...");
        }
        else {
            throw new InterruptedException(" matched detail is not displayed please check...");
        }
    }
    @And("I close the verify the matched details should be displayed scenario")
    public void i_close_the_verify_the_matched_details_should_be_displayed_scenario() {
        end();
    }
    @When("I click on the API tigger Option")
    public void i_click_on_the_api_tigger_option() throws InterruptedException {
        qr.getAPITiggerOption().click();
        Thread.sleep(2000);
    }
    @Then("I verify that when we click on the API Trigger sub menu that time API Trigger reapective page is open or not")
    public void i_verify_that_when_we_click_on_the_api_trigger_sub_menu_that_time_api_trigger_reapective_page_is_open_or_not() throws InterruptedException {
        String APITiggerText="API Trigger\nAdd API trigger at finequs.";
        String getAPITiggerPage=driver.findElement(By.xpath("//div[text()=' API Trigger ']")).getText();
        if (getAPITiggerPage.equals(APITiggerText))
        {
            System.out.println("API Trigger reapective page is open successfully");
        }
        else
        {
            throw new InterruptedException("API Trigger reapective page is not open please check...");
        }
    }
    @And("I close the verify that when we click on the API Trigger sub menu that time API Trigger reapective page is open")
    public void i_close_the_verify_that_when_we_click_on_the_api_trigger_sub_menu_that_time_api_trigger_reapective_page_is_open() {
        end();
    }
    @Then("I verify that on the API trigger page,Bulk upload redio button,Application id,Select Partner field should be displayed or not")
    public void i_verify_that_on_the_api_trigger_page_bulk_upload_redio_button_application_id_select_partner_field_should_be_displayed_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@value='yes']")));
        list.add(driver.findElement(By.xpath("//input[@value='no']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='ApplicationId']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='SignalId']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("All field is displayed successfully...");
            }
            else {
                throw new InterruptedException("Some Field are not display please check...");
            }
            i++;
        }
    }
    @And("I close verify that on the API trigger page,Bulk upload redio button,Application id,Select Partner field should be displayed or not scenario")
    public void i_close_verify_that_on_the_api_trigger_page_bulk_upload_redio_button_application_id_select_partner_field_should_be_displayed_or_not_scenario() {
        end();
    }
    @When("I select the merchant partner")
    public void i_select_the_merchant_partner() throws InterruptedException {
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='SignalId']")));
        select.selectByVisibleText("FlexiLoan");
        Thread.sleep(1000);
    }
    @Then("I verify that when we click on the submit button with keep blank Application Id & select value for select partner that time alert should be displayed this field is required \\(invalid)")
    public void i_verify_that_when_we_click_on_the_submit_button_with_keep_blank_application_id_select_value_for_select_partner_that_time_alert_should_be_displayed_this_field_is_required_invalid() throws InterruptedException {
        qr.getSumbitMicro().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        String altmsg="Please select values for all the fields";
        String getaltermsg=qr.getCopyAlter().getText();
        if (getaltermsg.equals(altmsg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("accept the failure alter");
        }
        else {
            throw new InterruptedException("Incorrect alter come please check...");
        }
        String fieldalter="This field is required";
        String getFieldalter=qr.getSelectPartner().getText();
        if (getFieldalter.equals(fieldalter))
        {
            System.out.println("alert is displayed successfully...");
        }
        else {
            throw new InterruptedException("alert is not displayed please check...");
        }
    }

    @And("I close the verify that when we click on the submit button with keep blank Application Id & select value for select partner that time alert should be displayed this field is required \\(invalid) Scenario")
    public void i_close_the_verify_that_when_we_click_on_the_submit_button_with_keep_blank_application_id_select_value_for_select_partner_that_time_alert_should_be_displayed_this_field_is_required_invalid_scenario() {
        end();
    }

    @When("I select yes radio button for the Bulk upload option")
    public void i_select_yes_radio_button_for_the_bulk_upload_option() throws InterruptedException {
        qr.getYesRadioButton().click();
        Thread.sleep(1000);
    }
    @Then("I verify the select Excel file page should be displayed or not")
    public void i_verify_the_select_excel_file_page_should_be_displayed_or_not() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//p[text()='Select Excel File']")));
        list.add(driver.findElement(By.xpath("//input[@type='file']")));
        list.add(driver.findElement(By.xpath("//i[@class='fa fa-download fa-sm']")));
        list.add(driver.findElement(By.xpath("//button[text()=' Upload Data ']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("select Excel file is displayed successfully...");
            }
            else {
                throw new InterruptedException("select Excel file is not displayed please check...");
            }
            i++;
        }
    }
    @And("I close the verify the select Excel file page should be displayed or not scenario")
    public void i_close_the_verify_the_select_excel_file_page_should_be_displayed_or_not_scenario() {
        end();
    }
    @When("I upload the cashE file")
    public void i_upload_the_cash_e_file() throws InterruptedException, IOException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/cashE.exe");
        Thread.sleep(5000);
        qr.getUploadFileButton().click();
        Thread.sleep(3000);
    }
    @Then("I verify the new added record should be display in the file Upload report with success value or not")
    public void i_verify_the_new_added_record_should_be_display_in_the_file_upload_report_with_success_value_or_not() throws InterruptedException, IOException {
        String d=driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data= String.valueOf(Integer.parseInt(d.replaceAll("\\D","")));
        int beforecount= Integer.parseInt(data.substring(2));
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/cashE.exe");
        Thread.sleep(5000);
        qr.getUploadFileButton().click();
        Thread.sleep(3000);
        qr.getClosealter().click();
        Thread.sleep(2000);
        qr.getRefeshButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        String d1=driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data1= String.valueOf(Integer.parseInt(d1.replaceAll("\\D","")));
        int afterecount= Integer.parseInt(data1.substring(2));
        WebElement addedrecord=driver.findElement(By.xpath("(//tr[@class='mat-row ng-star-inserted'])[1]"));
       if (afterecount>beforecount&&addedrecord.isDisplayed())
        {
            System.out.println("Record added successfully...");
        }
        else {
            throw new InterruptedException("Record is not added please check...");
        }
    }
    @And("I close the verify the new added record should be display in the file Upload report with success value or not")
    public void i_close_the_verify_the_new_added_record_should_be_display_in_the_file_upload_report_with_success_value_or_not() {
        end();
    }

    @Then("I verify that when we upload file for CashE, KreditBee,Prefr option through Choose file button with valid date that time added record should be display in the file Upload report with success value or scenario")
    public void i_verify_that_when_we_upload_file_for_cash_e_kredit_bee_prefr_option_through_choose_file_button_with_valid_date_that_time_added_record_should_be_display_in_the_file_upload_report_with_success_value_or_scenario() throws InterruptedException {
        String msg="Micro Loan file uploaded successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("alert is displayed Micro loan file uploaded successfully");
        }
        else {
            throw new InterruptedException("alert is not displayed Micro loan file uploaded please check...");
        }
    }
    @And("I close verify that when we upload file for CashE, KreditBee,Prefr option through Choose file button with valid date that time added record should be display in the file Upload report with success value")
    public void i_close_verify_that_when_we_upload_file_for_cash_e_kredit_bee_prefr_option_through_choose_file_button_with_valid_date_that_time_added_record_should_be_display_in_the_file_upload_report_with_success_value() {
        end();
    }
    @When("I upload the Prefr file")
    public void i_upload_the_prefr_file() throws InterruptedException, IOException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/cashE.exe");
        Thread.sleep(5000);
        qr.getUploadFileButton().click();
        Thread.sleep(3000);
    }
    @Then("I verify the new added record should be display in the file Upload report with success value or nor not")
    public void i_verify_the_new_added_record_should_be_display_in_the_file_upload_report_with_success_value_or_nor_not() {

    }
    @And("I close the verify the new added record should be display in the file Upload report with success value or nor not scenario")
    public void i_close_the_verify_the_new_added_record_should_be_display_in_the_file_upload_report_with_success_value_or_nor_not_scenario() {
        end();
    }
    @When("I upload the KreditBee File")
    public void i_upload_the_kredit_bee_file() throws InterruptedException, IOException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/KreditBee.exe");
        Thread.sleep(5000);
        qr.getUploadFileButton().click();
        Thread.sleep(3000);
    }

    @Then("I verify the new added record should be display in the file Upload report with success value for the KeditBee not")
    public void iVerifyTheNewAddedRecordShouldBeDisplayInTheFileUploadReportWithSuccessValueForTheKeditBeeNot() throws InterruptedException, IOException {
        String d=driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data= String.valueOf(Integer.parseInt(d.replaceAll("\\D","")));
        int beforecount= Integer.parseInt(data.substring(2));
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/KreditBee.exe");
        Thread.sleep(5000);
        qr.getUploadFileButton().click();
        Thread.sleep(3000);
        qr.getClosealter().click();
        Thread.sleep(2000);
        qr.getRefeshButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        String d1=driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data1= String.valueOf(Integer.parseInt(d1.replaceAll("\\D","")));
        int afterecount= Integer.parseInt(data1.substring(2));
        WebElement addedrecord=driver.findElement(By.xpath("(//tr[@class='mat-row ng-star-inserted'])[1]"));
        if (afterecount>beforecount&&addedrecord.isDisplayed())
        {
            System.out.println("Record added successfully...");
        }
        else {
            throw new InterruptedException("Record is not added please check...");
        }
    }
    @And("I close the verify the new added record should be display in the file Upload report with success for the KeditBee value or not")
    public void iCloseTheVerifyTheNewAddedRecordShouldBeDisplayInTheFileUploadReportWithSuccessForTheKeditBeeValueOrNot() {
        end();
    }

    @Then("I verify that when we upload file for KreditBee option through Choose file button with valid date that time added record should be display in the file Upload report with success value or scenario")
    public void iVerifyThatWhenWeUploadFileForKreditBeeOptionThroughChooseFileButtonWithValidDateThatTimeAddedRecordShouldBeDisplayInTheFileUploadReportWithSuccessValueOrScenario() throws InterruptedException {
        String msg="Micro Loan file uploaded successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("alert is displayed Micro loan file uploaded successfully");
        }
        else {
            throw new InterruptedException("alert is not displayed Micro loan file uploaded please check...");
        }
    }
    @And("I close the verify that when we upload file for KreditBee option through Choose file button with valid date that time added record should be display in the file Upload report with success value or scenario")
    public void iCloseTheVerifyThatWhenWeUploadFileForKreditBeeOptionThroughChooseFileButtonWithValidDateThatTimeAddedRecordShouldBeDisplayInTheFileUploadReportWithSuccessValueOrScenario() {
        end();
    }
    @When("I Upload the Bulk Upload file")
    public void i_upload_the_bulk_upload_file() throws InterruptedException, IOException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getChooseFile()).click().build().perform();
        Thread.sleep(3000);
        Runtime.getRuntime().exec("AutoITFile/BulkUploadAPIData.exe");
        Thread.sleep(5000);
        qr.getLoginSubmit().click();
        Thread.sleep(3000);
        /*qr.getClosealter().click();
        Thread.sleep(1000);*/
    }
    @Then("I verify that user is able to select customer deatils Bulk excel file through Choose file button scenario")
    public void i_verify_that_user_is_able_to_select_customer_deatils_bulk_excel_file_through_choose_file_button_scenario() throws InterruptedException {
        String msg="Data uploaded successfully.";
        String getmsg=qr.getCopyAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("Bulk Data Uploaded Successfully...");
        }
        else {
            throw new InterruptedException("Bulk data not uploded please check....");
        }
    }
    @And("I close the verify that user is able to select customer deatils Bulk excel file through Choose file button scenario")
    public void i_close_the_verify_that_user_is_able_to_select_customer_deatils_bulk_excel_file_through_choose_file_button_scenario() {
        end();
    }
    @Then("I verify that when we upload valid excel file through choose file button that time uploaded records should be displayed in the Bulk upload report")
    public void i_verify_that_when_we_upload_valid_excel_file_through_choose_file_button_that_time_uploaded_records_should_be_displayed_in_the_bulk_upload_report() throws InterruptedException {
        SimpleDateFormat dateformat=new SimpleDateFormat("dd/MM/yyyy, hh:mm aa");
        String systemdate=dateformat.format(new Date()).toString();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
       WebElement row=driver.findElement(By.xpath("(//tr[@class='mat-row ng-star-inserted'])[1]"));
        String getDateFormat=qr.getDateTime().getText();
        if (getDateFormat.equals(systemdate)&& row.isDisplayed())
        {
            System.out.println("Bulk data Added successfully");
        }
        else {
            throw new InterruptedException("Bulk data not Added successfully please check...");
        }
    }
    @And("I close the verify that when we upload valid excel file through choose file button that time uploaded records should be displayed in the Bulk upload report")
    public void i_close_the_verify_that_when_we_upload_valid_excel_file_through_choose_file_button_that_time_uploaded_records_should_be_displayed_in_the_bulk_upload_report() {
      end();
    }
    @Then("I verify that on the Bulk upload reaport File date, Bulk upload count,Bank name,Action column should be displyed or not")
    public void i_verify_that_on_the_bulk_upload_reaport_file_date_bulk_upload_count_bank_name_action_column_should_be_displyed_or_not() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[text()='File Date']")));
        list.add(driver.findElement(By.xpath("//span[text()='Bulk Upload Count']")));
        list.add(driver.findElement(By.xpath("//span[text()='BankName']")));
        list.add(driver.findElement(By.xpath("//span[text()='Action']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("column is displyed");
            }
            else
            {
                throw new InterruptedException("bulk upload column is not displayed please check...");
            }
            i++;
        }
    }
    @And("I close the verify that on the Bulk upload reaport File date, Bulk upload count,Bank name,Action column should be displyed or not")
    public void i_close_the_verify_that_on_the_bulk_upload_reaport_file_date_bulk_upload_count_bank_name_action_column_should_be_displyed_or_not() {
        end();
    }
    @Then("I verify that search box should be displayed under File date,Bulk upload count,Bank name,Action for these field")
    public void i_verify_that_search_box_should_be_displayed_under_file_date_bulk_upload_count_bank_name_action_for_these_field() throws InterruptedException {
      js=(JavascriptExecutor)driver;
      js.executeScript("window.scrollBy(0,200)");
      Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@placeholder='File Date']")));
        list.add(driver.findElement(By.xpath("//input[@placeholder='Bulk Upload Count']")));
        list.add(driver.findElement(By.xpath("//input[@placeholder='BankName']")));
        list.add(driver.findElement(By.xpath("//input[@placeholder='Action']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("search box is displayed successfully");
            }
            else {
                throw new InterruptedException("search box is not displayed please check...");
            }
            i++;
        }
    }
    @And("I close the verify that search box should be displayed under File date,Bulk upload count,Bank name,Action for these field scenario")
    public void i_close_the_verify_that_search_box_should_be_displayed_under_file_date_bulk_upload_count_bank_name_action_for_these_field_scenario() {
        end();
    }
    @Then("I verify that when user enter DB exist details in the Search box & click on the enter button that time matched details should be displayed search report which are present Bulk Upload")
    public void i_verify_that_when_user_enter_db_exist_details_in_the_search_box_click_on_the_enter_button_that_time_matched_details_should_be_displayed_search_report_which_are_present_bulk_upload() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");

        String data=json.jsonActualReadData("BulkUploadCount");
        qr.getSearchBulkUploadCount().click();
        Thread.sleep(1000);
        qr.getSearchBulkUploadCount().sendKeys(data);
        Thread.sleep(1000);
        qr.getSearchBulkUploadCount().sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        String getdata=qr.getSameBulkCount().getText();
        if (getdata.equals(data))
        {
            System.out.println("matched details is displayed successfully...");
        }
        else {
            throw new InterruptedException("matched detail is not displayed please check...");
        }
    }
    @And("I close the verify that when user enter DB exist details in the Search box & click on the enter button that time matched details should be displayed search report which are present Bulk Upload scenario")
    public void i_close_the_verify_that_when_user_enter_db_exist_details_in_the_search_box_click_on_the_enter_button_that_time_matched_details_should_be_displayed_search_report_which_are_present_bulk_upload_scenario() {
        end();
    }
    @Then("I verify that,when we click on the Export button that time clicked Bulk Upload excelsheet should be download or not")
    public void i_verify_that_when_we_click_on_the_export_button_that_time_clicked_bulk_upload_excelsheet_should_be_download_or_not() throws InterruptedException {
        filelist=file.listFiles();
        for (File f:filelist)
        {
            f.delete();
        }
        if (file.exists()!=true)
        {
            file.mkdir();
        }
        qr.getExportbutton().click();
        Thread.sleep(1000);

        filelist=file.listFiles();
       // String fileName = (String) js.executeScript("return document.querySelector('#contentAreaDownloadsView .downloadMainArea .downloadContainer description:nth-of-type(1)').value");
        filelist=file.listFiles();
        for (File f:filelist)
        {
            String comparefilename="BulkUploadData.xls";
            String downloadedgetfilename=f.getName();
           if (downloadedgetfilename.contains(comparefilename))
            {
                System.out.println("File downloaded successfully...");
            }
            else {
                throw new InterruptedException("Unable to download file please check...");
            }
        }

    }
    @And("I close the verify that,when we click on the Export button that time clicked Bulk Upload excelsheet should be download")
    public void i_close_the_verify_that_when_we_click_on_the_export_button_that_time_clicked_bulk_upload_excelsheet_should_be_download() {
        end();
    }
    @When("I select no radio button for the Bulk upload option")
    public void i_select_no_radio_button_for_the_bulk_upload_option() throws InterruptedException {
        qr.getSelectNo().click();
        Thread.sleep(1000);
    }
    @Then("I verify that when user select No option in the Bulk Upload radio button that time Bulk Upload No respective page is open")
    public void i_verify_that_when_user_select_no_option_in_the_bulk_upload_radio_button_that_time_bulk_upload_no_respective_page_is_open() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='ApplicationId']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='SignalId']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Bulk Upload page is open successfully");
            }
            else {
                throw new InterruptedException("Bulk Upload page not is open please check...");
            }
            i++;
        }
    }
    @And("I close the verify that when user select No option in the Bulk Upload radio button that time Bulk Upload No respective page is open")
    public void i_close_the_verify_that_when_user_select_no_option_in_the_bulk_upload_radio_button_that_time_bulk_upload_no_respective_page_is_open() {
      end();
    }
    @When("I select the application Id in bulk upload")
    public void i_select_the_application_id_in_bulk_upload() throws InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("(//div[@class='form-group col-sm-4'])[1]"))).click().build().perform();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//select[@formcontrolname='ApplicationId']")).sendKeys(Keys.ARROW_DOWN);
        driver.findElement(By.xpath("//select[@formcontrolname='ApplicationId']")).sendKeys(Keys.ARROW_DOWN);
        driver.findElement(By.xpath("//select[@formcontrolname='ApplicationId']")).sendKeys(Keys.ENTER);
        Thread.sleep(1000);
       // driver.findElement(By.xpath("(//div[@class='form-group col-sm-4'])[1]")).sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//div[@class='col-md-6']")).click();
        Thread.sleep(1000);
    }

    @Then("I verify that when we click on the submit button with keepling Balnk Application Id & select partner field value that time alert should be displayed this field is required \\(invalid)")
    public void i_verify_that_when_we_click_on_the_submit_button_with_keepling_balnk_application_id_select_partner_field_value_that_time_alert_should_be_displayed_this_field_is_required_invalid() throws InterruptedException {
        qr.getSumbitMicro().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        String altmsg="Please select values for all the fields";
        String getaltermsg=qr.getCopyAlter().getText();
        if (getaltermsg.equals(altmsg))
        {
            qr.getClosealter().click();
            Thread.sleep(1000);
            System.out.println("accept the failure alter");
        }
        else {
            throw new InterruptedException("Incorrect alter come please check...");
        }
        String fieldalter="This field is required";
        String getFieldalter=qr.getSelectPartner().getText();
        if (getFieldalter.equals(fieldalter))
        {
            System.out.println("alert is displayed successfully...");
        }
        else {
            throw new InterruptedException("alert is not displayed please check...");
        }
    }
    @And("I close the verify that when we click on the submit button with keepling Balnk Application Id & select partner field value that time alert should be displayed this field is required \\(invalid) scenario")
    public void i_close_the_verify_that_when_we_click_on_the_submit_button_with_keepling_balnk_application_id_select_partner_field_value_that_time_alert_should_be_displayed_this_field_is_required_invalid_scenario() {
        end();
    }
    @Then("I verify that the keep blank Application Id & select partner field that time alter is display or not")
    public void i_verify_that_the_keep_blank_application_id_select_partner_field_that_time_alter_is_display_or_not() throws InterruptedException {
        qr.getSumbitMicro().click();
        String msg="Please select values for all the fields";
        String getmsg=qr.getCopyAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            System.out.println("Correct alter is accepted...");
        }
        else{
            throw new InterruptedException("Incorrect alter is display please check...");
        }
        String applicationIDmsg="This field is required";
        String getapplicatioIDMsg=qr.getSelectPartner().getText();
        if (getapplicatioIDMsg.equals(applicationIDmsg))
        {
            System.out.println("Correct Application ID alter is accepted...");
        }
        else{
            throw new InterruptedException("Incorrect Aplication ID alter is display please check...");
        }
        String partner="This field is required";
        String getpartnerMsg=qr.getSelectPartner2().getText();
        if (getpartnerMsg.equals(partner))
        {
            System.out.println("Correct select merchant alter is accepted...");
        }
        else{
            throw new InterruptedException("Incorrect Select merchant alter is display please check...");
        }
    }
    @And("I close the I verify that the keep blank Application Id & select partner field that time alter is display or not scenario")
    public void i_close_the_i_verify_that_the_keep_blank_application_id_select_partner_field_that_time_alter_is_display_or_not_scenario() {
        end();
    }
    @When("I click on the submit button in API trigger")
    public void i_click_on_the_submit_button_in_api_trigger() throws InterruptedException {
        qr.getSumbitMicro().click();
        Thread.sleep(1000);
    }
    @Then("I verify the confirmation alert should be displayed or not")
    public void i_verify_the_confirmation_alert_should_be_displayed_or_not() throws InterruptedException {
       String msg="Are you sure you want to publish data.";
       String getmsg=qr.getCopyAlter().getText();
       if (getmsg.equals(msg))
       {
           qr.getDatacollectionok().click();
           System.out.println("confirmation alert is displayed successfully..");
       }
       else
       {
           throw new InterruptedException("confirmation alert is not displayed please check...");
       }
    }
    @And("I close the verify the confirmation alert should be displayed or not scenario")
    public void i_close_the_verify_the_confirmation_alert_should_be_displayed_or_not_scenario() {
        end();
    }


}

