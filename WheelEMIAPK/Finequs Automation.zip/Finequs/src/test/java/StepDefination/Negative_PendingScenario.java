package StepDefination;

import Helper.BaseClass;
import Helper.PropertiesReader;
import Helper.QRCodeHelper;
import Utilities.JsonDataReadAndWrite;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Negative_PendingScenario extends BaseClass {
    PropertiesReader pro=new PropertiesReader();
    WebDriverWait wait;
    JsonDataReadAndWrite json=new JsonDataReadAndWrite();
    JavascriptExecutor js;
    String parentwindow=null;
    String old_AppId;
    @Given("I am on login webpage")
    public void i_am_on_login_webpage() throws IOException, ParseException, InterruptedException {
        set();
        Thread.sleep(1000);
        String url=pro.propertyReader("url");
        driver.get(url);
        ngwebdriver.waitForAngularRequestsToFinish();
        wait=new WebDriverWait(driver,30);
        login();
    }
    @When("I navigate to the Home page")
    public void i_navigate_to_the_home_page() {
        qr=new QRCodeHelper();
        qr.getNavigationBar().click();
        ngwebdriver.waitForAngularRequestsToFinish();
    }
    @When("I Click on the loan option dropdoown")
    public void i_click_on_the_loan_option_dropdoown() throws InterruptedException {
        qr.getLoans().click();
        Thread.sleep(1000);
    }
    @When("I select the Data Collection Queue option")
    public void i_select_the_data_collection_queue_option() throws InterruptedException {
        qr.getQuicDataCollectionQueue().click();
        /*ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);*/
        Thread.sleep(25000);
    }
    @Then("I Validate Data collection Q in Loans menu")
    public void i_validate_data_collection_q_in_loans_menu() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//button[text()=' Previous ']")));
        list.add(driver.findElement(By.xpath("//button[text()=' Next ']")));
        list.add(qr.gettoggleButtonDCQ());
        list.add(qr.getappIdOnBankSQ());
        list.add(qr.getSearchClick());
        qr.getSearchClick().click();
        Thread.sleep(2000);
        List<WebElement>searchDropDownOption= driver.findElements(By.xpath("//ul[@class='ngx-select__choices dropdown-menu ng-star-inserted show']//li"));
        if (searchDropDownOption.size()>0)
        {
            System.out.println("search dropdown option is showing");
        }else {
            throw new IllegalArgumentException("search dropdown option are not showing");
        }
        qr.getSearchId().sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        list.add(qr.getMicroId());
        list.add(qr.getmerchantDetails());
        list.add(qr.getDataCollectionSalutation());
        list.add(qr.getfirstNameDCQ());
        list.add(qr.getlastNameDCQ());
        list.add(qr.getloanAppliedForDCQ());
        list.add(qr.getloan2AppliedForDCQ());
        list.add(qr.getlastModifiedDateDCQ());
        list.add(qr.getmobileDCQ());
        list.add(qr.getalternateMobileDCQ());
        list.add(qr.getloanTenureDCQ());
        list.add(qr.getloanPurposeDCQ());
        list.add(qr.getApplicant_DetailsHeaderDCQ());
        list.add(qr.getpanCardDCQ());
        list.add(qr.getaddressLine2DCQ());
        list.add(qr.getCurrentResidenceAddressDCQ());
        list.add(qr.getaddressLine1DCQ());
        list.add(qr.getaddressLine2DCQ());
        list.add(qr.getaddressLine3DCQ());
        list.add(qr.getlandmarkDCQ());
        list.add(qr.getpinCodeDCQ());
        list.add(qr.getresidenceTypeDCQ());
        list.add(qr.getresidentialStateDCQ());
        list.add(qr.getresidentialCityDCQ());
        list.add(qr.gettotalResidenceYearsDCQ());
        list.add(qr.getPermanentResidenceAddressDCQ());
        list.add(qr.getcurrentPermanentSameDCQ());
        list.add(qr.getofficeAddressLine1DCQ());
        list.add(qr.getofficeAddressLine2DCQ());
        list.add(qr.getofficeLandmarkDCQ());
        list.add(qr.getofficeStateIdDCQ());
        list.add(qr.getofficeCityIdDCQ());
        list.add(qr.getreferenceName1DCQ());
        list.add(qr.getmobileOfReference1DCQ());
        list.add(qr.getreferenceAddress1DCQ());
        list.add(qr.getrelationWith1BorroweDCQ());
        list.add(qr.getreferenceName2DCQ());
        list.add(qr.getmobileOfReference2DCQ());
        list.add(qr.getreferenceAddress2DCQ());
        list.add(qr.getrelationWith2BorroweDCQ());
        list.add(qr.getnomineeName1DCQ());
        list.add(qr.getnomineeName1DCQ());
        list.add(qr.getmobileNoofNominee1DCQ());
        list.add(qr.getnomineeName2DCQ());
        list.add(qr.getnomineeAddress2DCQ());
        list.add(qr.getnomineeAddress2DCQ());
        list.add(qr.getrelationWithBorrowe1DCQ());
        list.add(qr.getrelationWithBorrowe2DCQ());
        list.add(qr.getoldRemarkDCQ());
        list.add(qr.getApplicationIdColumnDCQ());
        list.add(qr.getDiariseDatesColumnDCQ());
        list.add(qr.getDiariseReasonsColumnDCQ());
        list.add(qr.getCommentColumnDCQ());
        list.add(qr.getCreatedByColumnDCQ());
        list.add(qr.getcallButtonDCQ());
        list.add(qr.getDiariseButtonDCQ());
        list.add(qr.getCustomerNotInterestedButtonDCQ());
        list.add(qr.getDeclineButtonDCQ());
        list.add(qr.getBankSelectionButtonDCQ());
        list.add(qr.getSaveButtonDCQ());
        list.add(qr.getSubmitButtonDCQ());
        int i=0;
        int j=1;
        int n=6;
        while (i<list.size()){
            if (!list.get(i).isDisplayed())
            {
                throw new IllegalArgumentException(list.get(i)+" the element is not showing");
            }
            if (i==n*j&&j<=12){
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,400)");
                Thread.sleep(3000);
                j++;
            }
            i++;
        }
    }

    @Then("I Validate Refresh Queue in Toggle button in Data collection Q in Loans menu")
    public void i_validate_refresh_queue_in_toggle_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,15000)");
        Thread.sleep(1000);
        String data = driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data1 = data.replaceAll("\\D", "");
        int count= Integer.parseInt(data1);
       // int count = Integer.parseInt(data1.substring(2));
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-15000)");
        Thread.sleep(15000);
        qr.getToggleButton().click();
        Thread.sleep(3000);
        qr.getToggleRefreshButton().click();
        Thread.sleep(1000);
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,15000)");
        Thread.sleep(15000);
        String data2 = driver.findElement(By.xpath("//div[@class='mat-paginator-range-label']")).getText();
        String data22 = data2.replaceAll("\\D", "");
        int count2= Integer.parseInt(data22);
      //  int count2 = Integer.parseInt(data22.substring(2));
        if (count2 >= count) {
            System.out.println("page is Refresh Queue in Toggle button in Data collection Q in Loans menu successfully....");
        }
       /* else if (count2==0&&count==0)
        {
            System.out.println("page is Refresh Queue in Toggle button in Data collection Q in Loans menu successfully....");
        }*/
        else {
            throw new InterruptedException("Page is Refresh Queue in Toggle button in Data collection Q in Loans menu please check....");
        }
    }
    @And("I close the Validate Refresh Queue in Toggle button in Data collection Q in Loans menu scenario")
    public void i_close_the_validate_refresh_queue_in_toggle_button_in_data_collection_q_in_loans_menu_scenario() {
        end();
    }
    @Then("I verify the the frozen fields")
    public void i_verify_the_the_frozen_fields() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@name='firstName']")));
        list.add(driver.findElement(By.xpath("//input[@name='lastName']")));
        list.add(driver.findElement(By.xpath("//select[@name='loanAppliedFor']")));
        list.add(driver.findElement(By.xpath("//input[@name='lastModifiedDate']")));
        list.add(driver.findElement(By.xpath("//input[@name='mobile']")));
        WebElement salutation=driver.findElement(By.xpath("//select[@formcontrolname='salutation']"));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed()&&!list.get(i).isEnabled()&&salutation.isDisplayed()&&salutation.isEnabled())
            {
                System.out.println("Fields are displayed successfully...");
            }
            else {
                throw new InterruptedException("Fields are not displayed please check....");
            }
            i++;
        }
        /*int j=0;
        while (j<list1.size())
        {
            if (list1.get(i).isDisplayed()&&list1.get(i).isEnabled())
            {
                System.out.println("Fields are Editiable and is displayed successfully....");
            }
            else {
                throw new InterruptedException("Fields are not Editiable and is displayed please check....");
            }
            j++;*/
    }
    @And("I close the verify the the frozen fields scenarios")
    public void i_close_the_verify_the_the_frozen_fields_scenarios() {
        end();
    }
    @Then("I Validate Applicant details section queue in Toggle button in Data collection Q in Loans menu")
    public void i_validate_applicant_details_section_queue_in_toggle_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        String pancard=driver.findElement(By.xpath("//input[@name='panCard']")).getAttribute("value");
        WebElement pancardfield=driver.findElement(By.xpath("//input[@name='panCard']"));
        if (!pancard.isEmpty()&&pancardfield.isDisplayed()&&!pancardfield.isEnabled())
        {
            System.out.println("Pan card field is working");
        }
        else {
            throw new InterruptedException("PAN card field is not working please check...");
        }
        WebElement gender=driver.findElement(By.xpath("//select[@formcontrolname='gender']"));
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='gender']")));
        String selectoption= String.valueOf(select.getFirstSelectedOption());
        if (!selectoption.isEmpty()&&gender.isEnabled()&&gender.isDisplayed())
        {
            System.out.println("Gender field is working fine...");
        }
        else {
            throw new InterruptedException("Gender field is not working please check...");
        }
        WebElement marital_status=driver.findElement(By.xpath("//select[@formcontrolname='maritalStatus']"));
        Select s=new Select(driver.findElement(By.xpath("//select[@formcontrolname='maritalStatus']")));
        String maritalstatus= String.valueOf(s.getFirstSelectedOption());
        if (!maritalstatus.isEmpty()&&marital_status.isDisplayed()&&marital_status.isEnabled())
        {
            System.out.println("Marital status field is working fine...");
        }
        else {
            throw new InterruptedException("Marital status field is not working please check...");
        }
        WebElement no_of_depedants=driver.findElement(By.xpath("//select[@formcontrolname='noOfDependents']"));
        if (no_of_depedants.isDisplayed()&&no_of_depedants.isEnabled())
        {
            System.out.println("no of dependants field is working fine...");
        }
        else {
            throw new InterruptedException("No of depedants field is not working please check...");
        }
        WebElement fathername=driver.findElement(By.xpath("//input[@name='fatherName']"));
        if (fathername.isDisplayed()&&fathername.isEnabled())
        {
            System.out.println("Father name field is working fine...");
        }
        else {
            throw new InterruptedException("Father name field is not working please check...");
        }
        WebElement mothername=driver.findElement(By.xpath("//input[@name='motherName']"));

        if (mothername.isDisplayed()&&mothername.isEnabled())
        {
            System.out.println("Mother name field is working fine....");
        }
        else {
            throw new InterruptedException("Mother name field is not working fine please check...");
        }
    }
    @And("I close the Validate Applicant details section queue in Toggle button in Data collection Q in Loans menu")
    public void i_close_the_validate_applicant_details_section_queue_in_toggle_button_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("I Verify that,Loan details section in the Data collection Queue.")
    public void i_verify_that_loan_details_section_in_the_data_collection_queue() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,150)");
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='loanTenure']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='loanPurpose']")));
        int i=0;
        while (i<list.size())
        {
            list.get(i).click();
            Thread.sleep(1000);
           /* Select ss=new Select(driver.findElement(By.xpath("//select[@formcontrolname='loanTenure']")));
            WebElement option= (WebElement) ss.getOptions();
            Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='loanPurpose']")));
            WebElement option1= (WebElement) select.getOptions();*/
            if (list.get(i).isDisplayed())
            {
                System.out.println("Drop-down options is Able to select Manually successfully...");
            }
            else {
                throw new InterruptedException("Drop-down options is not Able to select Manually please check...");
            }
            i++;
        }
    }
    @And("I close the Verify that,Loan details section in the Data collection Queue scenario")
    public void i_close_the_verify_that_loan_details_section_in_the_data_collection_queue_scenario() {
        end();
    }
    @Then("I Validate Current Residence address section in Toggle button in Data collection Q in Loans menu")
    public void i_validate_current_residence_address_section_in_toggle_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine3']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='landmark']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='pinCode']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='residenceType']")));
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[2]")));
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[3]")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='totalResidenceYears']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("All fields are display");
            }
            else {
                throw new InterruptedException("Some Fields are not display please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Current Residence address section in Toggle button in Data collection Q in Loans menu scenario")
    public void i_close_the_validate_current_residence_address_section_in_toggle_button_in_data_collection_q_in_loans_menu_scenario() {
        end();
    }
    @And("I Close the Validate Data collection Q in Loans menu Scenario")
    public void i_close_the_validate_data_collection_q_in_loans_menu_scenario() {
        end();
    }
    @Then("I verify the Verify that,Latest submitted application should be display first and Previous button should be disable")
    public void i_verify_the_verify_that_latest_submitted_application_should_be_display_first_and_previous_button_should_be_disable() throws InterruptedException {
       WebElement button=driver.findElement(By.xpath("//button[@class='ml-1 ml-lg-0 btn-shadow btn-wide btn-pill btn-hover-shine btn btn-outline-secondary']"));
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")));
        list.add(driver.findElement(By.xpath("(//p[@class='mb-0'])[2]")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&!button.isEnabled())
            {
                System.out.println("Latest submitted application is display first and Previous button is disable...");
            }
            else
            {
                throw new InterruptedException("Latest submitted application is not display first and Previous button is not disable please check...");
            }
            i++;
        }
    }
    @And("I close the Verify that,Latest submitted application should be display first and Previous button should be disable scenario")
    public void i_close_the_verify_that_latest_submitted_application_should_be_display_first_and_previous_button_should_be_disable_scenario() {
        end();
    }
    @Then("I verify the System should navigate to next and previous application and should display that application details")
    public void i_verify_the_system_should_navigate_to_next_and_previous_application_and_should_display_that_application_details() throws InterruptedException {
        String applicationID=driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")).getText();
        qr.getNextButton().click();
        Thread.sleep(30000);
        String nextapplicationID=driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")).getText();
        if (!nextapplicationID.equals(applicationID))
        {
            System.out.println("System is navigate to next application successfully...");
        }
        else {
            throw new InterruptedException("System is not able to navigate to next application please check...");
        }
        String nextapplicationID1=driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")).getText();
        qr.getPreviousButton().click();
        Thread.sleep(30000);
        String applicationID1=driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")).getText();
        if (!applicationID1.equals(nextapplicationID1))
        {
            System.out.println("System is navigate to previous application successfully");
        }
        else {
            throw new InterruptedException("System is not able to navigate to previous application please check...");
        }
    }
    @And("I close verify the System should navigate to next and previous application and should display that application details")
    public void i_close_verify_the_system_should_navigate_to_next_and_previous_application_and_should_display_that_application_details() {
        end();
    }
    @Then("I Verify that Previous Button should be Disable.")
    public void i_verify_that_previous_button_should_be_disable() throws InterruptedException {
        WebElement button=driver.findElement(By.xpath("//button[@class='ml-1 ml-lg-0 btn-shadow btn-wide btn-pill btn-hover-shine btn btn-outline-secondary']"));
        if(!button.isEnabled())
        {
            System.out.println("Previous Button is Disable..");
        }
        else {
            throw new InterruptedException("Previous Button is Disable please check....");
        }
    }
    @And("I close the Verify that Previous Button should be Disable.")
    public void i_close_the_verify_that_previous_button_should_be_disable() {
        end();
    }
    @Then("I verify the System should display the dropdown values of application ids and allow user to select the application id from dropdown and selected application details should display")
    public void i_verify_the_system_should_display_the_dropdown_values_of_application_ids_and_allow_user_to_select_the_application_id_from_dropdown_and_selected_application_details_should_display() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        qr.getDataCollectionSearch().click();
        Thread.sleep(2000);
       if (qr.getSearchDropDown().isDisplayed())
       {
           System.out.println("The System is display the dropdown values of application ids");
       }
        else
       {
           throw new InterruptedException("The System is not display the dropdown values of application ids please check...");
       }
        String appid=json.jsonActualReadData("ApplicationID");
        qr.getSearchId().sendKeys(appid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        Thread.sleep(12000);
        String getApplicationid=driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")).getText();
        Thread.sleep(1000);
        if (getApplicationid.equals(appid))
        {
            System.out.println("selected application details is display successfully....");
        }
        else
        {
            throw new InterruptedException("selected application details is not display please check...");
        }
    }
    @And("I close the System should display the dropdown values of application ids and allow user to select the application id from dropdown and selected application details should display scenario")
    public void i_close_the_system_should_display_the_dropdown_values_of_application_ids_and_allow_user_to_select_the_application_id_from_dropdown_and_selected_application_details_should_display_scenario() {
      end();
    }
    @Then("I verify the In Search Application id drop down application id Only showing Mecharnt which is mapped under him.")
    public void i_verify_the_in_search_application_id_drop_down_application_id_only_showing_mecharnt_which_is_mapped_under_him() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        qr.getDataCollectionSearch().click();
        Thread.sleep(1000);
        String appid=json.jsonActualReadData("ApplicationID");
        qr.getSearchId().sendKeys(appid);
        Thread.sleep(1000);
        WebElement option=driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[1]"));
        if (option.isDisplayed())
        {
            System.out.println("showing Mecharnt which is mapped under him is sucessfully...");
        }
        else {
            throw new InterruptedException("Mecharnt is not showing which is mapped under him please check...");
        }
    }
    @And("I close the In Search Application id drop down, application id Only showing Mecharnt which is mapped under him.")
    public void i_close_the_in_search_application_id_drop_down_application_id_only_showing_mecharnt_which_is_mapped_under_him() {
        end();
    }
    @Then("I Validate Subheader in Data collection Q in Loans menu")
    public void i_validate_subheader_in_data_collection_q_in_loans_menu() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")));
        list.add(driver.findElement(By.xpath("(//p[@class='mb-0'])[2]")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Subheader in Data collection Q in Loans menu display successfully...");
            }
            else
            {
                throw new InterruptedException("Subheader in Data collection Q in Loans menu is not disable please check...");
            }
            i++;
        }

    }
    @And("I close the Validate Subheader in Data collection Q in Loans menu")
    public void i_close_the_validate_subheader_in_data_collection_q_in_loans_menu() {
    end();
    }
    @Then("I Verify that Merchant Details sub header should be Non editable Fields and it should be Auto populated selection of new Application ID.")
    public void i_verify_that_merchant_details_sub_header_should_be_non_editable_fields_and_it_should_be_auto_populated_selection_of_new_application_id() throws InterruptedException {
        List<WebElement> list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-data-collection-q/div[2]/div[3]/div/div[1]/div/h4")));
        list.add(driver.findElement(By.xpath("(//p[@class='mb-0'])[2]")));
        list.add(driver.findElement(By.xpath("//label[@class='pr-2 mb-md-0']")));
        list.add(driver.findElement(By.xpath("//div[@class='d-flex flex-wrap align-items-center']")));
        int i=0;
        while (i<list.size())
        {
            if (!list.get(i).isEnabled())
            {
                throw new InterruptedException("Merchant Details sub header is not Non editable Fields and it is not Auto populated selection of new Application ID.");
            }
            else {
                System.out.println("Merchant Details sub header is Non editable Fields and it is Auto populated selection of new Application ID.");
            }
            i++;
        }
    }
    @And("I close Verify that Merchant Details sub header should be Non editable Fields and it should be Auto populated selection of new Application ID.")
    public void i_close_verify_that_merchant_details_sub_header_should_be_non_editable_fields_and_it_should_be_auto_populated_selection_of_new_application_id() {
        end();
    }
    @When("I click on the toggle button in bank selection")
    public void i_click_on_the_toggle_button_in_bank_selection() throws InterruptedException {
        qr.getToggleButton().click();
        Thread.sleep(3000);
    }
    @Then("I verify the toggle button in Data collection Q in Loans menu")
    public void i_verify_the_toggle_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Queue']")));
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Application']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Toggle button Working fine...");
            }
            else {
                throw new InterruptedException("Toggle button is not working fine please check...");
            }
            i++;
        }
    }
    @And("I close the verify the toggle button in Data collection Q in Loans menu")
    public void i_close_the_verify_the_toggle_button_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("I click on the refresh queue button")
    public void i_click_on_the_refresh_queue_button() throws InterruptedException {
        qr.getToggleRefreshButton().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
    }
    @Then("I Verify that after click on Page Refresh or Application Refresh Session should not be logout")
    public void i_verify_that_after_click_on_page_refresh_or_application_refresh_session_should_not_be_logout() throws InterruptedException {
        WebElement dataCollectionQueuepage=driver.findElement(By.xpath("//div[@class='MerchantDetails ng-star-inserted']"));
        if (dataCollectionQueuepage.isDisplayed())
        {
            System.out.println("Application Refresh Session is not be logout....");
        }
        else {
            throw new InterruptedException("Application Refresh Session is logout please check.....");
        }
    }
    @And("I close the I Verify that after click on Page Refresh or Application Refresh Session should not be logout scenario")
    public void i_close_the_i_verify_that_after_click_on_page_refresh_or_application_refresh_session_should_not_be_logout_scenario() {
        end();
    }
    @Then("I Verify that Pincode field should be allow {int} digit only")
    public void i_verify_that_pincode_field_should_be_allow_digit_only(Integer int1) throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,4000)");
        qr.getCurrentPincode().clear();
        Thread.sleep(1000);
        String enterpincode="41102578";
        qr.getCurrentPincode().sendKeys(enterpincode);
        Thread.sleep(1000);
        int comparelengthd=qr.getCurrentPincode().getAttribute("value").length();
        if (comparelengthd==6)
        {
            System.out.println("Pincode contains only 6 digit");
        }
        else {
            throw new InterruptedException("Pincode field dont have any 6 digit validation please check....");
        }
    }
    @And("I close the Verify that Pincode field should be allow {int} digit only scenarios")
    public void i_close_the_verify_that_pincode_field_should_be_allow_digit_only_scenarios(Integer int1) {
        end();
    }
    @Then("I Verify that Permanent Residence Address Section fields in Data collection queue.")
    public void i_verify_that_permanent_residence_address_section_fields_in_data_collection_queue() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine3']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddLandmark']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddPinCode']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentResidenceType']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddState']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddCity']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("All field is displayed successfully....");
            }
            else {
                throw new InterruptedException("Not all field are displayed successfully please check...");
            }
              i++;
        }

    }
    @And("I close the Verify that Permanent Residence Address Section fields in Data collection queue scenario")
    public void i_close_the_verify_that_permanent_residence_address_section_fields_in_data_collection_queue_scenario() {
      end();
    }
    @Then("I Verify that If User Tick Same As current Residence Address then All Fields should be Copy from Current Residence Address and Paste in Permanent Residence Address.")
    public void i_verify_that_if_user_tick_same_as_current_residence_address_then_all_fields_should_be_copy_from_current_residence_address_and_paste_in_permanent_residence_address() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");
        List<String>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine1']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine2']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine3']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='landmark']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='pinCode']")).getText());
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='residenceType']")).getText());
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[2]")).getText());
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[3]")).getText());
        qr.getCurrentpermanentsame().click();
        Thread.sleep(1000);
        qr.getCurrentpermanentsame().click();
        Thread.sleep(1000);
        List<String>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine1']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine2']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine3']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddLandmark']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddPinCode']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentResidenceType']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddState']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddCity']")).getText());
        int i=0;
        while (i<list1.size())
        {
            if (list.get(i).equals(list1.get(i)))
            {
                System.out.println("Same As current Residence Address then All Fields is Copy from Current Residence Address and Paste in Permanent Residence Address successfully...");
            }
            else {
                throw new InterruptedException("Same As current Residence Address then All Fields is not Copy from Current Residence Address and Paste in Permanent Residence Address please check And the Field is:="+list.get(i));
            }
            i++;
        }

    }
    @And("I close the Verify that If User Tick Same As current Residence Address then All Fields should be Copy from Current Residence Address and Paste in Permanent Residence Address scenario")
    public void i_close_the_verify_that_if_user_tick_same_as_current_residence_address_then_all_fields_should_be_copy_from_current_residence_address_and_paste_in_permanent_residence_address_scenario() {
       end();
    }
    @Then("I Verify that If User Untick Same As current Residence Address then All Fields should be clear from Permanent Residence Address.")
    public void i_verify_that_if_user_untick_same_as_current_residence_address_then_all_fields_should_be_clear_from_permanent_residence_address() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        qr.getCurrentpermanentsame().click();
        Thread.sleep(1000);
        qr.getCurrentpermanentsame().click();
        Thread.sleep(1000);
        List<String>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine1']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine2']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddressLine3']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddLandmark']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='permanentAddPinCode']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentResidenceType']")).getAttribute("value"));
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddState']")).getAttribute("value"));
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='permanentAddCity']")).getAttribute("value"));

        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
        int i=0;
        while (i<list1.size())
        {
            if (list1.get(i).isEmpty())
            {
                System.out.println("All Fields is clear from Permanent Residence Address successfully...");
            }
            else {
                throw new InterruptedException("All Fields is not clear from Permanent Residence Address please check...");
            }
            i++;
        }
    }
    @And("I close the Verify that If User Untick Same As current Residence Address then All Fields should be clear from Permanent Residence Address scenario")
    public void i_close_the_verify_that_if_user_untick_same_as_current_residence_address_then_all_fields_should_be_clear_from_permanent_residence_address_scenario() {
       end();
    }
    @Then("I Validate Occupation details section in Toggle button in Data collection Q in Loans menu")
    public void i_validate_occupation_details_section_in_toggle_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,2000)");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//p[text()='Office Address']"));
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='occupation']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='orgName']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='orgTypeOrBusType']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='designation']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='noOfMonthsOrYrsInCurrentJob']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='yrsOfWorkExp']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='netMonthlyIncome1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officialEmailId']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='customerProfile']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Occupation details section in Toggle button in Data collection Q in Loans menu is dispaly successfully..");
            }
            else {
                throw new InterruptedException("Occupation details section in Toggle button in Data collection Q in Loans menu is not display please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Occupation details section in Toggle button in Data collection Q in Loans menu")
    public void i_close_the_validate_occupation_details_section_in_toggle_button_in_data_collection_q_in_loans_menu() {
        end();
    }
 /*   @Then("I Verify that No.of month\\/years in Current Job should be less than total years of work experience\\/Business.")
    public void i_verify_that_no_of_month_years_in_current_job_should_be_less_than_total_years_of_work_experience_business() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,600)");
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='noOfMonthsOrYrsInCurrentJob']")));
        select.selectByVisibleText("3 - 4 years");
        Thread.sleep(1000);
        String data="3 - 4 years";
        String getdata=data.replaceAll("\\D","");
        int comparedata= Integer.parseInt(getdata.substring(0));
        Thread.sleep(1000);
        Select select1=new Select(driver.findElement(By.xpath("//select[@formcontrolname='yrsOfWorkExp']")));
        select1.selectByValue("1 - 2 years");
        String seconddata="1 - 2 years";
        String getseconddata=seconddata.replaceAll("\\D","");
        int getsecondcomparedata= Integer.parseInt(getseconddata.substring(0));
        if (getsecondcomparedata<comparedata)
        {
            System.out.println("No.of month years in Current Job is less than total years of work experience Business");
        }
        else {
            throw new InterruptedException("No.of month years in Current Job is not less than total years of work experience Business please check...");
        }
        String msg="Total Years of work experience/Business is required";
        String getmsg=driver.findElement(By.xpath("//span[@class='text-danger ng-star-inserted']")).getText();
        if (getmsg.equals(msg))
        {
            System.out.println("No.of month years in Current Job is less than total years of work experience Business");
        }
        else
        {
            throw new InterruptedException("No.of month years in Current Job is not less than total years of work experience Business please check...");
        }

    }
    @And("I close the Verify that,No.of month \\/years in Current Job should be less than total years of work experience\\/Business scenario.")
    public void i_close_the_verify_that_no_of_month_years_in_current_job_should_be_less_than_total_years_of_work_experience_business_scenario() {
        end();
    }*/
    @Then("I Verify that No.of month years in Current Job should be less than total years of work experience Business.")
    public void i_verify_that_no_of_month_years_in_current_job_should_be_less_than_total_years_of_work_experience_business() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,600)");
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='noOfMonthsOrYrsInCurrentJob']")));
        select.selectByVisibleText("3 - 4 years");
        Thread.sleep(1000);
        String data="3 - 4 years";
        String getdata=data.replaceAll("\\D","");
        int comparedata= Integer.parseInt(getdata.substring(0));
        Thread.sleep(1000);
        Select select1=new Select(driver.findElement(By.xpath("//select[@formcontrolname='yrsOfWorkExp']")));
        select1.selectByVisibleText("1 - 2 years");
        String seconddata="1 - 2 years";
        String getseconddata=seconddata.replaceAll("\\D","");
        int getsecondcomparedata= Integer.parseInt(getseconddata.substring(0));
        if (getsecondcomparedata<comparedata)
        {
            System.out.println("No.of month years in Current Job is less than total years of work experience Business");
        }
        else {
            throw new InterruptedException("No.of month years in Current Job is not less than total years of work experience Business please check...");
        }
        qr.getTotalExpericanceLabel().click();
        Thread.sleep(1000);
        String msg="Total Years of work experience/Business is required";
        String getmsg=driver.findElement(By.xpath("//span[@class='text-danger ng-star-inserted']")).getText();
        if (getmsg.equals(msg))
        {
            System.out.println("No.of month years in Current Job is less than total years of work experience Business");
        }
        else
        {
            throw new InterruptedException("No.of month years in Current Job is not less than total years of work experience Business please check...");
        }
    }
    @And("I close the Verify that,No.of month years in Current Job should be less than total years of work experience Business scenario.")
    public void i_close_the_verify_that_no_of_month_years_in_current_job_should_be_less_than_total_years_of_work_experience_business_scenario() {
      end();
    }
    @Then("I Validate Office address section in Data collection Q in Loans menu")
    public void i_validate_office_address_section_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,700)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='resOfficeSame']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine3']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officeLandmark']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='officePinCode']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='officeStateId']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='officeCityId']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("All fields of office address section are show successfully...");
            }
            else {
                throw new InterruptedException("Some office address field are not display please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Office address section in Data collection Q in Loans menu")
    public void i_close_the_validate_office_address_section_in_data_collection_q_in_loans_menu() {
      end();
    }
    @Then("I Verify that, If User Tick Same As current Residence Address then All Fields should be Copy from Current Residence Address and Paste in Office Address.")
    public void i_verify_that_if_user_tick_same_as_current_residence_address_then_all_fields_should_be_copy_from_current_residence_address_and_paste_in_office_address() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        qr.getResOfficeSame().click();
        Thread.sleep(1000);
        /*qr.getResOfficeSame().click();
        Thread.sleep(1000);*/
        List<String>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine1']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine2']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='addressLine3']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='landmark']")).getText());
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='pinCode']")).getText());
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[2]")).getText());
        list.add(driver.findElement(By.xpath("(//div[@class='ngx-select__toggle btn form-control'])[3]")).getText());
        List<String>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine1']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine2']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine3']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeLandmark']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officePinCode']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='officeStateId']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='officeCityId']")).getText());
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).equals(list1.get(i)))
            {
                System.out.println("All Fields is Copy from Current Residence Address and Paste in Office Address successfully...");
            }
            else
            {
                throw new InterruptedException("All Fields is not Copy from Current Residence Address and Paste in Office Address please check...=:"+list.get(i));
            }
            i++;
        }
    }
    @And("I close the Verify that, If User Tick Same As current Residence Address then All Fields should be Copy from Current Residence Address and Paste in Office Address.")
    public void i_close_the_verify_that_if_user_tick_same_as_current_residence_address_then_all_fields_should_be_copy_from_current_residence_address_and_paste_in_office_address() {
        end();
    }


    @Then("I Verify that If User Untick Same As current Residence Address then All Fields should be clear from Office Address.")
    public void iVerifyThatIfUserUntickSameAsCurrentResidenceAddressThenAllFieldsShouldBeClearFromOfficeAddress() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getResOfficeSame().click();
        Thread.sleep(1000);
        qr.getResOfficeSame().click();
        Thread.sleep(1000);
        List<String>list1=new ArrayList<>();
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine1']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine2']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeAddressLine3']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officeLandmark']")).getText());
        list1.add(driver.findElement(By.xpath("//input[@formcontrolname='officePinCode']")).getText());
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='officeStateId']")).getAttribute("value"));
        list1.add(driver.findElement(By.xpath("//select[@formcontrolname='officeCityId']")).getAttribute("value"));
        int i=0;
        while (i<list1.size())
        {
            if (list1.get(i).isEmpty())
            {
                System.out.println("All Fields should be clear from Office Address successfully..");
            }
            else
            {
                throw new InterruptedException("All Fields should be clear from Office Address please check...");
            }
            i++;
        }
    }

    @And("I close the Verify that If User Untick Same As current Residence Address then All Fields should be clear from Office Address")
    public void iCloseTheVerifyThatIfUserUntickSameAsCurrentResidenceAddressThenAllFieldsShouldBeClearFromOfficeAddress() {
        end();
    }
    @Then("I Validate Reference details section in Data collection Q in Loans menu fields are display or not")
    public void i_validate_reference_details_section_in_data_collection_q_in_loans_menu_fields_are_display_or_not() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='referenceName1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference1']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='relationWith1Borrowe']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='referenceAddress1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='referenceName2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference2']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='relationWith2Borrowe']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='referenceAddress2']")));
        int i=0;
        while (i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("In reference details all fields are display successfully...");
            }
            else {
                throw new InterruptedException("only some fields are display in reference details please check....");
            }
            i++;
        }
    }
    @And("I Validate Reference details section in Data collection Q in Loans menu fields are display or not scenario")
    public void i_validate_reference_details_section_in_data_collection_q_in_loans_menu_fields_are_display_or_not_scenario() {
       end();
    }
    @Then("I Reference {int} Name and Reference {int} Name Fields Special Characters and Number should not be allowed.")
    public void i_reference_name_and_reference_name_fields_special_characters_and_number_should_not_be_allowed(Integer int1, Integer int2) throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='referenceName1']")).clear();
        Thread.sleep(1000);
        String firstreferencename=json.jsonActualReadData("FirstInvalidReferenceName");
        driver.findElement(By.xpath("//input[@formcontrolname='referenceName1']")).sendKeys(firstreferencename);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Reference 1 Name']")).click();
        Thread.sleep(1000);
        String msg="Please enter valid name";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("In reference name 1 special character and number not allow");
        }
        else {
            throw new InterruptedException("In reference name 1 Special character and number allow please check...");
        }
        String secondrefencename=json.jsonActualReadData("SecondInvalidReferenceName");
        driver.findElement(By.xpath("//input[@formcontrolname='referenceName2']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='referenceName2']")).sendKeys(secondrefencename);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Relation 2 with Borrowe']")).click();
        Thread.sleep(3000);
        String referencemsg="Please enter valid name";
        String getreferencemsg=driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")).getText();
        if (getreferencemsg.equals(referencemsg))
        {
            System.out.println("In reference name 2 special character and number not allow");
        }
        else {
            throw new InterruptedException("In reference name 2 Special character and number allow please check...");
        }
    }
    @And("I close the Reference {int} Name and Reference {int} Name Fields Special Characters and Number should not be allowed.")
    public void i_close_the_reference_name_and_reference_name_fields_special_characters_and_number_should_not_be_allowed(Integer int1, Integer int2) {
      end();
    }
    @Then("I In Mobile no of Reference {int} and Mobile no of Reference {int} fields Special Characters and Alphabets are not be allowed.")
    public void i_in_mobile_no_of_reference_and_mobile_no_of_reference_fields_special_characters_and_alphabets_are_not_be_allowed(Integer int1, Integer int2) throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        String firstreferencemobilenumber=json.jsonActualReadData("InvalidMobileNumber");
        driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference1']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference1']")).sendKeys(firstreferencemobilenumber);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Mobile No of Reference 1']")).click();
        Thread.sleep(1000);
        String mobilemsg="Please enter valid mobile number";
        String getmobilemsg=qr.getReferenceMSG().getText();
        if (getmobilemsg.equals(mobilemsg))
        {
            System.out.println("In reference mobile 1 special character and number not allow");
        }
        else {
            throw new InterruptedException("In reference mobile 1 special character and number is allow please check...");
        }

        String secondreferencemobilenumber=json.jsonActualReadData("InvalidMobilereferenceNumber");
        driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference2']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='mobileOfReference2']")).sendKeys(secondreferencemobilenumber);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Mobile No of Reference 2']")).click();
        Thread.sleep(1000);
        String secondmobilemsg="Please enter valid mobile number";
        String getsecodmobilemsg=driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")).getText();
        if (getsecodmobilemsg.equals(secondmobilemsg))
        {
            System.out.println("In reference mobile 1 special character and number not allow");
        }
        else {
            throw new InterruptedException("In reference mobile 1 special character and number is allow please check...");
        }
    }
    @And("I close In Mobile no of Reference {int} and Mobile no of Reference {int} fields Special Characters and Alphabets are not be allowed.")
    public void i_close_in_mobile_no_of_reference_and_mobile_no_of_reference_fields_special_characters_and_alphabets_are_not_be_allowed(Integer int1, Integer int2) {
        end();
    }
    @Then("I Validate Nominee details section in Data collection Q in Loans menu")
    public void i_validate_nominee_details_section_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='nomineeName1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee1']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='relationWithBorrowe1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='nomineeAddress1']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='nomineeName2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee2']")));
        list.add(driver.findElement(By.xpath("//select[@formcontrolname='relationWithBorrowe2']")));
        list.add(driver.findElement(By.xpath("//input[@formcontrolname='nomineeAddress2']")));
        int i=0;
        while(i<list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("All Nominee fields are displayed successfully...");
            }
            else {
                throw new InterruptedException("Some nominee fields are not displayed please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Nominee details section in Data collection Q in Loans menu")
    public void i_close_the_validate_nominee_details_section_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("I Nominee {int} Name and Nominee {int} Name Fields Special Characters and Number should not be allowed.")
    public void i_nominee_name_and_nominee_name_fields_special_characters_and_number_should_not_be_allowed(Integer int1, Integer int2) throws InterruptedException, IOException, org.json.simple.parser.ParseException {
       js=(JavascriptExecutor) driver;
       js.executeScript("window.scrollBy(0,999)");
       Thread.sleep(1000);
       String nomineename=json.jsonActualReadData("FirstNomineeIncorrectName");
       driver.findElement(By.xpath("//input[@formcontrolname='nomineeName1']")).clear();
       Thread.sleep(1000);
       driver.findElement(By.xpath("//input[@formcontrolname='nomineeName1']")).sendKeys(nomineename);
       Thread.sleep(1000);
       driver.findElement(By.xpath("//label[text()='Nominee 1 Name']")).click();
       Thread.sleep(1000);
       String firstnomineemsg="Please enter valid name";
       String getfirstnomineemsg=qr.getReferenceMSG().getText();
       if (getfirstnomineemsg.equals(firstnomineemsg))
       {
           System.out.println("Nominee First name Fields Special Characters and Number is not allowed");
       }
       else {
           throw new InterruptedException("Fields Special Characters and Number is allowed please check...");
       }
        String secondnomineename=json.jsonActualReadData("SecondNomineeIncorrectName");
        driver.findElement(By.xpath("//input[@formcontrolname='nomineeName2']")).clear();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='nomineeName2']")).sendKeys(secondnomineename);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Nominee 2 Name']")).click();
        Thread.sleep(1000);
        String secondnomineemsg="Please enter valid name";
        String getsecondnomineemsg=driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")).getText();
        if (getsecondnomineemsg.equals(secondnomineemsg))
        {
            System.out.println("Nominee First name Fields Special Characters and Number is not allowed");
        }
        else {
            throw new InterruptedException("Fields Special Characters and Number is allowed please check...");
        }
    }
    @And("I close Nominee {int} Name and Nominee {int} Name Fields Special Characters and Number should not be allowed.")
    public void i_close_nominee_name_and_nominee_name_fields_special_characters_and_number_should_not_be_allowed(Integer int1, Integer int2) {
        end();
    }
    @Then("I Verify that In Mobile no of Nominee {int} and Mobile no of Nominee {int} fields Special Characters and Alphabets are not be allowed.")
    public void i_verify_that_in_mobile_no_of_nominee_and_mobile_no_of_nominee_fields_special_characters_and_alphabets_are_not_be_allowed(Integer int1, Integer int2) throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee1']")).clear();
        Thread.sleep(1000);
        String firstnomineemobileno=json.jsonActualReadData("InvalidMobileNumber");
        driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee1']")).sendKeys(firstnomineemobileno);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Mobile No. of Nominee 1']")).click();
        Thread.sleep(1000);
        String msg="Please enter valid mobile number";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("In nominee 1 mobile number special character and alphabet is not allow...");
        }
        else {
            throw new InterruptedException("In nominee 1 mobile number special character and alphabet is allow please check....");
        }

        driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee2']")).clear();
        Thread.sleep(1000);
        String secondnomineemobileno=json.jsonActualReadData("InvalidMobileNumber");
        driver.findElement(By.xpath("//input[@formcontrolname='mobileNoofNominee2']")).sendKeys(secondnomineemobileno);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//label[text()='Mobile No. of Nominee 2']")).click();
        Thread.sleep(1000);
        String secondmsg="Please enter valid mobile number";
        String secondgetmsg=driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")).getText();
        if (secondgetmsg.equals(secondmsg))
        {
            System.out.println("In nominee 1 mobile number special character and alphabet is not allow...");
        }
        else {
            throw new InterruptedException("In nominee 1 mobile number special character and alphabet is allow please check....");
        }
    }
    @And("I close the Verify that In Mobile no of Nominee {int} and Mobile no of Nominee {int} fields Special Characters and Alphabets are not be allowed.")
    public void i_close_the_verify_that_in_mobile_no_of_nominee_and_mobile_no_of_nominee_fields_special_characters_and_alphabets_are_not_be_allowed(Integer int1, Integer int2) {
        end();
    }
    @Then("I Validate Remarks section in Data collection Q in Loans menu")
    public void i_validate_remarks_section_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        WebElement previewsremark=qr.getOldRemark();
        WebElement newremark=qr.getRemarkNew();
        if (previewsremark.isDisplayed()&&!previewsremark.isEnabled()&&newremark.isDisplayed()&&newremark.isEnabled())
        {
            System.out.println("Previous Remarks It is Disable and cant edit and  is display previous remarks New Remark It is enable and allow user to enter and remarks is dispolay on the field");
        }
        else {
            throw new InterruptedException("Previous Remarks It is not Disable and cant edit and  is not display previous remarks New Remark It is enable and allow user to enter and remarks  is npt dispolay on the field please check...");
        }
    }
    @And("I close the Validate Remarks section in Data collection Q in Loans menu")
    public void i_close_the_validate_remarks_section_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("I verify the Validate Grid column section section in Data collection Q in Loans menu or not")
    public void iVerifyTheValidateGridColumnSectionSectionInDataCollectionQInLoansMenuOrNot() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1100)");
        Thread.sleep(1000);
        List<WebElement>l=new ArrayList<>();
        l.add(driver.findElement(By.xpath("//input[@placeholder='ApplicationId']")));
        l.add(driver.findElement(By.xpath("//input[@placeholder='Diarise Date']")));
        l.add(driver.findElement(By.xpath("//input[@placeholder='Diarise Reason']")));
        l.add(driver.findElement(By.xpath("//input[@placeholder='Comment']")));
        l.add(driver.findElement(By.xpath("//input[@placeholder='Created By']")));
        int i=0;
        while (i<l.size())
        {
            if (l.get(i).isDisplayed())
            {
                System.out.println("All Field are displayed in grid column successfully...");
            }
            else {
                throw new InterruptedException("All Field is not displayed in grid column please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Grid column section section in Data collection Q in Loans menu")
    public void i_close_the_validate_grid_column_section_section_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("I Verify that, User able to search Diaries application details from Search box")
    public void i_verify_that_user_able_to_search_diaries_application_details_from_search_box() throws InterruptedException {
      js=(JavascriptExecutor) driver;
      js.executeScript("window.scrollBy(0,1100)");
      Thread.sleep(1000);
      WebElement diarise_reason=driver.findElement(By.xpath("//input[@placeholder='Diarise Reason']"));
      if (diarise_reason.isDisplayed()&&diarise_reason.isEnabled())
      {
          System.out.println("User able to search Diaries aplicationdetails from Search box..");
      }
      else {
          throw new InterruptedException("User not able to search Diaries aplicationdetails from Search box please check...");
      }
    }
    @And("I close the Verify that, User able to search Diaries application details from Search box")
    public void i_close_the_verify_that_user_able_to_search_diaries_application_details_from_search_box() {
     end();
    }
    @Then("I Validate Diarise button in Data collection Q in Loans menu")
    public void i_validate_diarise_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getDiariseButton().click();
        Thread.sleep(3000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//input[@id='dob-id']")));
        list.add(driver.findElement(By.xpath("//input[@placeholder='HH']")));
        list.add(driver.findElement(By.xpath("//input[@placeholder='MM']")));
        list.add(driver.findElement(By.xpath("//select[@id='diariseReason']")));
        list.add(driver.findElement(By.xpath("//textarea[@id='comment']")));
        WebElement button=driver.findElement(By.xpath("//button[text()='Submit']"));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&!button.isEnabled()&&button.isDisplayed())
            {
                System.out.println("Diarise button all fields are available...");
            }
            else {
                throw new InterruptedException("Diasarise button all fields are not available please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Diarise button in Data collection Q in Loans menu")
    public void i_close_the_validate_diarise_button_in_data_collection_q_in_loans_menu() {
    end();
    }
    @Then("I Validate Customer not interested button button in Data collection Q in Loans menu")
    public void i_validate_customer_not_interested_button_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(3000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//button[text()='Ok']")));
        list.add(driver.findElement(By.xpath("//button[text()='Cancel']")));
        String msg="Do you really want to decline this application ?";
        String getmsg=qr.getCopyAlter().getText();
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&list.get(i).isEnabled()&&getmsg.equals(msg))
            {
                System.out.println("All fields are available in not interested button popup");
            }
            else
            {
                throw new InterruptedException("All fields are not available in not interested button popup please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Customer not interested button button in Data collection Q in Loans menu")
    public void i_close_the_validate_customer_not_interested_button_button_in_data_collection_q_in_loans_menu() {
       end();
    }
    @Then("I Verify that If User Click on Cancel Button then Popup window should be close and application should not be rejected.")
    public void i_verify_that_if_user_click_on_cancel_button_then_popup_window_should_be_close_and_application_should_not_be_rejected() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);
        qr.getCancelButton().click();
        Thread.sleep(1000);
    }
    @And("I close the Verify that, If User Click on Cancel Button then Popup window should be close and application should not be rejected.")
    public void i_close_the_verify_that_if_user_click_on_cancel_button_then_popup_window_should_be_close_and_application_should_not_be_rejected() {
        end();
    }
    @Then("I Verify that Without select Declined Reason Submit button should not be enable.")
    public void i_verify_that_without_select_declined_reason_submit_button_should_not_be_enable() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(1000);
        WebElement decline_button=qr.getDeclineDisplayButton();
        if (decline_button.getAttribute("disabled").equals("true"))
        {
            System.out.println("Dclined button is not enable....");
        }
        else
        {
            throw new InterruptedException("Without selecting reason submit button is able please check...");
        }
    }
    @And("I close the Verify that Without select Declined Reason Submit button should not be enable.")
    public void i_close_the_verify_that_without_select_declined_reason_submit_button_should_not_be_enable() {
        end();
    }
    @Then("I Validate Bank selection button button button in Data collection Q in Loans menu")
    public void i_validate_bank_selection_button_button_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.gerBankSelectionButton().click();
        Thread.sleep(1000);
        String msg="Customer Application Status updated successfully.";
        String getmsg=qr.getCopyAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("Correct bank Selection alter accpted..");
        }
        else {
            throw new InterruptedException("Incorrect bank selection alter accepted please check...");
        }
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-1600)");
        Thread.sleep(1000);
        String pagename="Bank Selection Queue";
        String getpagename=driver.findElement(By.xpath("(//p[@class='mb-0'])[1]")).getText();
        if (getpagename.equals(pagename))
        {
            System.out.println("Bank selection page is open successfully...");
        }
        else {
            throw new InterruptedException("Bank selection page is not open please check...");
        }
    }
    @And("I close the Validate Bank selection button button button in Data collection Q in Loans menu")
    public void i_close_the_validate_bank_selection_button_button_button_in_data_collection_q_in_loans_menu() {
      end();
    }
    @Then("I Validate Save button button in Data collection Q in Loans menu")
    public void i_validate_save_button_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getDataCollectionQueueSubmit().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String savemsg="Application updated successfully";
        String getsavemsg=qr.getCopyAlter().getText();
        if (getsavemsg.equals(savemsg))
        {
            qr.getClosealter().click();
            System.out.println("save button validate successfully...");
        }
        else {
            throw new InterruptedException("something wants wrong with the save in data collection quque button pleas check..");
        }
    }
    @And("I close the Validate Save button button in Data collection Q in Loans menu")
    public void i_close_the_validate_save_button_button_in_data_collection_q_in_loans_menu() {
        end();
    }
    @Then("Validate save button in Data collection Q in Loans menu")
    public void validate_save_button_in_data_collection_q_in_loans_menu() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1600)");
        Thread.sleep(1000);
        qr.getDataCollectionQueueSubmit().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String msg="Application updated successfully";
        String getmsg=qr.getCopyAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            System.out.println("Appllication updated successfully...");
        }
        else {
            throw new InterruptedException("Appllication not updatedplease check...");
        }
    }
    @And("I close Validate Submit button in Data collection Q in Loans menu")
    public void i_close_validate_submit_button_in_data_collection_q_in_loans_menu() {
       end();
    }
    @When("I click on the microloan queue")
    public void i_click_on_the_microloan_queue() throws InterruptedException {
        qr.getMicroLoanQueue().click();
        Thread.sleep(3000);
    }
    @Then("I Validate Micro loan Queue in loan applications")
    public void i_validate_micro_loan_queue_in_loan_applications() throws InterruptedException {
        WebElement previousbutton=driver.findElement(By.xpath("//button[text()=' Previous ']"));
        WebElement nextbutton=qr.getNextButton();
        if (!previousbutton.isEnabled()&&previousbutton.isDisplayed()&&nextbutton.isDisplayed())
        {
            System.out.println("Button are display successfully...");
        }
        else {
            throw new InterruptedException("Buttons are not displayed please check...");
        }
    }
    @And("I close the Validate Micro loan Queue in loan applications")
    public void i_close_the_validate_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I Verify the microloan page is open or not")
    public void i_verify_the_microloan_page_is_open_or_not() throws InterruptedException {
        String pagename="Micro Loan Queue";
        String getpagename=driver.findElement(By.xpath("(//p[@class='mb-0'])[1]")).getText();
        if (getpagename.equals(pagename))
        {
            System.out.println("Correct microloan queue page is open");
        }
        else {
            throw new InterruptedException("Incorrect Microloan queue page is open please check....");
        }
    }
    @And("I close the Verify the microloan page is open or not")
    public void i_close_the_verify_the_microloan_page_is_open_or_not() {
       end();
    }

    @Then("I Validate Ellipsis in sub header in Micro loan Queue in loan applications")
    public void i_validate_ellipsis_in_sub_header_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        qr.getElipsis().click();
        Thread.sleep(1000);
        List<WebElement> list = new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Queue']")));
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Application']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Elipsis options are display successfully...");
            }
            else {
                throw new InterruptedException("Elipsis options are not display please check....");
            }
            i++;
        }
    }
    @And("I close Validate Ellipsis in sub header in Micro loan Queue in loan applications")
    public void i_close_validate_ellipsis_in_sub_header_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I verify that user should be able to see & click Ellipsis icon more than one time")
    public void i_verify_that_user_should_be_able_to_see_click_ellipsis_icon_more_than_one_time() throws InterruptedException {
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,7000)");
        Thread.sleep(1000);
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-7000)");
        Thread.sleep(1000);
        WebElement elipsebutton = qr.getElipsis();
        qr.getElipsis().click();
        List<WebElement> list = new ArrayList<>();
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Queue']")));
        list.add(driver.findElement(By.xpath("//span[text()='Refresh Application']")));
        int i = 0;
        while (i < list.size()) {
            if (elipsebutton.isDisplayed()&&list.get(i).isDisplayed()) {
                System.out.println("Elipsis options are display one more time successfully...");
            } else
            {
                throw new InterruptedException("Elipsis options are not display one more time please check....");
            }

            i++;
        }

    }
    @And("I close the verify that user should be able to see & click Ellipsis icon more than one time")
    public void i_close_the_verify_that_user_should_be_able_to_see_click_ellipsis_icon_more_than_one_time() {
       end();
    }

    @Then("I Validate Refresh Queue Ellipsis in sub header in Micro loan Queue in loan applications")
    public void i_validate_refresh_queue_ellipsis_in_sub_header_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        int beforesize=driver.findElements(By.xpath("//div[@class='ng-star-inserted']")).size();
        qr.getElipsis().click();
        driver.findElement(By.xpath("//span[text()='Refresh Queue']")).click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(2000);
        int aftersize=driver.findElements(By.xpath("//div[@class='ng-star-inserted']")).size();
        if (aftersize>=beforesize)
        {
            System.out.println("micro loan queue Page is refresh successfully...");
        }
        else
        {
            throw new InterruptedException("Micro loan queue page is not refresh please check....");
        }
    }
    @And("I close the Validate Refresh Queue Ellipsis in sub header in Micro loan Queue in loan applications")
    public void i_close_the_validate_refresh_queue_ellipsis_in_sub_header_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I Validate Search for applications here button in Micro loan Queue in loan applications")
    public void i_validate_search_for_applications_here_button_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        qr.getSearchClick().click();
        Thread.sleep(3000);
        if (qr.getSearchDropDown().isDisplayed())
        {
            System.out.println("dropdown options are displyed successsfully...");
        }
        else {
            throw new InterruptedException("Drop-down options are not displayed please check...");
        }
    }
    @And("I close the Validate Search for applications here button in Micro loan Queue in loan applications")
    public void i_close_the_validate_search_for_applications_here_button_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that when user will enter wrong id in the Search for Applciations here dropdown that time alert should be dispalyed")
    public void i_verify_that_when_user_will_enter_wrong_id_in_the_search_for_applciations_here_dropdown_that_time_alert_should_be_dispalyed() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String wrongapplicatioid=json.jsonActualReadData("invalidApplicationID");
        qr.getSearchId().sendKeys(wrongapplicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String msg="NO RESULTS FOUND";
        String getmsg=driver.findElement(By.xpath("//li[@class='ngx-select__item ngx-select__item_no-found dropdown-header ng-star-inserted']")).getText();
        Thread.sleep(1000);
        if (getmsg.equals(msg))
        {
            System.out.println("Wrong application Id Enter...");
        }
        else {
            throw new InterruptedException("Wrong application ID Enter take search field please check....");
        }
    }
    @And("I close the verify that when user will enter wrong id in the Search for Applciations here dropdown that time alert should be dispalyed")
    public void i_close_the_verify_that_when_user_will_enter_wrong_id_in_the_search_for_applciations_here_dropdown_that_time_alert_should_be_dispalyed() {
       end();
    }
    @Then("I verify that user is able to serach app id multiple time")
    public void i_verify_that_user_is_able_to_serach_app_id_multiple_time() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();

        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++) {
            String appid = dropoption.get(i).getText();
            qr.getSearchId().sendKeys(appid);
            Thread.sleep(1000);
            qr.getSearchId().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
        }
        /*Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("CorrectApplicationID1");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);*/
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        act.moveToElement(driver.findElement(By.xpath("//a[@class='ngx-select__clear btn btn-link ng-star-inserted']"))).click().build().perform();
        Thread.sleep(3000);
        Actions act1=new Actions(driver);
        act1.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid2=json.jsonActualReadData("CorrectApplicationID2");
        qr.getSearchId().sendKeys(applicatioid2);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
    }
    @And("I close the verify that user is able to serach app id multiple time")
    public void i_close_the_verify_that_user_is_able_to_serach_app_id_multiple_time() {
     end();
    }
    @Then("I Validate From date in Micro loan Queue in loan applications")
    public void i_validate_from_date_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("//input[@placeholder='From Date']"))).click().build().perform();
        Thread.sleep(3000);
        if (qr.getDateDisplay().isDisplayed()&&qr.getDateDisplay().isEnabled())
        {
            System.out.println("user is able to serach app id multiple time successfully...");
        }
        else {
            throw new InterruptedException("user is not able to serach app id multiple time please check...");
        }
    }
    @And("I close the Validate From date in Micro loan Queue in loan applications")
    public void i_close_the_validate_from_date_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that when user will search Microloan queue without selecting From date field that time alert should be displayed From date required")
    public void i_verify_that_when_user_will_search_microloan_queue_without_selecting_from_date_field_that_time_alert_should_be_displayed_from_date_required() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("CorrectApplicationID1");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);

        Actions act1=new Actions(driver);
        act1.moveToElement(driver.findElement(By.xpath("//input[@placeholder='To Date']"))).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//td[@class='ng-star-inserted'])[13]")).click();
        Thread.sleep(1000);

        qr.getSearch().click();
        String msg="From Date is required";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("alert is displayed From date required");
        }
        else {
            throw new InterruptedException("alert is not displayed From date required please check...");
        }
    }
    @And("I close verify that when user will search Microloan queue without selecting From date field that time alert should be displayed From date required")
    public void i_close_verify_that_when_user_will_search_microloan_queue_without_selecting_from_date_field_that_time_alert_should_be_displayed_from_date_required() {
    end();
    }
    @Then("I Validate To date in Micro loan Queue in loan applications")
    public void i_validate_to_date_in_micro_loan_queue_in_loan_applications() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        qr.getSearchClick().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++) {
            String appid = dropoption.get(i).getText();
            qr.getSearchId().sendKeys(appid);
            Thread.sleep(1000);
            qr.getSearchId().sendKeys(Keys.ENTER);
            Thread.sleep(1000);

        }
        /*Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("CorrectApplicationID1");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);*/

        Actions act1=new Actions(driver);
        act1.moveToElement(driver.findElement(By.xpath("//input[@placeholder='From Date']"))).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
       // driver.findElement(By.xpath("//span[@class='is-highlighted']")).click();
        Date d=new Date();
        SimpleDateFormat sd=new SimpleDateFormat("d");
        sd.format(d);
        driver.findElement(By.xpath("//span[text()="+sd.format(d)+"]")).click();
        Thread.sleep(1000);

        qr.getSearch().click();
        Thread.sleep(1000);
        String msg="To Date is required";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("alert is displayed From date required");
        }
        else {
            throw new InterruptedException("alert is not displayed From date required please check...");
        }

    }
    @And("I close the Validate To date in Micro loan Queue in loan applications")
    public void i_close_the_validate_to_date_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I Validate Search button in Micro loan Queue in loan applications")
    public void i_validate_search_button_in_micro_loan_queue_in_loan_applications() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();

        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++) {
            String appid = dropoption.get(i).getText();
            qr.getSearchId().sendKeys(appid);
            Thread.sleep(1000);
            json.jsonWrite("ApplicationID",appid);
            qr.getSearchId().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
        }

    /*    Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("CorrectApplicationID1");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);*/
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);

        Actions act1=new Actions(driver);
        act1.moveToElement(driver.findElement(By.xpath("//input[@placeholder='From Date']"))).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//td[@class='ng-star-inserted'])[13]")).click();
        Thread.sleep(1000);

        Actions act2=new Actions(driver);
        act2.moveToElement(driver.findElement(By.xpath("//input[@placeholder='To Date']"))).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//td[@class='ng-star-inserted'])[15]")).click();
        Thread.sleep(1000);

        qr.getSearch().click();
        Thread.sleep(3000);
        String applicatioid=json.jsonReadData("ApplicationID");
        String getapplicatioid=qr.getMicroId().getText();
        if (getapplicatioid.equals(applicatioid))
        {
            System.out.println("Correct application ID get...");
        }
        else
        {
            throw new InterruptedException("Incorrect Application ID get please check.....");
        }
    }
    @And("I close the Validate Search button in Micro loan Queue in loan applications")
    public void i_close_the_validate_search_button_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that when we click on the search button without entering App id or from date & to date value that time alert should be displayed")
    public void i_verify_that_when_we_click_on_the_search_button_without_entering_app_id_or_from_date_to_date_value_that_time_alert_should_be_displayed() throws InterruptedException {
        Actions actions=new Actions(driver);
        actions.moveToElement(qr.getSearch()).click().build().perform();
        Thread.sleep(5000);

        String msg="From Date is required";
        String getmsg=qr.getReferenceMSG().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("alert is displayed From date required");
        }
        else {
            throw new InterruptedException("alert is not displayed From date required please check...");
        }

        Thread.sleep(1000);
        String msg1="To Date is required";
        String getmsg1=driver.findElement(By.xpath("(//span[@class='text-danger ng-star-inserted'])[2]")).getText();
        if (getmsg1.equals(msg1))
        {
            System.out.println("alert is displayed From date required");
        }
        else {
            throw new InterruptedException("alert is not displayed From date required please check...");
        }
    }
    @And("I close the verify that when we click on the search button without entering App id or from date & to date value that time alert should be displayed")
    public void i_close_the_verify_that_when_we_click_on_the_search_button_without_entering_app_id_or_from_date_to_date_value_that_time_alert_should_be_displayed() {
        end();
    }
    @Then("I verify that when user select date backword direction in the from date and to date field & click on the search button that time alert should be displayed from date should be leass than to date")
    public void i_verify_that_when_user_select_date_backword_direction_in_the_from_date_and_to_date_field_click_on_the_search_button_that_time_alert_should_be_displayed_from_date_should_be_leass_than_to_date() throws InterruptedException {
       /* Date date=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YYYY");
        String fromdate=sdf.format(date);
        qr.getFromDate().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        qr.getFromDate().sendKeys(fromdate);
        Thread.sleep(1000);
        qr.getFromDate().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);*/

        qr.getFromDate().click();
        Thread.sleep(5000);
        Date d=new Date();
        SimpleDateFormat sd=new SimpleDateFormat("d");
        sd.format(d);
        driver.findElement(By.xpath("//span[text()="+sd.format(d)+"]")).click();
        Thread.sleep(1000);

        Actions act1=new Actions(driver);
        act1.moveToElement(qr.getToDate()).click().build().perform();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        qr.getPreviousbutton().click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("(//td[@class='ng-star-inserted'])[16]")).click();
        Thread.sleep(1000);

        qr.getSearch().click();
        Thread.sleep(3000);

        String altermsg="From date should be less than To date";
        String getaltermsg=qr.getAlter().getText();
        if (getaltermsg.equals(altermsg))
        {
            qr.getClosealter().click();
            System.out.println("alert is displayed from date should be less than to date successfully..");
        }
        else {
            throw new InterruptedException("alert is not displayed from date should be less than to date please check...");
        }
    }
    @And("I close the verify that when user select date backword direction in the from date and to date field & click on the search button that time alert should be displayed from date should be leass than to date")
    public void i_close_the_verify_that_when_user_select_date_backword_direction_in_the_from_date_and_to_date_field_click_on_the_search_button_that_time_alert_should_be_displayed_from_date_should_be_leass_than_to_date() {
        end();
    }
    @Then("I Validate in Status in Micro loan Queue in loan applications")
    public void i_validate_in_status_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        Thread.sleep(1000);
        Actions actions=new Actions(driver);
       actions.moveToElement(qr.getYes_Status()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getMicroId());
        list.add(driver.findElement(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[1]")));
        list.add(driver.findElement(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[2]")));
        list.add(driver.findElement(By.xpath("(//div[@class='col-12 d-md-flex flex-wrap align-item-center justify-content-between justify-content-md-start mb-2'])[3]")));
        int i=0;
        while (i < list.size()) {
            if (list.get(i).isDisplayed()) {
                System.out.println("For Yes status all fields are displayed successfully...");
            } else {
                throw new InterruptedException("For Yes status not all fields are displayed please check...");
            }
            i++;
        }
            /*String getapplicationid=qr.getMicroId().getText();
            if (!getapplicationid.equals(applicationid))
            {
                System.out.println("For Yes status apllication ID is changed...");
            }
            else
            {
                throw new InterruptedException("For Yes status application ID is not changed please check...");
            }*/
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,-500)");
            Thread.sleep(1000);
            Actions act=new Actions(driver);
            act.moveToElement(qr.getNo_status()).click().build().perform();
            ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,999)");
            String msg="No Data Available...";
            String getapplicationid1=driver.findElement(By.xpath("//h3[text()='No Data Available...']")).getText();
            if (getapplicationid1.equals(msg))
            {
                System.out.println("For NO status apllication ID is not have Bank data");
            }
            else
            {
                throw new InterruptedException("For NO status apllication ID is have Bank data please check...");
            }

        }

    @And("I close the Validate in Status in Micro loan Queue in loan applications")
    public void i_close_the_validate_in_status_in_micro_loan_queue_in_loan_applications() {
      end();
    }
    @Then("I verify that when user mark both status that time both \\(Yes - No) having status name lead should be displayed")
    public void i_verify_that_when_user_mark_both_status_that_time_both_yes_no_having_status_name_lead_should_be_displayed() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getMicroId());
        list.add(driver.findElement(By.xpath("//label[@class='pr-2 mb-md-0']")));
        list.add(driver.findElement(By.xpath("(//p[@class='mb-0 pr-1'])[1]")));
        list.add(driver.findElement(By.xpath("(//p[@class='mb-0 pr-1'])[2]")));
        int i=0;
        while (i < list.size()) {
            if (list.get(i).isDisplayed()) {
                System.out.println("For Both status all fields are displayed successfully...");
            } else {
                throw new InterruptedException("For Both status not all fields are displayed please check...");
            }
            i++;
        }
    }
    @And("I close the verify that when user mark both status that time both \\(Yes - No) having status name lead should be displayed")
    public void i_close_the_verify_that_when_user_mark_both_status_that_time_both_yes_no_having_status_name_lead_should_be_displayed() {
       end();
    }
    @Then("I Validate Application id in Micro loan Queue in loan - for search lead bank status not present")
    public void i_validate_application_id_in_micro_loan_queue_in_loan_for_search_lead_bank_status_not_present() throws InterruptedException {
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("//select[@id='formly_21_select_salutation_0']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_21_input_firstName_1']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_21_input_lastName_2']")));
        list.add(driver.findElement(By.xpath("//select[@id='formly_21_select_loanAppliedFor_3']")));
        list.add(driver.findElement(By.xpath("//select[@id='formly_21_select_loan2AppliedFor_4']")));
        list.add(driver.findElement(By.xpath("//input[@id='dob-id']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_21_input_mobile_6']")));
        list.add(driver.findElement(By.xpath("//input[@id='formly_21_input_alternateMobile_7']")));
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Syustem should display on top left Application id successfully...");
            }
            else
            {
                throw new InterruptedException("Syustem io not display on top left Application id please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Application id in Micro loan Queue in loan - for search lead bank status not present")
    public void i_close_the_validate_application_id_in_micro_loan_queue_in_loan_for_search_lead_bank_status_not_present() {
    end();
    }
    @Then("I Validate Salutation in Application in Micro loan Queue in loan applications")
    public void i_validate_salutation_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        WebElement salutation=qr.getInsurance_salutation();
        if (salutation.isDisplayed())
        {
            System.out.println("Salutation in Application in Micro loan Queue in loan applications is display successfully...");
        }
        else {
            throw new InterruptedException("Salutation in Application in Micro loan Queue in loan applications is not display please check...");
        }
    }
    @And("I close the Validate Salutation in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_salutation_in_application_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I  verify that user should be able to see Salutation field read only format")
    public void i_verify_that_user_should_be_able_to_see_salutation_field_read_only_format() throws InterruptedException {
        WebElement salutation=qr.getInsurance_salutation();
        if (salutation.getAttribute("disabled").equals("true"))
        {
            System.out.println("user should be able to see Salutation field read only format");
        }
        else {
            throw new InterruptedException("user should be able to see Salutation field but it not in read only formatplease check...");
        }
    }
    @And("I close  verify that user should be able to see Salutation field read only format")
    public void i_close_verify_that_user_should_be_able_to_see_salutation_field_read_only_format() {
      end();
    }
    @Then("I Validate First name in Application in Micro loan Queue in loan applications")
    public void i_validate_first_name_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        WebElement firstname=qr.getMicroFirstname();
        if (firstname.isDisplayed())
        {
            System.out.println("First name in Application in Micro loan Queue in loan applications is display successfully...");
        }
        else {
            throw new InterruptedException("First name in Application in Micro loan Queue in loan applications is not display please check...");
        }
    }
    @And("I close the Validate First name in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_first_name_in_application_in_micro_loan_queue_in_loan_applications() {
      end();
    }
    @Then("I verify that user should be able to see First name field read only format")
    public void i_verify_that_user_should_be_able_to_see_first_name_field_read_only_format() throws InterruptedException {
        WebElement firstname=qr.getMicroFirstname();
        if (firstname.getAttribute("disabled").equals("true"))
        {
            System.out.println("user should be able to see Firstname field read only format");
        }
        else {
            throw new InterruptedException("user should be able to see Firstname field but it not in read only formatplease check...");
        }
    }
    @And("I close the I verify that user should be able to see First name field read only format")
    public void i_close_the_i_verify_that_user_should_be_able_to_see_first_name_field_read_only_format() {
         end();
    }
    @Then("I Validate Last name in Application in Micro loan Queue in loan applications")
    public void i_validate_last_name_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        WebElement lastname=qr.gerMicroLastname();
        if (lastname.isDisplayed())
        {
            System.out.println("Last name in Application in Micro loan Queue in loan applications");
        }
        else {
            throw new InterruptedException("Last name in Application in Micro loan Queue in loan applications is not display please check....");
        }
    }
    @And("I close Validate Last name in Application in Micro loan Queue in loan applications")
    public void i_close_validate_last_name_in_application_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I verify that user should be able to see Last name field read only format")
    public void i_verify_that_user_should_be_able_to_see_last_name_field_read_only_format() throws InterruptedException {
        WebElement lastname=qr.gerMicroLastname();
        if (lastname.getAttribute("disabled").equals("true"))
        {
            System.out.println("user is to see Last name field read only format");
        }
        else {
            throw new InterruptedException("user is able to see Last name field not in read only format please check...");
        }
    }
    @And("I close the verify that user should be able to see Last name field read only format")
    public void i_close_the_verify_that_user_should_be_able_to_see_last_name_field_read_only_format() {
     end();
    }
    @Then("I Validate Loan applied for in Application in Micro loan Queue in loan applications")
    public void i_validate_loan_applied_for_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        String loanaplliedfor=qr.getMicroLoanAppliedFor().getAttribute("value");
        if (!loanaplliedfor.isEmpty())
        {
            System.out.println("Loan applied for in Application in Micro loan Queue in loan applications is display successfully...");
        }
        else {
            throw new InterruptedException("Loan applied for in Application in Micro loan Queue in loan applications is not display please check...");
        }
    }
    @And("I close the Validate Loan applied for in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_loan_applied_for_in_application_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I Validate Loan {int} applied for in Application in Micro loan Queue in loan applications")
    public void i_validate_loan_applied_for_in_application_in_micro_loan_queue_in_loan_applications(Integer int1) throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(1000);
        WebElement secondloan=qr.getSecondLoan();
        if (secondloan.isDisplayed())
        {
            System.out.println("Loan 2 applied for in Application in Micro loan Queue in loan applications is display successfully...");
        }
        else {
            throw new InterruptedException("Loan 2 applied for in Application in Micro loan Queue in loan applications is not display  please check...");
        }
    }
    @And("I close the Validate Loan {int} applied for in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_loan_applied_for_in_application_in_micro_loan_queue_in_loan_applications(Integer int1) {
     end();
    }
    @Then("I verify that user is able to select Loan2 applied for field on the Microloan queue stage")
    public void i_verify_that_user_is_able_to_select_loan2_applied_for_field_on_the_microloan_queue_stage() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(1000);
        /*qr.getSecondLoan().click();
        Thread.sleep(2000);*/
        Select select=new Select(driver.findElement(By.xpath("(//select[@placeholder='--Select--'])[3]")));
        select.selectByVisibleText("Personal Loan");
        Thread.sleep(1000);
        String getoption=driver.findElement(By.xpath("(//select[@placeholder='--Select--'])[3]")).getAttribute("value");
        if (!getoption.isEmpty())
        {
            System.out.println("user is able to select Loan2 applied for field on the Microloan queue stage");
        }else {
            throw new InterruptedException("user is Not able to select Loan2 applied for field on the Microloan queue stageplease check...");
        }

    }
    @And("I close the verify that user is able to select Loan2 applied for field on the Microloan queue stage")
    public void i_close_the_verify_that_user_is_able_to_select_loan2_applied_for_field_on_the_microloan_queue_stage() {
    end();
    }
    @Then("I verify that user is able to prerform any action\\(Data collection, dairise, Decline etc) without select Loan2 applied for field")
    public void i_verify_that_user_is_able_to_prerform_any_action_data_collection_dairise_decline_etc_without_select_loan2_applied_for_field() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getDeclineButton());
        list.add(qr.getDiariseButton()) ;
        list.add(qr.getDatacollection());
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&list.get(i).isEnabled())
            {
                System.out.println("User able to perform any action");
            }
            else {
                throw new InterruptedException("User not able to perform any action please check....");
            }
            i++;
        }
    }
    @And("I close the verify that user is able to prerform any action\\(Data collection, dairise, Decline etc) without select Loan2 applied for field")
    public void i_close_the_verify_that_user_is_able_to_prerform_any_action_data_collection_dairise_decline_etc_without_select_loan2_applied_for_field() {
       end();
    }
    @Then("I Validate Last modified date for in Application in Micro loan Queue in loan applications")
    public void i_validate_last_modified_date_for_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
    js=(JavascriptExecutor)driver;
    js.executeScript("window.scrollBy(0,300)");
    Thread.sleep(1000);
     String lastmodifieddate=qr.getInsurance_dob().getAttribute("value");
     if (!lastmodifieddate.isEmpty())
     {
         System.out.println("Last modification date is display successfully"+lastmodifieddate);
     }
     else
     {
         throw new InterruptedException("Last modification date is not diaplay please check...");
     }
    }
    @And("I close the Validate Last modified date for in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_last_modified_date_for_in_application_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I close the verify that user should be able to see modified date filed read only format")
    public void i_close_the_verify_that_user_should_be_able_to_see_modified_date_filed_read_only_format() {
       end();
    }
    @Then("I verify that user should be able to see modified date filed read only format")
    public void iVerifyThatUserShouldBeAbleToSeeModifiedDateFiledReadOnlyFormat() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        WebElement lastmodifieddate=qr.getInsurance_dob();
        if (lastmodifieddate.getAttribute("disabled").equals("true"))
        {
            System.out.println("The Last modification field user should be able to see modified date filed read only format");
        }
        else {
            throw new InterruptedException("The Last modification field user should be able to see modified date filed is not read only format please check...");
        }
    }
    @Then("I Validate Mobile in Application in Micro loan Queue in loan applications")
    public void i_validate_mobile_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        String mobilenumber=qr.getMicroMobileNo().getAttribute("value");
        if (!mobilenumber.isEmpty())
        {
            System.out.println("Mobile number is already exists");
        }
        else {
            throw new InterruptedException("Mobile number is not already exists please check...");
        }
    }
    @And("I close the Validate Mobile in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_mobile_in_application_in_micro_loan_queue_in_loan_applications() {
     end();
    }
    @Then("I verify that user should be able see mobile number filed read only format on the Micro loan queue stage")
    public void i_verify_that_user_should_be_able_see_mobile_number_filed_read_only_format_on_the_micro_loan_queue_stage() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        WebElement mobilenumber=qr.getMicroMobileNo();
        if (mobilenumber.getAttribute("disabled").equals("true"))
        {
            System.out.println("mobile number filed read only format on the Micro loan queue stage");
        }
        else
        {
            throw new InterruptedException("mobile number filed is not in read only format on the Micro loan queue stage pelase check...");
        }
    }
    @And("I close the verify that user should be able see mobile number filed read only format on the Micro loan queue stage")
    public void i_close_the_verify_that_user_should_be_able_see_mobile_number_filed_read_only_format_on_the_micro_loan_queue_stage() {
        end();
    }
    @Then("I Validate Alternate contact in Application in Micro loan Queue in loan applications")
    public void i_validate_alternate_contact_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        WebElement alternametemobilenumber=qr.getmicroalternatemobilenumber();
        if(alternametemobilenumber.isDisplayed())
        {
            System.out.println("system is display alternate contact number");
        }
        else {
            throw new InterruptedException("system is not display alternate contact number please check...");
        }
    }
    @And("I close Validate Alternate contact in Application in Micro loan Queue in loan applications")
    public void i_close_validate_alternate_contact_in_application_in_micro_loan_queue_in_loan_applications() {
       end();
    }
    @Then("I verify that user should be able see Alternate contact field read only format on the Micro loan queue stage")
    public void i_verify_that_user_should_be_able_see_alternate_contact_field_read_only_format_on_the_micro_loan_queue_stage() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        WebElement alternametemobilenumber=qr.getmicroalternatemobilenumber();
        if (alternametemobilenumber.getAttribute("disabled").equals("true"))
        {
            System.out.println("user should be able see Alternate contact field read only format on the Micro loan queue stage");
        }
        else {
            throw new InterruptedException("user not able see Alternate contact field read only format on the Micro loan queue stage please check");
        }
    }
    @And("I close the verify that user should be able see Alternate contact field read only format on the Micro loan queue stage")
    public void i_close_the_verify_that_user_should_be_able_see_alternate_contact_field_read_only_format_on_the_micro_loan_queue_stage() {
       end();
    }
    @Then("I Validate Remarks in Application in Micrloan Queue in loan applications")
    public void i_validate_remarks_in_application_in_micrloan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        WebElement previousremarke=driver.findElement(By.xpath("//textarea[@id='formly_24_textarea_oldRemark_0']"));
       String previousremark=driver.findElement(By.xpath("//textarea[@id='formly_24_textarea_oldRemark_0']")).getAttribute("value");
       WebElement newremark=driver.findElement(By.xpath("//textarea[@id='formly_24_textarea_newRemark_1']"));
       if (previousremark.isEmpty()&&!previousremarke.isEnabled()&&newremark.isDisplayed()&&newremark.isEnabled())
       {
           System.out.println("1.Previous Remark(It should be in disable position and also should dispay already enterd remarks)2.New Remark(This should be enable and allow user to enter Remarks)");
       }
       else {
           throw new InterruptedException("1.Previous Remark(It is not in disable position and also should dispay already enterd remarks)2.New Remark(This is not  enable and allow user to enter Remarks) please check...");
       }

    }
    @And("I close the Validate Remarks in Application in Micrloan Queue in loan applications")
    public void i_close_the_validate_remarks_in_application_in_micrloan_queue_in_loan_applications() {
       end();
    }
    @Then("I verify that user is able to perform any action on lead with entering New Remark textbox value")
    public void i_verify_that_user_is_able_to_perform_any_action_on_lead_with_entering_new_remark_textbox_value() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        WebElement newremark=driver.findElement(By.xpath("//textarea[@id='formly_24_textarea_newRemark_1']"));
        if (newremark.isDisplayed()&&newremark.isEnabled())
        {
            System.out.println("user is able to perform any action on lead with entering New Remark textbox value");
        }
        else
        {
            throw new InterruptedException("user is  not to perform any action on lead with entering New Remark textbox value please check...");
        }
    }
    @And("I close the verify that user is able to perform any action on lead with entering New Remark textbox value")
    public void i_close_the_verify_that_user_is_able_to_perform_any_action_on_lead_with_entering_new_remark_textbox_value() {
     end();
    }
    @Then("I verify that user is able to prerform any action \\(Data collection, dairise, Decline etc) without enter any details in the New Remark field")
    public void i_verify_that_user_is_able_to_prerform_any_action_data_collection_dairise_decline_etc_without_enter_any_details_in_the_new_remark_field() throws InterruptedException {
        js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getDeclineButton());
        list.add(qr.getDiariseButton()) ;
        list.add(qr.getDatacollection());
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed()&&list.get(i).isEnabled())
            {
                System.out.println("User able to perform any action");
            }
            else {
                throw new InterruptedException("User not able to perform any action please check....");
            }
            i++;
        }

    }
    @And("I close the verify that user is able to prerform any action \\(Data collection, dairise, Decline etc) without enter any details in the New Remark field")
    public void i_close_the_verify_that_user_is_able_to_prerform_any_action_data_collection_dairise_decline_etc_without_enter_any_details_in_the_new_remark_field() {
        end();
    }
    @Then("I Validate Bank status in Application in Micro loan Queue in loan applications")
    public void i_validate_bank_status_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
       List<WebElement>l=new ArrayList<>();
       l.add(qr.getBoth_status());
       l.add(qr.getYes_Status());
       l.add(qr.getNo_status());
       int i=0;
       while (i<l.size())
       {
           if (l.get(i).isDisplayed())
           {
               System.out.println("ALL Final status id displayed successfully...");
           }
           else
           {
               throw new InterruptedException("Only some status are displayed please check....");
           }
           i++;
       }
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("SearchApplicationID");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicationid=qr.getMicroId().getText();
        if (!applicationid.isEmpty())
        {
            System.out.println("Application id is display successfully...");
        }
        else
        {
            throw new InterruptedException("Application Id is not displayed please check...");
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[6]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[7]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[8]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[9]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[10]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[11]")));
        list.add(driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[12]")));
        list.add(driver.findElement(By.xpath("//input[@name='bankName']")));
        list.add(driver.findElement(By.xpath("//input[@name='sanctionedDate']")));
        list.add(driver.findElement(By.xpath("//input[@name='sanctionedAmount']")));
        list.add(driver.findElement(By.xpath("//input[@name='disbursedDate']")));
        list.add(driver.findElement(By.xpath("//input[@name='disbursedAmount']")));
        list.add(driver.findElement(By.xpath("//input[@name='status']")));
        list.add(driver.findElement(By.xpath("//input[@name='actionPriority']")));
        int j=0;
        while (j< list.size())
        {
            if (list.get(j).isDisplayed())
            {
                System.out.println("All Fields are display in bank status");
            }
            else {
                throw new InterruptedException("Only Some Fileds are display in bank status please check....");
            }
            j++;
        }
    }
    @And("I close the Validate Bank status in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_bank_status_in_application_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that Bank status should not displayed for which App id not updated reverse file")
    public void i_verify_that_bank_status_should_not_displayed_for_which_app_id_not_updated_reverse_file() throws InterruptedException {
        List<WebElement>l=new ArrayList<>();
        l.add(qr.getBoth_status());
        l.add(qr.getYes_Status());
        l.add(qr.getNo_status());
        int i=0;
        while (i<l.size())
        {
            if (l.get(i).isDisplayed())
            {
                System.out.println("ALL Final status id displayed successfully...");
            }
            else
            {
                throw new InterruptedException("Only some status are displayed please check....");
            }
            i++;
        }
        String applicationid=qr.getMicroId().getText();
        if (!applicationid.isEmpty())
        {
            System.out.println("Application id is display successfully...");
        }
        else
        {
            throw new InterruptedException("Application Id is not displayed please check...");
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);

        String msg="No Data Available...";
        String getapplicationid1=driver.findElement(By.xpath("//h3[text()='No Data Available...']")).getText();
        if (getapplicationid1.equals(msg))
        {
                System.out.println("bank status fields are not display");
            }
            else {
                throw new InterruptedException("Bank status field are display please check....");

        }
    }
    @And("I close the verify that Bank status should not displayed for which App id not updated reverse file")
    public void i_close_the_verify_that_bank_status_should_not_displayed_for_which_app_id_not_updated_reverse_file() {
          end();
    }
    @Then("I verify that user should be able to see bank status filed read only format")
    public void i_verify_that_user_should_be_able_to_see_bank_status_filed_read_only_format() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("SearchApplicationID");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,980)");
        Thread.sleep(1000);
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getMicroId());
        list.add(qr.getBankStatusApplicationID());
        list.add(qr.getBankstatusfinalstatus());
        list.add(qr.getBankstatustotalDisburedAmount());

        list.add(qr.getBankInsrtedRow());
        int i=0;
        while (i < list.size()) {
            act.doubleClick(list.get(i)).build().perform();
            Thread.sleep(1000);

            if (!(list.get(i).getTagName().equalsIgnoreCase("input")||list.get(i).getTagName().equalsIgnoreCase("textarea"))) {
                System.out.println("bank status filed is read only");
            }
            else
            {
                throw new InterruptedException("bank status filed not in read only format please check...");
            }
            i++;
        }

    }
    @And("I close the verify that user should be able to see bank status filed read only format")
    public void i_close_the_verify_that_user_should_be_able_to_see_bank_status_filed_read_only_format() {
       end();
    }
    @Then("I check if the match reacord visible under grid columns")
    public void i_check_if_the_match_reacord_visible_under_grid_columns() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("SearchApplicationID");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        String bankname=json.jsonActualReadData("BankName");
        driver.findElement(By.xpath("//input[@placeholder='Bank Name']")).click();
        Thread.sleep(1000);
        qr.getMicor_Bank_Name().sendKeys(bankname);
        Thread.sleep(1000);
        qr.getMicor_Bank_Name().sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        WebElement dropdowndisplay= driver.findElement(By.xpath("(//span[@class='ng-star-inserted'])[14]"));
        String comparedropdown=dropdowndisplay.getText();
        if (comparedropdown.equals(bankname)&&dropdowndisplay.isDisplayed())
        {
            System.out.println("the match reacord visible under grid columns");
        }
        else {
            throw new InterruptedException("the match reacord visible under grid columns please check...");
        }
    }
    @And("I close the check if the match reacord visible under grid columns")
    public void i_close_the_check_if_the_match_reacord_visible_under_grid_columns() {
        end();
    }
    @Then("I verify that when user will enter wrong details & trigger API that time no any match details should be dispaly")
    public void i_verify_that_when_user_will_enter_wrong_details_trigger_api_that_time_no_any_match_details_should_be_dispaly() throws InterruptedException, IOException, org.json.simple.parser.ParseException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("SearchApplicationID");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        String bankname=json.jsonActualReadData("IncorrectBankName");
        driver.findElement(By.xpath("//input[@placeholder='Bank Name']")).click();
        Thread.sleep(1000);
        qr.getMicor_Bank_Name().sendKeys(bankname);
        Thread.sleep(1000);
        qr.getMicor_Bank_Name().sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        String tabelbody= driver.findElement(By.xpath("//*[@id=\"appm\"]/div/app-wbd-q/div[2]/div[4]/div/div/div/main/div[1]/app-bank-status/div[2]/div/div/div/div/div/main/app-grid/div[1]/div/table/tbody")).getText();
        if (tabelbody.isEmpty())
        {
            System.out.println("No any match is display for the wrong bank name");
        }
        else {
            throw new InterruptedException("Match is disply for the wrong bank name please check...");
        }

    }
    @And("I close the verify that when user will enter wrong details & trigger API that time no any match details should be dispaly")
    public void i_close_the_verify_that_when_user_will_enter_wrong_details_trigger_api_that_time_no_any_match_details_should_be_dispaly() {
       end();
    }
    @Then("I Validate Decline Bank status in Application in Micro loan Queue in loan applications")
    public void i_validate_decline_bank_status_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(2000);
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getButton_close());
        list.add(qr.getDeclineReason());
        list.add(qr.getDeclineReasonSubmitButton());
        int i=0;
        while (i<list.size()) {
            if (list.get(i).isDisplayed()) {
                System.out.println(" Decline Bank status in Application in Micro loan Queue in loan applications");
            } else {
                throw new InterruptedException("Decline Bank status in Application in Micro loan Queue in loan applications please check...");
            }
            i++;
        }
    }
    @And("I close the Validate Decline Bank status in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_decline_bank_status_in_application_in_micro_loan_queue_in_loan_applications() {
     end();
    }
    @Then("I verify that when user click on the Decline button without selecting Declined reason that time alert should display please select Decline reason")
    public void i_verify_that_when_user_click_on_the_decline_button_without_selecting_declined_reason_that_time_alert_should_display_please_select_decline_reason() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(2000);
        qr.getDeclineReasonSubmitButton().click();
        Thread.sleep(1000);
        String msg="please select Decline reason";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            System.out.println("correct alter is display");
        }
        else{
            throw new InterruptedException("please select Decline reason alter is not shown please check...");
        }
    }
    @And("I close the verify that when user click on the Decline button without selecting Declined reason that time alert should display please select Decline reason")
    public void i_close_the_verify_that_when_user_click_on_the_decline_button_without_selecting_declined_reason_that_time_alert_should_display_please_select_decline_reason() {
       end();
    }
    @Then("I Validate Submit Decline Bank status in Application in Micro loan Queue in loan applications")
    public void i_validate_submit_decline_bank_status_in_application_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(2000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='declinereason']")));
        select.selectByVisibleText("Cash Salary");
        Thread.sleep(1000);
        qr.getDeclineReasonSubmitButton().click();
        Thread.sleep(1000);
        String msg="Decline reason updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("correct alter is display");
        }
        else{
            throw new InterruptedException("Incorrect alter is diaplay please check...");
        }
    }
    @And("I close the Validate Submit Decline Bank status in Application in Micro loan Queue in loan applications")
    public void i_close_the_validate_submit_decline_bank_status_in_application_in_micro_loan_queue_in_loan_applications() {
      end();
    }
    @Then("I verify that when user decline lead that time declined lead should not display in the search for application here textbox \\(on the Micro loan Queue stage)")
    public void i_verify_that_when_user_decline_lead_that_time_declined_lead_should_not_display_in_the_search_for_application_here_textbox_on_the_micro_loan_queue_stage() throws InterruptedException {
        String applicationid=qr.getMicroId().getText();
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(2000);
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='declinereason']")));
        select.selectByVisibleText("Cash Salary");
        Thread.sleep(1000);
        qr.getDeclineReasonSubmitButton().click();
        Thread.sleep(1000);
        String msg="Decline reason updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("correct alter is display");
        }
        else{
            throw new InterruptedException("Incorrect alter is diaplay please check...");
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(1000);
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        qr.getSearchId().sendKeys(applicationid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String msg1="NO RESULTS FOUND";
        String getmsg1=driver.findElement(By.xpath("//li[@class='ngx-select__item ngx-select__item_no-found dropdown-header ng-star-inserted']")).getText();
        Thread.sleep(1000);
        if (getmsg1.equals(msg1))
        {
            System.out.println("For Decline Reason Application ID not found");
        }
        else {
            throw new InterruptedException("For Decline Reason Application ID id found please check....");
        }
    }
    @And("I close the verify that when user decline lead that time declined lead should not display in the search for application here textbox \\(on the Micro loan Queue stage)")
    public void i_close_the_verify_that_when_user_decline_lead_that_time_declined_lead_should_not_display_in_the_search_for_application_here_textbox_on_the_micro_loan_queue_stage() {
     end();
    }
    @Then("I Validate Data collection button in Micro loan Queue in loan applications")
    public void i_validate_data_collection_button_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDatacollection().click();
        Thread.sleep(2000);
        String msg="Customer Application Status updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            System.out.println("Correct data collection aler is diaplay...");
        }
        else {
            throw new InterruptedException("Incorrect data collection alter is display please chek...");
        }
    }
    @And("I close the Validate Data collection button in Micro loan Queue in loan applications")
    public void i_close_the_validate_data_collection_button_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that when user click on the Data Collection button that time Data colletion action performed lead should not display in the search for application here textbox \\(on the Micro loan Queue stage)")
    public void i_verify_that_when_user_click_on_the_data_collection_button_that_time_data_colletion_action_performed_lead_should_not_display_in_the_search_for_application_here_textbox_on_the_micro_loan_queue_stage() throws InterruptedException {
        String applicationid=qr.getMicroId().getText();
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDatacollection().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(1000);
        qr.getDatacollectionok().click();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        this.i_navigate_to_the_home_page();
        this.i_click_on_the_microloan_queue();
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        qr.getSearchId().sendKeys(applicationid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String msg1="NO RESULTS FOUND";
        String getmsg1=driver.findElement(By.xpath("//li[@class='ngx-select__item ngx-select__item_no-found dropdown-header ng-star-inserted']")).getText();
        Thread.sleep(1000);
        if (getmsg1.equals(msg1))
        {
            System.out.println("For Data collectionn Reason Application ID not found");
        }
        else {
            throw new InterruptedException("For data collection Reason Application ID id found please check....");
        }
    }

    @And("I close the verify that when user click on the Data Collection button that time Data colletion action performed lead should not display in the search for application here textbox \\(on the Micro loan Queue stage)")
    public void i_close_the_verify_that_when_user_click_on_the_data_collection_button_that_time_data_colletion_action_performed_lead_should_not_display_in_the_search_for_application_here_textbox_on_the_micro_loan_queue_stage() {
      end();
    }
    @Then("Validate ok button in success message in Data collection in Micro loan Queue in loan applications")
    public void validate_ok_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDatacollection().click();
        Thread.sleep(2000);
        String msg="Customer Application Status updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            //ngwebdriver.waitForAngularRequestsToFinish();
            Thread.sleep(7000);
            System.out.println("Correct data collection aler is diaplay...");
        }
        else {
            throw new InterruptedException("Incorrect data collection alter is display please chek...");
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        String Datamsg="Data Collection Queue";
        String getdatamsg=driver.findElement(By.xpath("(//p[@class='mb-0'])[1]")).getText();
        if (getdatamsg.equals(Datamsg))
        {
            System.out.println("data collection action performed lead is display on the data collection page");
        }
        else {
            throw new InterruptedException("data collection action performed lead is not display on the data collection page please check....");
        }
    }
    @And("I close the Validate ok button in success message in Data collection in Micro loan Queue in loan applications")
    public void i_close_the_validate_ok_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() {
     end();
    }
    @Then("Validate Customer not interested button in success message in Data collection in Micro loan Queue in loan applications")
    public void validate_customer_not_interested_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);
        String cmsg="Do you really want to decline this application ?";
        String getcmsg=qr.getAlter().getText();
        if (getcmsg.equals(cmsg))
        {
            System.out.println("comfirmation msg display successfully...");
        }
        else
        {
            throw new InterruptedException("confirmation msg is not display please check...");
        }
        List<WebElement>list=new ArrayList<>();
        list.add(qr.getDatacollectionok());
        list.add(qr.getCancelButton());
        int i=0;
        while (i< list.size())
        {
            if (list.get(i).isDisplayed())
            {
                System.out.println("Conformation Yes and No options are displayed successfully...");
            }
            else {
                throw new InterruptedException("Conformation Yes and No options are displayed please check...");
            }
            i++;
        }

    }
    @And("I close the Validate Customer not interested button in success message in Data collection in Micro loan Queue in loan applications")
    public void i_close_the_validate_customer_not_interested_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() {
    end();
    }
    @Then("I verify that when user click on other than the Customer not interested button that time sysyetm should not display Customer not found respective page")
    public void i_verify_that_when_user_click_on_other_than_the_customer_not_interested_button_that_time_sysyetm_should_not_display_customer_not_found_respective_page() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getDeclineButton().click();
        Thread.sleep(2000);
        String cmsg="Do you really want to decline this application ?";
        String getcmsg=driver.findElement(By.xpath("//h6[@id='modal-basic-title']")).getText();
        if (!getcmsg.equals(cmsg))
        {
            System.out.println("Customer not found button respective page is not open");
        }
        else {
            throw new InterruptedException("Customer is found button respective page is not open please check...");
        }
    }
    @And("I close the verify that when user click on other than the Customer not interested button that time sysyetm should not display Customer not found respective page")
    public void i_close_the_verify_that_when_user_click_on_other_than_the_customer_not_interested_button_that_time_sysyetm_should_not_display_customer_not_found_respective_page() {
      end();
    }
    @Then("I Validate ok button in Customer not interested button in success message in Data collection in Micro loan Queue in loan applications")
    public void i_validate_ok_button_in_customer_not_interested_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
        String msg="Decline reason updated successfully.";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getDatacollectionok().click();
            Thread.sleep(1000);
            System.out.println("System should display a success message like Decline reason updated successfully");
        }
        else {
            throw new InterruptedException("System is not display a success message like Decline reason updated please check...");
        }
    }
    @And("I close Validate ok button in Customer not interested button in success message in Data collection in Micro loan Queue in loan applications")
    public void i_close_validate_ok_button_in_customer_not_interested_button_in_success_message_in_data_collection_in_micro_loan_queue_in_loan_applications() {
        end();
    }
    @Then("I verify that when user click on the OK button on the confirmation msg that time declined reason updated lead should not visible in the search application here textbox")
    public void i_verify_that_when_user_click_on_the_ok_button_on_the_confirmation_msg_that_time_declined_reason_updated_lead_should_not_visible_in_the_search_application_here_textbox() throws InterruptedException {
        String applicationid=qr.getMicroId().getText();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getCustomerNotInterestedButton().click();
        Thread.sleep(2000);
        qr.getDatacollectionok().click();
        Thread.sleep(1000);
        qr.getDatacollectionok().click();
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-999)");
        Thread.sleep(1000);
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        qr.getSearchId().sendKeys(applicationid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String msg1="NO RESULTS FOUND";
        String getmsg1=driver.findElement(By.xpath("//li[@class='ngx-select__item ngx-select__item_no-found dropdown-header ng-star-inserted']")).getText();
        Thread.sleep(1000);
        if (getmsg1.equals(msg1))
        {
            System.out.println("For Data collectionn Reason Application ID not found");
        }
        else {
            throw new InterruptedException("For data collection Reason Application ID id found please check....");
        }

    }
    @And("I close the verify that when user click on the OK button on the confirmation msg that time declined reason updated lead should not visible in the search application here textbox")
    public void i_close_the_verify_that_when_user_click_on_the_ok_button_on_the_confirmation_msg_that_time_declined_reason_updated_lead_should_not_visible_in_the_search_application_here_textbox() {
        end();
    }
    @Then("I verify that when user click on the Call button that time & CENTAUR application will not open at our side that time alert msg should be displayed something went wrong")
    public void i_verify_that_when_user_click_on_the_call_button_that_time_centaur_application_will_not_open_at_our_side_that_time_alert_msg_should_be_displayed_something_went_wrong() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
        Actions act=new Actions(driver);
        act.moveToElement(qr.getSearchClick()).click().build().perform();
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        String applicatioid=json.jsonActualReadData("SearchApplicationID");
        qr.getSearchId().sendKeys(applicatioid);
        Thread.sleep(1000);
        qr.getSearchId().sendKeys(Keys.ENTER);
        ngwebdriver.waitForAngularRequestsToFinish();
        Thread.sleep(5000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,999)");
        Thread.sleep(1000);
        qr.getCallButton().click();
        Thread.sleep(1000);
        String msg="Something Went Wrong OR Please re-login in CENTAUR App !";
        String getmsg=qr.getAlter().getText();
        if (getmsg.equals(msg))
        {
            qr.getClosealter().click();
            System.out.println("Something Went Wrong OR Please re-login in CENTAUR App ! alert is displayed successfully");
        }
        else {
            throw new InterruptedException("Something Went Wrong OR Please re-login in CENTAUR App ! alert is not displayed please check....");
        }
    }
    @And("I close the verify that when user click on the Call button that time & CENTAUR application will not open at our side that time alert msg should be displayed something went wrong")
    public void i_close_the_verify_that_when_user_click_on_the_call_button_that_time_centaur_application_will_not_open_at_our_side_that_time_alert_msg_should_be_displayed_something_went_wrong() {
     end();
    }
//*********************************************************************************************************************************************************************************************************************************************************************************************
@Then("I verify the all fields are present or not")
public void i_verify_the_all_fields_are_present_or_not() throws InterruptedException {
    List<WebElement> list = new ArrayList<WebElement>();
    list.add(qr.getPreviousbutton1());
    list.add(qr.getNextButton1());
    list.add(qr.getThreeDotButton());
    list.add(qr.getsearchID1());
    /*qr.getsearchID1().click();
    Thread.sleep(2000);
    qr.getsearchIDInput().sendKeys(appId);
    qr.getsearchIDInput().sendKeys(Keys.ENTER);
    Thread.sleep(3000);*/
    js=(JavascriptExecutor) driver;
    js.executeScript("window.scrollBy(0,300)");
    Thread.sleep(1000);
    list.add(qr.getappIdOnBankSQ());
    list.add(qr.getmerchantDetails());
    list.add(qr.getmerchantDetailsName());
    list.add(qr.getBuraueScrore());
    list.add(qr.getBuraueScroreNumber());
    list.add(qr.getfirstName());
    list.add(qr.getlastName());
    list.add(qr.getDOB1());
    list.add(qr.getMobileNumber());
    list.add(qr.getpanNumber());
    list.add(qr.getoccupation1());
    list.add(qr.getLoanApplied());
    list.add(qr.getLoanApplied2());
    list.add(qr.getpincode());
    list.add(qr.getadditionDataText());
    //   js.executeScript("window.scrollBy(0,300)");
    list.add(qr.getBankQGender());
    list.add(qr.getBankQcurrentAddress());
    list.add(qr.getBankQemailID());
    list.add(qr.getBankQLoanAmt());
    list.add(qr.getBankQmonthlyIncome());
    list.add(qr.getBankQIsNetBankingAvailable());
    list.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
    list.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
    list.add(qr.getBankQofficePincode());
    //  js.executeScript("window.scrollBy(0,300)");
    list.add(qr.getSendotp1());
    list.add(qr.getCallButton1());
    list.add(qr.getDeclineButton1());
    list.add(qr.getSumbitMicro1());
    list.add(qr.getDiariseButton1());
    list.add(qr.getCustomerNotInterestedButton1());

    int i=0;
    while(i< list.size())
    {
        if(list.get(i).isDisplayed())
        {
            System.out.println("field is displayed"+ list.get(i));
        }else {
            throw new IllegalArgumentException("field is not present"+ list.get(i));
        }
        if(i==4||i==8||i==12||i==16||i==20||i==24||i==28){
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,300)");
        }
        i++;
    }
}

    @Then("I close the Validate Bank selection Q in menu scenario")
    public void i_close_the_validate_bank_selection_q_in_menu_scenario() {
        end();
    }
    @When("I select the Bank selection Queue option")
    public void i_select_the_bank_selection_queue_option() throws InterruptedException {
        qr.getSelectionBankQ().click();
        Thread.sleep(2000);
    }
    @Then("I verify the All fields and Textbox should be non editable except Loan2 applied For dropdown and Search for application here  in Application Details Section.")
    public void i_verify_the_all_fields_and_textbox_should_be_non_editable_except_loan2_applied_for_dropdown_and_search_for_application_here_in_application_details_section() throws InterruptedException {
        /*enable element list*/
        List<WebElement>Enable=new ArrayList<>();
        Enable.add(qr.getLoanApplied2());
        Enable.add(qr.getsearchID1());
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        /*disable element list*/
        List<WebElement>disable=new ArrayList<>();
        disable.add(qr.getfirstName());
        disable.add(qr.getlastName());
        disable.add(qr.getDOB1());
        disable.add(qr.getMobileNumber());
        disable.add(qr.getpanNumber());
        disable.add(qr.getoccupation1());
        disable.add(qr.getLoanApplied());
        disable.add(qr.getpincode());

        int j=0;
        while(j<disable.size())
        {
            if (disable.get(j).isEnabled())
            {
                throw new IllegalArgumentException("filed is showing enable "+Enable.get(j));
            }
            if(j==3||j==6){
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,300)");
            }
            j++;
        }

        int i=0;
        while(i<Enable.size())
        {
            if (!Enable.get(i).isEnabled())
            {
                throw new IllegalArgumentException("filed is showing enable "+Enable.get(i));
            }
            i++;
        }
    }

    @Then("I close the All fields and Textbox should be non editable except Loan2 applied For dropdown and Search for application here  in Application Details Section scenario.")
    public void i_close_the_all_fields_and_textbox_should_be_non_editable_except_loan2_applied_for_dropdown_and_search_for_application_here_in_application_details_section_scenario() {
        end();
    }


    @Then("I verify the Previous Button should be disable after landed on Landing Page of Bank Selection queue  in Application Details Section.")
    public void i_verify_the_previous_button_should_be_disable_after_landed_on_landing_page_of_bank_selection_queue_in_application_details_section() throws InterruptedException {
        Thread.sleep(2000);
        if (!qr.getPreviousbutton1().isEnabled()){
            System.out.println("previous button showing disable");
        }else {
            throw new IllegalArgumentException("previous button showing enable");
        }
    }
    @Then("I close the Previous Button should be disable after landed on Landing Page of Bank Selection queue  in Application Details Section scenario")
    public void i_close_the_previous_button_should_be_disable_after_landed_on_landing_page_of_bank_selection_queue_in_application_details_section_scenario() {
        end();
    }

    @When("I click on Next button of Bank selection Queue page")
    public void i_click_on_next_button_of_bank_selection_queue_page() throws InterruptedException {
        Thread.sleep(2000);
        old_AppId=qr.getappIdOnBankSQ().getText();
        qr.getNextButton().click();
        Thread.sleep(3000);

    }

    @Then("I verify System should display next application id and its details or Not")
    public void i_verify_system_should_display_next_application_id_and_it_details_or_not() {
        String new_AppId=qr.getappIdOnBankSQ().getText();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,400)");
        if (!old_AppId.equalsIgnoreCase(new_AppId))
        {
            List<String> values=new ArrayList<>();
            values.add( qr.getfirstName().getAttribute("value"));
            values.add(qr.getlastName().getAttribute("value"));
            values.add(qr.getDOB1().getAttribute("value"));
            values.add(qr.getMobileNumber().getAttribute("value"));
            values.add(qr.getpanNumber().getAttribute("value"));
            values.add(qr.getoccupation1().getAttribute("value"));
            values.add(qr.getLoanApplied().getAttribute("value"));
            values.add(qr.getpincode().getAttribute("value"));
            int i=0;
            while (i<values.size()){
                if (values.get(i).isEmpty())
                {
                    throw new IllegalArgumentException("On this"+values.indexOf(values.get(i))+"__ value is showing empty ");
                }
                i++;
            }
        }else {
            throw new IllegalArgumentException("after clicking on Next button the next Application page is not showing");
        }
    }

    @Then("I close the System should display next application id and its details or Not scenario")
    public void i_close_the_system_should_display_next_application_id_and_its_details_or_not_scenario() {
        end();
    }

    @When("I click on the previous button of Bank selection Queue page")
    public void i_click_on_the_previous_button_of_bank_selection_queue_page() throws InterruptedException {
        qr.getPreviousbutton1().click();
        Thread.sleep(2000);
    }
    @Then("I verify System should display previous application id and its details or Not")
    public void i_verify_system_should_display_previous_application_id_and_its_details_or_not() {
        String currentID=qr.getappIdOnBankSQ().getText();
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,400)");
        if (old_AppId.equalsIgnoreCase(currentID))
        {
            List<String> values=new ArrayList<>();
            values.add( qr.getfirstName().getAttribute("value"));
            values.add(qr.getlastName().getAttribute("value"));
            values.add(qr.getDOB1().getAttribute("value"));
            values.add(qr.getMobileNumber().getAttribute("value"));
            values.add(qr.getpanNumber().getAttribute("value"));
            values.add(qr.getoccupation1().getAttribute("value"));
            values.add(qr.getLoanApplied().getAttribute("value"));
            values.add(qr.getpincode().getAttribute("value"));
            int i=0;
            while (i<values.size()){
                if (values.get(i).isEmpty())
                {
                    throw new IllegalArgumentException("On this"+values.indexOf(values.get(i))+"__ value is showing empty ");
                }
                i++;
            }
        }else {
            throw new IllegalArgumentException("after clicking on previous button the next Application page is not showing");
        }

    }
    @Then("I close the System should display previous application id and its details or Not scenario")
    public void i_close_the_system_should_display_previous_application_id_and_its_details_or_not_scenario() {
        end();
    }
    /*@When("I select the last applicaton id of Bank selection Queue page")
    public void i_select_the_last_applicaton_id_of_bank_selection_queue_page() throws InterruptedException {
        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>appIdList=driver.findElements(By.xpath("//li[@class='ngx-select__item-group ng-star-inserted']"));
        qr.getEnterSearchID().sendKeys(appIdList.get(appIdList.size()-1).getText());
        qr.getEnterSearchID().sendKeys(Keys.ENTER);
        Thread.sleep(1000);
    }

    @Then("I verify the next button is disable or not")
    public void i_verify_the_next_button_is_disable_or_not() {
        if ( qr.getNextButton().isEnabled()){
            throw new IllegalArgumentException("user select last application Id the also next button showing enable");
        }else {
            System.out.println("user select last application Id the next button showing disable");
        }

    }

    @Then("I close the After click on Next Button next Application Id should be Open. If next application Id not available then Next Button should be Disable Scenario")
    public void i_close_the_after_click_on_next_button_next_application_id_should_be_open_if_next_application_id_not_available_then_next_button_should_be_disable_scenario() {


    }*/


    @When("I click on the toggle button")
    public void i_click_on_the_toggle_button() throws InterruptedException {
        qr.getThreeDotButton().click();
        Thread.sleep(1000);
    }

    @Then("I verify the system showing Refresh Queue and Refresh applications option or Not")
    public void i_verify_the_system_showing_refresh_queue_and_refresh_applications_option_or_not() throws InterruptedException {
        Thread.sleep(1000);
        List<WebElement> toggelOptions=qr.gettoggelButtonOptionName();
        List<String> currentToggelOptinName=new ArrayList<>();
        currentToggelOptinName.add("Refresh Queue");
        currentToggelOptinName.add("Refresh Application");
        int i=0;
        while (i<toggelOptions.size())
        {
            if (!toggelOptions.get(i).getText().equalsIgnoreCase(currentToggelOptinName.get(i)))
            {
                throw new IllegalArgumentException(toggelOptions.get(i).getText()+" is not same to "+currentToggelOptinName.get(i));
            }
            i++;
        }

    }

    @Then("I close the system showing Refresh Queue and Refresh applications scenario")
    public void i_close_the_system_showing_refresh_queue_and_refresh_applications_scenario() {
        end();
    }

    @When("I click on the every toggel option")
    public void i_click_on_the_every_toggel_option() throws InterruptedException {
        Thread.sleep(1000);
        List<WebElement> toggelOptions=qr.gettoggelButtonOptionName();

        int i=0;
        while (i<toggelOptions.size())
        {
            toggelOptions.get(i).click();
            Thread.sleep(2000);
            if (!qr.getpageTitle().getText().equalsIgnoreCase("Bank Selection Queue"))
            {
                throw new IllegalArgumentException("session is logout");
            }
            i++;
        }
    }
    @Then("I verfiy the session logout or Not")
    public void i_verfiy_the_session_logout_or_not() throws InterruptedException {
        Thread.sleep(1000);
        if (!qr.getpageTitle().getText().equalsIgnoreCase("Bank Selection Queue"))
        {
            throw new IllegalArgumentException("session is logout");
        }

    }
    @Then("I close the after click on Page Refresh or Application Refresh Session should not be logout scenario")
    public void i_close_the_after_click_on_page_refresh_or_application_refresh_session_should_not_be_logout_scenario() {
        end();
    }

    @When("I select the Application ID in bank selection Q")
    public void i_select_the_application_id_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(1000);
        qr.getEnterSearchID().sendKeys("AA9602");
        Thread.sleep(1000);
        qr.getEnterSearchID().sendKeys(Keys.ENTER);
        Thread.sleep(2000);

    }
    @When("I click on the Page Refresh option of toggel Button")
    public void i_click_on_the_page_refresh_option_of_toggel_button() throws InterruptedException {
        List<WebElement> toggelOptions=qr.gettoggelButtonOptionName();
        toggelOptions.get(0).click();
        Thread.sleep(1000);
    }
    @Then("I verify the System should Refresh the Bank selection Q")
    public void i_verify_the_system_should_refresh_the_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(1000);
        if (qr.getEnterSearchID().getAttribute("value").isEmpty())
        {
            System.out.println("page is refreshed");
        }else {
            throw new IllegalArgumentException("page is not refreshed");
        }
    }
    @Then("I close the Refresh Queue in Toggle button in Bank selection Q page in menu")
    public void i_close_the_refresh_queue_in_toggle_button_in_bank_selection_q_page_in_menu() {
        end();
    }

    @When("I click on the search application Id dropdown in bank selection Q")
    public void i_click_on_the_search_application_id_dropdown_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(1000);
    }
    @Then("I verify the System should display the applicataion ids which are there in bank selection Q")
    public void i_verify_the_system_should_display_the_applicataion_ids_which_are_there_in_bank_selection_q() {
        if ((qr.getApplicationIDsList().size()>0||qr.getApplicationIDsList().get(0).getText().equalsIgnoreCase(" No results found ")))
        {
            System.out.println("application ID list is showing");
        }else {
            throw new IllegalArgumentException("search Application Id here dropdown showing empty");
        }
    }
    @And("I close the Validate Search Applications dropdown in Toggle button in Bank selection Q page in menu scenario")
    public void i_close_the_validate_search_applications_dropdown_in_toggle_button_in_bank_selection_q_page_in_menu_scenario() {
        end();
    }
    @When("Click on the addition data required text")
    public void click_on_the_addition_data_required_text() throws InterruptedException {
      /*  qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);*/
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-600)");
        Thread.sleep(2000);
        qr.getadditionDataText().click();
        Thread.sleep(1000);
        qr.getadditionDataText().click();
        Thread.sleep(1000);
    }
    @Then("I verify the additional data required fields are showing or not")
    public void i_verify_the_additional_data_required_fields_are_showing_or_not() throws InterruptedException {
        List<WebElement> fields=new ArrayList<>();
        fields.add(qr.getBankQGender());
        fields.add(qr.getBankQcurrentAddress());
        fields.add(qr.getBankQemailID());
        fields.add(qr.getBankQLoanAmt());
        fields.add(qr.getBankQmonthlyIncome());
        fields.add(qr.getBankQIsNetBankingAvailable());
        fields.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
        fields.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        fields.add(qr.getBankQofficePincode());
        fields.add(qr.getSendotp1());


        int i=0;
        while(i<fields.size())
        {
            if(!fields.get(i).isDisplayed())
            {
                throw new IllegalArgumentException("field is not present"+fields.get(i));
            }
            i++;
        }
    }
    @Then("I close the Validate Additional data required Applictaion details scenario")
    public void i_close_the_validate_additional_data_required_applictaion_details_scenario() {
        end();
    }

    @When("I entered few fields value in additional data required section of bank selection Q")
    public void i_entered_few_fields_value_in_additional_data_required_section_of_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQGender());
        slt.selectByIndex(1);
        Thread.sleep(1000);

        Select slt1=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);

        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);


    }
    @Then("Verify the send OTP button is disable or not Without Fillup all fields in bank selection Q")
    public void verify_the_send_otp_button_is_disable_or_not_without_fillup_all_fields_in_bank_selection_q() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button showing enable without fillin the mandatory fields");
        }else {
            System.out.println("send OTP button showing disable without fillin the mandatory fields");
        }
    }
    @Then("I close the  All Fields are mandatory to fill. Without Fillup all fields, Send OTP button should not be enable scenario")
    public void i_close_the_all_fields_are_mandatory_to_fill_without_fillup_all_fields_send_otp_button_should_not_be_enable_scenario() {
        end();
    }

    @When("I click on the gender dropdown of the additional data required section of bank selection Q")
    public void i_click_on_the_gender_dropdown_of_the_additional_data_required_section_of_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        qr.getBankQGender().click();
        Thread.sleep(1000);

    }

    @Then("I verfiy the male female and other values are present in dropdown list")
    public void i_verfiy_the_male_female_and_other_values_are_present_in_dropdown_list() {
        Select slt=new Select(qr.getBankQGender());
        List<WebElement> option=slt.getOptions();
        option.remove(0);

        List<String> expectedOptionName=new ArrayList<String>();
        expectedOptionName.add("Male");
        expectedOptionName.add("Female");
        expectedOptionName.add("Other");
        int i=0;
        int j=0;
        while (i<option.size())
        {
            if(option.get(i).getText().equalsIgnoreCase(expectedOptionName.get(j))){
                System.out.println(expectedOptionName.get(i)+"option is present in the gender dropdown");
            }else {
                throw new IllegalArgumentException(expectedOptionName.get(i)+"option is not present in the gender dropdown");
            }
            i++;
            j++;
        }

    }

    @Then("I verify the user should able select value in dropdown")
    public void i_verify_the_user_should_able_select_value_in_dropdown() throws InterruptedException {
        Select slt=new Select(qr.getBankQGender());
        Thread.sleep(1000);
        slt.selectByIndex(0);
        Thread.sleep(1000);
    }

    @Then("I verify the selected value should display in Gender dropdown")
    public void i_verify_the_selected_value_should_display_in_gender_dropdown() {
        Select slt=new Select(qr.getBankQGender());
        if(slt.getFirstSelectedOption().getText().isEmpty())
        {
            throw new IllegalArgumentException("selected value is not showing in gender dropdown");
        }
    }
    @Then("I close the Vaildate Gender dropdown in additional data required in bankl selection page")
    public void i_close_the_vaildate_gender_dropdown_in_additional_data_required_in_bankl_selection_page() {
        end();
    }

    @When("I fill all fields of additional data required section exclude gender in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_gender_in_bank_selection_q() throws InterruptedException {
        /*qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);*/
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,800)");
        Select select=new Select(driver.findElement(By.xpath("//select[@formcontrolname='gender']")));
        select.selectByVisibleText("-- Select --");
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);



    }
    @Then("I verify the Send OTP button should disable in bank selection Q")
    public void i_verify_the_send_otp_button_should_disable_in_bank_selection_q() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without selecting the gender option");
        }
    }
    @Then("I close the  User unable to Enter other than Dropdown list and without fillup Gender Dropdown List user unable to Sent OTP Scenario")
    public void i_close_the_user_unable_to_enter_other_than_dropdown_list_and_without_fillup_gender_dropdown_list_user_unable_to_sent_otp_scenario() {
        end();
    }

    @Then("I verfiy the user should able to enter the text in current address field")
    public void i_verfiy_the_user_should_able_to_enter_the_text_in_current_address_field() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,800)");
        qr.getBankQcurrentAddress().sendKeys("HLR.90-364");
        Thread.sleep(1000);
    }

    @Then("I verify the user entered text present in current adddress field")
    public void i_verify_the_user_entered_text_present_in_current_adddress_field() throws InterruptedException {
        Thread.sleep(2000);
        if(qr.getBankQcurrentAddress().getAttribute("value").equalsIgnoreCase("HLR.90-364"))
        {
            System.out.println("entered text in current address is same to the present text in current address");
        }else {
            throw new IllegalArgumentException("entered text in current address is not same to the present text in current address");
        }
    }

    @Then("I close the Vaildate Current address in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_current_address_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude current address in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_current_address_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);


    }

    @Then("I verify the Send OTP button should disable in without entering the current address bank selection Q for")
    public void i_verify_the_send_otp_button_should_disable_in_without_entering_the_current_address_bank_selection_q_for() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the current address");
        }

    }

    @Then("I close the Verify that,  Current Address Field should be mandatory without fillup Current Address User unable to Sent OTP to Customer.")
    public void i_close_the_verify_that_current_address_field_should_be_mandatory_without_fillup_current_address_user_unable_to_sent_otp_to_customer() {
        end();
    }

    @Then("I verfiy the user should able to enter the emial address in email field")
    public void i_verfiy_the_user_should_able_to_enter_the_emial_address_in_email_field() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);

    }

    @Then("I verify the user entered email id present in email id field")
    public void i_verify_the_user_entered_email_id_present_in_email_id_field() {
        if(qr.getBankQemailID().getAttribute("value").equalsIgnoreCase("ss@gmail.com"))
        {
            System.out.println("entered email id is same as available email id in email id fields");
        }else {
            throw new IllegalArgumentException("entered email id is not same as available email id in email id fields");
        }

    }

    @Then("I close the  Vaildate Email id in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_email_id_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I entered the emaid without\\(@,.) and all madatory fields of required data")
    public void i_entered_the_emaid_without_and_all_madatory_fields_of_required_data() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ssgmailcom");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);


    }

    @Then("I verify the Send OTP button should disable in without entering the valid email ID in bank selection Q for")
    public void i_verify_the_send_otp_button_should_disable_in_without_entering_the_valid_email_id_in_bank_selection_q_for() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the current address");
        }else {
            System.out.println("send OTP button is disable without entering the current address");

        }
    }

    @Then("I close the  In Email textbox Field, Special characters should be available Else system not allowed to send OTP scenario")
    public void i_close_the_in_email_textbox_field_special_characters_should_be_available_else_system_not_allowed_to_send_otp_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude email address in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_email_address_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-100)");
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);
    }

    @Then("I verify the Send OTP button should disable in without entering the email address bank selection Q")
    public void i_verify_the_send_otp_button_should_disable_in_without_entering_the_email_address_bank_selection_q() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the email address");
        }else {
            System.out.println("send OTP button is disable without entering the email address");
        }

    }

    @Then("I close the Verify that, Email ID Field should be mandatory without fillup that Field User unable to Sent OTP to Customer scenario")
    public void i_close_the_verify_that_email_id_field_should_be_mandatory_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @Then("I verfiy the user should able to enter amount in the loan amount field")
    public void i_verfiy_the_user_should_able_to_enter_amount_in_the_loan_amount_field() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(2000);
    }

    @Then("I verify the user entered loan amount present in loan amount field")
    public void i_verify_the_user_entered_loan_amount_present_in_loan_amount_field() {
        if(qr.getBankQLoanAmt().getAttribute("value").equalsIgnoreCase("20000"))
        {
            System.out.println("entered amount is same as available  amount in loan amount fields");
        }
        else {
            throw new IllegalArgumentException("entered amount is not same as available  amount in loan amount fields");
        }
    }

    @Then("I Vaildate Loan amount in additional data required in bankl selection page scenario")
    public void i_vaildate_loan_amount_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @Then("I enter the Alphabets and Special Characters along with number in the loan amount field of required data")
    public void i_enter_the_alphabets_and_special_characters_along_with_number_in_the_loan_amount_field_of_required_data() throws InterruptedException {
       Thread.sleep(1000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);

        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20@#$%000");
        Thread.sleep(1000);

    }

    @Then("I verify the loan amount field accepting Alphabets and Special Characters or not")
    public void i_verify_the_loan_amount_fielsd_accepting_Alphabets_and_Special_Characters_or_not() {
        if (qr.geterrorMsg().isDisplayed())
        {
            System.out.println(qr.geterrorMsg().getText()+ "  loan amount field not accepting speacial charecter");
        }else {
            throw new IllegalArgumentException("loan amount field accepting speacial charecter");

        }
    }

    @Then("I In Loan Amount Textbox, Alphabets and Special Characters should not be allowed scenario")
    public void i_in_loan_amount_textbox_alphabets_and_special_characters_should_not_be_allowed_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude loan amount in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_loan_amount_in_bank_selection_q() throws InterruptedException {

        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);

    }

    @Then("I verify the Send OTP button should disable without entering the loan amount in required data")
    public void i_verify_the_send_otp_button_should_disable_without_entering_the_loan_amount_in_required_data() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the loan amount");
        }else {
            System.out.println("send OTP button is disable");
        }
    }

    @Then("I close the Loan amount Field should be mandatory without fillup that Field User unable to Sent OTP to Customer scenario")
    public void i_close_the_loan_amount_field_should_be_mandatory_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @Then("I verfiy the user should able to enter income in the monthly income field")
    public void i_verfiy_the_user_should_able_to_enter_income_in_the_monthly_income_field() throws InterruptedException {
        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
    }

    @Then("I verify the user entered monthly income present in monthly income field")
    public void i_verify_the_user_entered_monthly_income_present_in_monthly_income_field() {
        if(qr.getBankQmonthlyIncome().getAttribute("value").equalsIgnoreCase("25000"))
        {
            System.out.println("entered monthly income is same as available income amount in monthly income fields");
        }else {
            throw new IllegalArgumentException("entered monthly income is not same as available income amount in monthly income fields");
        }
    }

    @Then("I close the Vaildate monthly income in additional data required in bank selection page scenario")
    public void i_close_the_vaildate_monthly_income_in_additional_data_required_in_bank_selection_page_scenario() {
        end();
    }


    @Then("I enter the Alphabets and Special Characters along with number in the monthly income field of required data")
    public void i_enter_the_alphabets_and_special_characters_along_with_number_in_the_monthly_income_field_of_required_data() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);

        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("20@#$%000");
        Thread.sleep(3000);
    }
    @Then("I verify the monthly income field accepting Alphabets and Special Characters or not")
    public void i_verify_the_monthly_income_field_accepting_alphabets_and_special_characters_or_not() {
        if (qr.geterrorMsg().isDisplayed())
        {
            System.out.println(qr.geterrorMsg().getText()+ "  monthly income field not accepting speacial charecter");
        }else {
            throw new IllegalArgumentException("monthly income field accepting speacial charecter");

        }
    }

    @Then("I close the Net Monthly Income textbox Fields, Alphabets and Special Characters should not be allowed. Also Decimal numbers should not allowed scenario")
    public void i_close_the_net_monthly_income_textbox_fields_alphabets_and_special_characters_should_not_be_allowed_also_decimal_numbers_should_not_allowed_scenario() {

    }

    @When("I fill all fields of additional data required section exclude Monthly Income in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_monthly_income_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);
    }
    @Then("I verify the Send OTP button should disable without entering the Monthly Income in required data")
    public void i_verify_the_send_otp_button_should_disable_without_entering_the_monthly_income_in_required_data() {
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the valid monthaly income");
        }else {
            System.out.println("send OTP button is disable");
        }
    }
    @Then("I close the Net Monthly Income Field should be mandatory without fillup that Field  User unable to Sent OTP to Customer scenario")
    public void i_close_the_net_monthly_income_field_should_be_mandatory_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @When("I click on the Do you have internet banking dropdown of the additional data required section of bank selection Q")
    public void i_click_on_the_do_you_have_internet_banking_dropdown_of_the_additional_data_required_section_of_bank_selection_q() throws InterruptedException {
        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQIsNetBankingAvailable().click();
        Thread.sleep(1000);
    }

    @Then("I verfiy the yes and No values are present in dropdown list")
    public void i_verfiy_the_yes_and_no_values_are_present_in_dropdown_list() {
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        List<WebElement> option=slt.getOptions();
        option.remove(0);

        List<String> expectedOptionName=new ArrayList<String>();
        expectedOptionName.add("Yes");
        expectedOptionName.add("No");
        int i=0;
        while (i<option.size())
        {
            if(option.get(i).getText().equalsIgnoreCase(expectedOptionName.get(i))){
                System.out.println(expectedOptionName.get(i)+"option is present in the gender dropdown");
            }else {
                throw new IllegalArgumentException(expectedOptionName.get(i)+"option is not present in the gender dropdown");
            }
            i++;
        }


    }

    @Then("I verify the user should able select value in Do you have internet banking dropdown")
    public void i_verify_the_user_should_able_select_value_in_do_you_have_internet_banking_dropdown() throws InterruptedException {
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
    }

    @Then("I verify the selected value should display in Do you have internet banking dropdown")
    public void i_verify_the_selected_value_should_display_in_do_you_have_internet_banking_dropdown() {
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        if(slt.getFirstSelectedOption().getText().isEmpty())
        {
            throw new IllegalArgumentException("selected value is not showing in Do you have internet banking dropdown");
        }else {
            System.out.println("selected value is showing in Do you have internet banking dropdown");
        }
    }

    @Then("I close the Vaildate Do you have internet banking in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_do_you_have_internet_banking_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude Do You Have Internet Banking Dropdown in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_do_you_have_internet_banking_dropdown_in_bank_selection_q() throws InterruptedException {

        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt1=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt1.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);
    }

    @Then("I verify the Send OTP button should disable without selecting the value of Do You Have Internet Banking Dropdown in bank selection Q")
    public void i_verify_the_send_otp_button_should_disable_without_selecting_the_value_of_do_you_have_internet_banking_dropdown_in_bank_selection_q() throws InterruptedException {
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(1000);
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the valid monthaly income");
        }else {
            System.out.println("send OTP button is disable");
        }
    }

    @Then("I close the Do You Have Internet Banking Dropdown should be mandatory dropdown, without fillup that Field  User unable to Sent OTP to Customer scenario")
    public void i_close_the_do_you_have_internet_banking_dropdown_should_be_mandatory_dropdown_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @When("I click on the Is your salary credited in bank account dropdown of the additional data required section of bank selection Q")
    public void i_click_on_the_is_your_salary_credited_in_bank_account_dropdown_of_the_additional_data_required_section_of_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Thread.sleep(1000);
        qr.getBankQIsYourSalaryCreditedInBankAccount().click();
        Thread.sleep(1000);
    }

    @Then("I verfiy the yes and No values are present in Is your salary credited in bank account dropdown list")
    public void i_verfiy_the_yes_and_no_values_are_present_in_is_your_salary_credited_in_bank_account_dropdown_list() throws InterruptedException {
        Select slt=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        List<WebElement> option=slt.getOptions();
        option.remove(0);

        List<String> expectedOptionName=new ArrayList<String>();
        expectedOptionName.add("Yes");
        expectedOptionName.add("No");
        int i=0;
        while (i<option.size())
        {
            if(option.get(i).getText().equalsIgnoreCase(expectedOptionName.get(i))){
                System.out.println(expectedOptionName.get(i)+"option is present in the Is your salary credited in bank account dropdown");
            }else {
                throw new IllegalArgumentException(expectedOptionName.get(i)+"option is not present in the Is your salary credited in bank account dropdown");
            }
            i++;
        }
        qr.getBankQIsYourSalaryCreditedInBankAccount().click();
        Thread.sleep(1000);

    }

    @Then("I verify the user should able select value in Is your salary credited in bank account dropdown")
    public void i_verify_the_user_should_able_select_value_in_is_your_salary_credited_in_bank_account_dropdown() throws InterruptedException {
        Select slt=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
    }

    @Then("I verify the selected value should display in Is your salary credited in bank account dropdown")
    public void i_verify_the_selected_value_should_display_in_is_your_salary_credited_in_bank_account_dropdown() {
        Select slt=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        if(slt.getFirstSelectedOption().getText().isEmpty())
        {
            throw new IllegalArgumentException("selected value is not showing in Is your salary credited in bank account dropdown");
        }else {
            System.out.println(slt.getFirstSelectedOption().getText()+"   value is showing in Is your salary credited in bank account dropdown");
        }
    }

    @Then("I close the Vaildate Is your salary credited in bank account in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_is_your_salary_credited_in_bank_account_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude Is Your Salary Credited in Bank Account Dropdown in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_is_your_salary_credited_in_bank_account_dropdown_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        Thread.sleep(1000);
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);
    }

    @Then("I verify the Send OTP button should disable without selecting the value of Is Your Salary Credited in Bank Account Dropdown in bank selection Q")
    public void i_verify_the_send_otp_button_should_disable_without_selecting_the_value_of_is_your_salary_credited_in_bank_account_dropdown_in_bank_selection_q() throws InterruptedException {
        Select slt0=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        slt0.selectByVisibleText("-- Select --");
        Thread.sleep(1000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(1000);
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without selecting the Is Your Salary Credited in Bank Account Dropdown");
        }else {
            System.out.println("send OTP button is disable");
        }
    }

    @Then("I close the Is Your Salary Credited in Bank Account Dropdown should be mandatory dropdown, without fillup that Field  User unable to Sent OTP to Customer scenario")
    public void i_close_the_is_your_salary_credited_in_bank_account_dropdown_should_be_mandatory_dropdown_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @When("I click on the Do you have salary slip or certificate dropdown of the additional data required section of bank selection Q")
    public void i_click_on_the_do_you_have_salary_slip_or_certificate_dropdown_of_the_additional_data_required_section_of_bank_selection_q() throws InterruptedException {
        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate().click();
        Thread.sleep(1000);
    }

    @Then("I verfiy the yes and No values are present in Do you have salary slip or certificate dropdown list")
    public void i_verfiy_the_yes_and_no_values_are_present_in_do_you_have_salary_slip_or_certificate_dropdown_list() throws InterruptedException {
        Select slt=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        List<WebElement> option=slt.getOptions();
        option.remove(0);

        List<String> expectedOptionName=new ArrayList<String>();
        expectedOptionName.add("Yes");
        expectedOptionName.add("No");
        int i=0;
        while (i<option.size())
        {
            if(option.get(i).getText().equalsIgnoreCase(expectedOptionName.get(i))){
                System.out.println(expectedOptionName.get(i)+"option is present in the Is your salary credited in bank account dropdown");
            }else {
                throw new IllegalArgumentException(expectedOptionName.get(i)+"option is not present in the Is your salary credited in bank account dropdown");
            }
            i++;
        }
        qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate().click();
        Thread.sleep(1000);
    }

    @Then("I verify the user should able select value in Do you have salary slip or certificate dropdown")
    public void i_verify_the_user_should_able_select_value_in_do_you_have_salary_slip_or_certificate_dropdown() throws InterruptedException {
        Select slt=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
    }

    @Then("I verify the selected value should display in Do you have salary slip or certificate dropdown")
    public void i_verify_the_selected_value_should_display_in_do_you_have_salary_slip_or_certificate_dropdown() {
        Select slt=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        if(slt.getFirstSelectedOption().getText().isEmpty())
        {
            throw new IllegalArgumentException("selected value is not showing in Do you have salary slip or certificate dropdown");
        }else {
            System.out.println(slt.getFirstSelectedOption().getText()+"value is showing in Do you have salary slip or certificate dropdown");
        }
    }

    @Then("I close the Vaildate Do you have salary slip or certificate in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_do_you_have_salary_slip_or_certificate_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I fill all fields of additional data required section exclude Do You Have Salary Slip or Salary Certificate Dropdown in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_do_you_have_salary_slip_or_salary_certificate_dropdown_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        Thread.sleep(1000);
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        Select select=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        select.selectByVisibleText("-- Select --");
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411006");
        Thread.sleep(1000);
    }

    @Then("I verify the Send OTP button should disable without selecting the value of Do You Have Salary Slip or Salary Certificate Dropdown in bank selection Q")
    public void i_verify_the_send_otp_button_should_disable_without_selecting_the_value_of_do_you_have_salary_slip_or_salary_certificate_dropdown_in_bank_selection_q() throws InterruptedException {
        Thread.sleep(1000);
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without selecting the Do You Have Salary Slip or Salary Certificate Dropdown");
        }else {
            System.out.println("send OTP button is disable");
        }
    }

    @Then("I close the Do You Have Salary Slip or Salary Certificate Dropdown should be mandatory dropdown, without fillup that Field User unable to Sent OTP to Customer scenario")
    public void i_close_the_do_you_have_salary_slip_or_salary_certificate_dropdown_should_be_mandatory_dropdown_without_fillup_that_field_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @Then("I verfiy the user should able to enter pincode in the pincode field")
    public void i_verfiy_the_user_should_able_to_enter_pincode_in_the_pincode_field() throws InterruptedException {
        Thread.sleep(2000);
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411002");
        Thread.sleep(1000);
    }

    @Then("I verify the user entered pincode present in pincode field")
    public void i_verify_the_user_entered_pincode_present_in_pincode_field() {
        if (qr.getBankQofficePincode().getAttribute("value").isEmpty())
        {
            throw new IllegalArgumentException("user entered pincode is not showing in pincoe field");
        }else {
            System.out.println("user entered pincode is showing in pincoe field");
        }
    }

    @Then("I close the Vaildate Office pincode in additional data required in bankl selection page scenario")
    public void i_close_the_vaildate_office_pincode_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @Then("I verfiy the pincode field accept {int} digit or more than this")
    public void i_verfiy_the_pincode_field_accept_digit_or_more_than_this(Integer int1) throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411021789");
        Thread.sleep(1000);
        if (qr.getBankQofficePincode().getAttribute("value").length()==6)
        {
            System.out.println("pincode field accepted only 6 digit");
        }else {
            throw new IllegalArgumentException("pincode field accepting more than 6 digit");
        }

    }

    @Then("I close the Verify that , Pincode field should be allow {int} digit only scenario")
    public void i_close_the_verify_that_pincode_field_should_be_allow_digit_only_scenario(Integer int1) {
        end();
    }

    @When("I fill all fields of additional data required section exclude Pincode Field in bank selection Q")
    public void i_fill_all_fields_of_additional_data_required_section_exclude_pincode_field_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        /*Actions act=new Actions(driver);
        act.click(qr.getsearchID1()).build().perform();
        Thread.sleep(2000);
        qr.getsearchIDInput().sendKeys(appId);
        qr.getsearchIDInput().sendKeys(Keys.ENTER);
        Thread.sleep(3000);*/
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        Thread.sleep(1000);
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        Select slt4=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        Thread.sleep(1000);
        slt4.selectByIndex(1);
        Thread.sleep(1000);

    }

    @Then("I verify the Send OTP button should disable without entering the Pincode in required data")
    public void i_verify_the_send_otp_button_should_disable_without_entering_the_pincode_in_required_data() throws InterruptedException {
        Thread.sleep(1000);
        if (qr.getSendotp1().isEnabled())
        {
            throw new IllegalArgumentException("send OTP button is enable without entering the pincode ");
        }else {
            System.out.println("send OTP button is disable");
        }
    }

    @Then("I close the Pincode Field should be mandatory dropdown, without fillup Pincode User unable to Sent OTP to Customer scenario")
    public void i_close_the_pincode_field_should_be_mandatory_dropdown_without_fillup_pincode_user_unable_to_sent_otp_to_customer_scenario() {
        end();
    }

    @When("I fill all mandatory fields of additional data required section in bank selection Q")
    public void i_fill_all_mandatory_fields_of_additional_data_required_section_in_bank_selection_q() throws InterruptedException {
        qr.getsearchID1().click();
        Thread.sleep(2000);
        List<WebElement>dropoption=qr.getSearch_Option_Size();
        int getdropoptionsize=dropoption.size();
        for (int i=getdropoptionsize-1;i<getdropoptionsize;i++)
        {
            qr.getsearchID1().click();
            Thread.sleep(2000);
            String appid=dropoption.get(i).getText();
            qr.getsearchIDInput().sendKeys(appid);
            Thread.sleep(1000);
            qr.getsearchIDInput().sendKeys(Keys.ENTER);
            Thread.sleep(1000);
            js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(1000);
            List<WebElement>bankelement=new ArrayList<>();
            bankelement.add(qr.getBankQIsNetBankingAvailable());
            bankelement.add(qr.getBankQIsYourSalaryCreditedInBankAccount());
            bankelement.add(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());

            if (bankelement.get(0).isDisplayed()&&bankelement.get(0).isEnabled()&&bankelement.get(1).isDisplayed()&&bankelement.get(1).isEnabled()&&bankelement.get(2).isDisplayed()&&bankelement.get(2).isEnabled())
            {
                System.out.println("Process the application id....");
            }
            else {
                js=(JavascriptExecutor)driver;
                js.executeScript("window.scrollBy(0,-3000)");
                Thread.sleep(1000);

                // this.i_search_the_application_for_the_bank_selection_page();
            }
        }
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(1000);
        Select slt3=new Select( qr.getBankQGender());
        Thread.sleep(1000);
        slt3.selectByIndex(2);
        Thread.sleep(1000);
        qr.getBankQcurrentAddress().sendKeys("HRL,50");
        Thread.sleep(1000);
        qr.getBankQemailID().clear();
        Thread.sleep(1000);
        qr.getBankQemailID().sendKeys("ss@gmail.com");
        Thread.sleep(1000);
        qr.getBankQLoanAmt().clear();
        Thread.sleep(1000);
        qr.getBankQLoanAmt().sendKeys("20000");
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().clear();
        Thread.sleep(1000);
        qr.getBankQmonthlyIncome().sendKeys("25000");
        Thread.sleep(1000);
        Select slt=new Select(qr.getBankQIsNetBankingAvailable());
        Thread.sleep(1000);
        slt.selectByIndex(1);
        Thread.sleep(1000);
        Select slt2=new Select(qr.getBankQIsYourSalaryCreditedInBankAccount());
        Thread.sleep(1000);
        slt2.selectByIndex(1);
        Thread.sleep(1000);
        Select slt4=new Select(qr.getBankQDoYouHaveSalarySlipOrSalaryCertificate());
        Thread.sleep(1000);
        slt4.selectByIndex(1);
        Thread.sleep(1000);
        qr.getBankQofficePincode().sendKeys("411004");
        Thread.sleep(1000);
    }

    @Then("I verfiy the Send OTP button is enable or not")
    public void i_verfiy_the_send_otp_button_is_enable_or_not() {
        if (qr.getSendotp1().isEnabled())
        {
            System.out.println("send OTP button is enable");

        }else {
            throw new IllegalArgumentException("send OTP button is diaable after entering all details ");
        }
    }

    @Then("I verify the user should able to click on send OTP button")
    public void i_verify_the_user_should_able_to_click_on_send_otp_button() throws InterruptedException {
        if (isClickable(qr.getSendotp1(),wait))
        {
            System.out.println("after filling of all mandatory details send OTP button is clickable");
        }else {
            throw  new IllegalArgumentException("after filling of all mandatory details send OTP button is disable");
        }
        qr.getSendotp1().click();
        Thread.sleep(4000);
    }

    @Then("I verify the OTP sent success message showing or not after clicking on send OTP button")
    public void i_verify_the_otp_sent_success_message_showing_or_not_after_clicking_on_send_otp_button() throws InterruptedException {
        if( qr.getOTPSentMessage().getText().equalsIgnoreCase("An OTP has been sent to your mobile number"))
        {
            System.out.println("An OTP has been sent to your mobile number alert is showing after click on send OTP button");
        }else {
            throw new IllegalArgumentException("An OTP has been sent to your mobile number alert is not showing after click on send OTP button");
        }
        Thread.sleep(1000);
        qr.getacceptOTPAlert().click();
        Thread.sleep(1000);

    }

    @Then("I verify the OTP fields and verify OTP button in frozen formate is showing or not after clicking on send OTP button")
    public void i_verify_the_otp_fields_and_verify_otp_button_in_frozen_formate_is_showing_or_not_after_clicking_on_send_otp_button() throws InterruptedException {
        js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        if (qr.getenterOTPField().isDisplayed())
        {
            System.out.println("enter OTP fields is showing");
        }else {
            throw new IllegalArgumentException("enter OTP fields is not showing");
        }
        if (qr.getverfiyOTPButton().isEnabled())
        {
            throw new IllegalArgumentException("without entering the OTP verify OTP button showing enable");

        }else {
            System.out.println("without entering the OTP verify OTP button showing disable");
        }

    }

    @Then("I close the Vaildate Send OTP button in additional data required in bankl selection page Scenario")
    public void i_close_the_vaildate_send_otp_button_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @When("I click on send OTP button in bank selection Q")
    public void i_click_on_send_otp_button_in_bank_selection_q() throws InterruptedException {
        qr.getSendotp1().click();
        Thread.sleep(5000);
        qr.getacceptOTPAlert().click();
        Thread.sleep(1000);

    }

    @Then("I verfiy the OTP Field accept {int} digit or more than this")
    public void i_verfiy_the_otp_field_accept_digit_or_more_than_this(Integer int1) throws InterruptedException {
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        qr.getenterOTPField().sendKeys("411021789");
        Thread.sleep(1000);
        if (qr.getenterOTPField().getAttribute("value").length()==6)
        {
            System.out.println("Enter OTP field accepted only 6 digit");
        }else {
            throw new IllegalArgumentException("Enter OTP field accepting more than 6 digit");
        }


    }

    @Then("I close the OTP Field should be allowed only {int} digit scenario")
    public void i_close_the_otp_field_should_be_allowed_only_digit_scenario(Integer int1) {
        end();
    }

    @Then("I verify the user should able to enter the OTP in OTP field")
    public void i_verify_the_user_should_able_to_enter_the_otp_in_otp_field() throws InterruptedException {
        qr.getenterOTPField().sendKeys("675839");
        Thread.sleep(1000);
        if (qr.getenterOTPField().getAttribute("value").length()==6)
        {
            System.out.println("user is able to enter value in OTP filed");
        }else {
            throw new IllegalArgumentException("user is not able to enter value in OTP filed");
        }
    }

    @Then("I verify the mask button showing or not in OTP field")
    public void i_verify_the_mask_button_showing_or_not_in_otp_field() {
        if( qr.getmaskIcon().isDisplayed())
        {
            System.out.println("mask icon is showing in enter OTP field");
        }else {
            throw new IllegalArgumentException("mask icon is not showing in enter OTP field");
        }
    }

    @Then("I verify the verify OTP button enable after entering the OTP in OTP field")
    public void i_verify_the_verify_otp_button_enable_after_entering_the_otp_in_otp_field() {
        if (qr.getverfiyOTPButton().isEnabled())
        {
            System.out.println("verify OTP button is showing enable after entering the OTP ");
        }else {
            throw new IllegalArgumentException("verify OTP button is showing disable after entering the OTP also ");
        }
    }
    @Given("I verify the user click on verify OTP button or not")
    public void i_verify_the_user_click_on_verify_otp_button_or_not() throws InterruptedException {
        if(isClickable(qr.getVerifyOTP(),wait))
        {
            System.out.println("verfiy OTP button is clickable after entering the OTP in OTP field");
        }else {
            throw new IllegalArgumentException("verfiy OTP button is not clickable after entering the OTP in OTP field");
        }
        Thread.sleep(1000);
        qr.getVerifyOTP().click();

    }

    @Then("I close the Verify OTP button in additional data required in bankl selection page Scenario")
    public void i_close_the_verify_otp_button_in_additional_data_required_in_bankl_selection_page_scenario() {
        end();
    }

    @Then("I verify the {string} field Not accept alphabate and speacial charecter")
    public void i_verify_the_field_not_accept_alphabate_and_speacial_charecter(String str1) throws InterruptedException {
        Thread.sleep(1000);
        qr.getenterOTPField().sendKeys(str1);
        Thread.sleep(3000);
        Actions act=new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath("//label[@class='form-check-label mt-3 mb-3']"))).click().build().perform();
        Thread.sleep(4000);
        if(qr.geterrorMsg().isDisplayed())
        {
            System.out.println("OTP fisled not accepting the alphabate and speacial charecter");
        }else {
            throw new IllegalArgumentException("OTP filed accepting the alphabate and speacial charecter");
        }
    }

    @Then("I close the Only Digit Number should be Allowed in OTP field scenario")
    public void i_close_the_only_digit_number_should_be_allowed_in_otp_field_scenario() {
     end();
    }

    @When("I Enter the OPT in OTP in OTP field of Bank selection Q")
    public void i_enter_the_opt_in_otp_in_otp_field_of_bank_selection_q() {

    }
}
